const SUPABASE_URL = 'https://zfnlgzwvvytophdxtoks.supabase.co';
const SUPABASE_KEY = 'sb_publishable_d8kkB1Nyfjlx8LD9LQ5Ogw_WZPbxL5k';
const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const $ = (id) => document.getElementById(id);

function initIcons() {
  try { if (window.lucide) window.lucide.createIcons({ attrs: { 'stroke-width': 2.1 } }); } catch (e) { console.warn('Icons:', e); }
}
initIcons();

const imageInput = $('productImage');
const imagePreview = $('imagePreview');
const imageName = $('imageName');
imageInput?.addEventListener('change', () => {
  const file = imageInput.files?.[0];
  if (!file) {
    if (imagePreview) { imagePreview.removeAttribute('src'); imagePreview.classList.remove('show'); }
    if (imageName) imageName.textContent = '';
    return;
  }
  const allowed = ['image/jpeg','image/png','image/webp'];
  if (!allowed.includes(file.type)) {
    imageInput.value = '';
    if (imagePreview) { imagePreview.removeAttribute('src'); imagePreview.classList.remove('show'); }
    if (imageName) imageName.textContent = '';
    return setMessage($('orderMsg'), 'اختر صورة JPG أو PNG أو WEBP فقط.', 'error');
  }
  if (file.size > 5 * 1024 * 1024) {
    imageInput.value = '';
    if (imagePreview) { imagePreview.removeAttribute('src'); imagePreview.classList.remove('show'); }
    if (imageName) imageName.textContent = '';
    return setMessage($('orderMsg'), 'حجم الصورة يجب ألا يتجاوز 5MB.', 'error');
  }
  if (imageName) imageName.textContent = file.name;
  if (imagePreview) {
    imagePreview.src = URL.createObjectURL(file);
    imagePreview.classList.add('show');
  }
  setMessage($('orderMsg'), 'تم اختيار الصورة بنجاح ✓', 'success');
});

let qty = 1;
let selectedSite = 'AliExpress';
let cachedOrders = [];

const statusNames = {
  received: 'جديد', checking: 'جاري التحقق', price_confirmation: 'تأكيد السعر',
  awaiting_payment: 'انتظار الدفع', paid: 'مدفوع', shipping: 'قيد الشحن',
  arrived_algeria: 'وصل الجزائر', delivered: 'تم التسليم', cancelled: 'ملغي'
};

function setMessage(el, text, type = '') {
  if (!el) return;
  el.textContent = text || '';
  el.className = type;
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
function formatDate(value) {
  try { return new Date(value).toLocaleDateString('ar-DZ'); } catch { return '—'; }
}
function formatMoney(value, currency = 'DZD') {
  const n = Number(value);
  return Number.isFinite(n) ? `${n.toLocaleString('ar-DZ')} ${currency === 'DZD' ? 'دج' : currency}` : 'بانتظار التسعير';
}
function openAuth(message = '') {
  $('authModal')?.classList.add('show');
  if (message) setMessage($('authMsg'), message, 'error');
}
function closeAuth() { $('authModal')?.classList.remove('show'); }

async function getProfile(user) {
  if (!user) return null;
  const { data, error } = await db.from('profiles').select('id,first_name,last_name,full_name,phone,avatar_url').eq('id', user.id).maybeSingle();
  if (error) {
    console.warn('Profile:', error.message);
    return null;
  }
  return data || null;
}

function profileValuesFromUser(user, profile = null) {
  const meta = user?.user_metadata || {};
  const full = profile?.full_name || meta.full_name || '';
  const parts = String(full).trim().split(/\s+/).filter(Boolean);
  return {
    first_name: profile?.first_name || meta.first_name || parts.shift() || '',
    last_name: profile?.last_name || meta.last_name || parts.join(' ') || '',
    phone: profile?.phone || meta.phone || ''
  };
}

async function openProfileModal(user = null, message = '') {
  const current = user || (await db.auth.getUser()).data.user;
  if (!current) return openAuth(message || 'سجّل الدخول أولًا باستخدام Google.');
  const profile = await getProfile(current);
  const values = profileValuesFromUser(current, profile);
  $('firstName').value = values.first_name;
  $('lastName').value = values.last_name;
  $('phone').value = values.phone;
  $('profileModal')?.classList.add('show');
  if (message) setMessage($('profileMsg'), message, 'error');
}

async function ensureProfileComplete(user, showModal = true) {
  const profile = await getProfile(user);
  const values = profileValuesFromUser(user, profile);
  const complete = Boolean(values.first_name.trim() && values.last_name.trim() && values.phone.trim());
  if (!complete && showModal) await openProfileModal(user);
  return complete;
}

$('googleLogin')?.addEventListener('click', async () => {
  const button = $('googleLogin');
  if (button) button.disabled = true;
  setMessage($('authMsg'), 'جارٍ فتح تسجيل الدخول بحساب Google…', 'success');
  try {
    const redirectTo = 'https://dzfenk.github.io/FENK-DZ/';
    const { error } = await db.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo,
        queryParams: { access_type: 'offline', prompt: 'select_account' }
      }
    });
    if (error) setMessage($('authMsg'), error.message, 'error');
  } catch (error) {
    setMessage($('authMsg'), error?.message || 'تعذر بدء تسجيل الدخول عبر Google.', 'error');
  } finally {
    if (button) button.disabled = false;
  }
});

$('profileForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const { data: { user } } = await db.auth.getUser();
  if (!user) return openAuth('انتهت الجلسة. سجّل الدخول باستخدام Google.');
  const firstName = $('firstName').value.trim();
  const lastName = $('lastName').value.trim();
  const phone = $('phone').value.trim();
  if (!firstName || !lastName || !phone) return setMessage($('profileMsg'), 'أكمل الاسم واللقب ورقم الهاتف.', 'error');
  if (!/^[0-9+()\s-]{8,20}$/.test(phone)) return setMessage($('profileMsg'), 'أدخل رقم هاتف صحيح.', 'error');
  const button = $('saveProfile');
  button.disabled = true;
  button.textContent = 'جارٍ الحفظ…';
  try {
    const fullName = `${firstName} ${lastName}`.trim();
    const { error } = await db.from('profiles').upsert({
      id: user.id,
      first_name: firstName,
      last_name: lastName,
      full_name: fullName,
      phone,
      avatar_url: user.user_metadata?.avatar_url || null,
      updated_at: new Date().toISOString()
    }, { onConflict: 'id' });
    if (error) throw error;
    const { error: authError } = await db.auth.updateUser({ data: { first_name: firstName, last_name: lastName, full_name: fullName, phone } });
    if (authError) console.warn('Auth metadata:', authError.message);
    setMessage($('profileMsg'), 'تم حفظ بياناتك بنجاح ✓', 'success');
    updateAuthUI({ ...user, user_metadata: { ...(user.user_metadata || {}), full_name: fullName, first_name: firstName, last_name: lastName, phone } });
    setTimeout(() => $('profileModal')?.classList.remove('show'), 450);
  } catch (error) {
    console.error('Profile save:', error);
    setMessage($('profileMsg'), error?.message || 'تعذر حفظ البيانات. حاول مرة أخرى.', 'error');
  } finally {
    button.disabled = false;
    button.textContent = 'حفظ البيانات';
  }
});

// Product source selector

for (const button of document.querySelectorAll('#sites button')) {
  button.addEventListener('click', () => {
    document.querySelectorAll('#sites button').forEach((b) => b.classList.remove('active'));
    button.classList.add('active');
    selectedSite = button.dataset.site || 'موقع آخر';
  });
}

$('plus')?.addEventListener('click', () => { qty += 1; $('qty').textContent = qty; });
$('minus')?.addEventListener('click', () => { qty = Math.max(1, qty - 1); $('qty').textContent = qty; });
async function handleAccountClick() {
  const { data: { user } } = await db.auth.getUser();
  if (user) return openProfileModal(user);
  openAuth();
}
$('accountBtn')?.addEventListener('click', handleAccountClick);
$('mobileAccount')?.addEventListener('click', handleAccountClick);
$('mobileStore')?.addEventListener('click', () => $('marketModal')?.classList.add('show'));
function openMessages() { window.location.href = 'https://t.me/FENK_DZ_Bot'; }
$('messagesBtn')?.addEventListener('click', openMessages);
$('mobileMessages')?.addEventListener('click', openMessages);
$('closeProfile')?.addEventListener('click', () => $('profileModal')?.classList.remove('show'));
$('profileModal')?.addEventListener('click', (e) => { if (e.target === $('profileModal')) $('profileModal').classList.remove('show'); });
$('searchBtn')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') e.currentTarget.click(); });

$('closeAuth')?.addEventListener('click', closeAuth);
$('authModal')?.addEventListener('click', (e) => { if (e.target === $('authModal')) closeAuth(); });

async function refreshTelegramLinkUI(user) {
  const box = $('telegramLinkBox');
  if (!box) return;
  if (!user) { box.innerHTML = ''; return; }
  const { data } = await db.from('telegram_accounts').select('chat_id,username,first_name,linked_at').eq('user_id', user.id).maybeSingle();
  if (data) {
    box.innerHTML = `<div class=\"tg-linked\"><i data-lucide=\"circle-check\"></i><span>Telegram مرتبط${data.username ? ` (@${esc(data.username)})` : ''}</span></div>`;
  } else {
    box.innerHTML = `<button id=\"connectTelegram\" class=\"telegram-connect\" type=\"button\"><i data-lucide=\"send\"></i><span>ربط حسابي مع Telegram</span></button><small class=\"telegram-hint\">اضغط ثم افتح البوت وأرسل Start لربط الحساب.</small>`;
    $('connectTelegram')?.addEventListener('click', createTelegramLink);
  }
  initIcons();
}

async function createTelegramLink() {
  const { data: { user } } = await db.auth.getUser();
  if (!user) return openAuth('سجّل الدخول أولًا لربط Telegram.');
  const token = crypto.randomUUID();
  const expires = new Date(Date.now() + 15 * 60 * 1000).toISOString();
  const { error } = await db.from('telegram_link_tokens').insert({ token, user_id: user.id, expires_at: expires });
  if (error) {
    return setMessage($('authMsg'), 'تعذر إنشاء رابط Telegram. حاول مرة أخرى.', 'error');
  }
  const url = `https://t.me/FENK_DZ_Bot?start=${encodeURIComponent(token)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
  setMessage($('authMsg'), 'تم فتح بوت FENK DZ. اضغط Start لإتمام الربط.', 'success');
  setTimeout(() => refreshTelegramLinkUI(user), 1500);
}

document.querySelectorAll('[data-scroll]').forEach(el => el.addEventListener('click', () => { const target=document.querySelector(el.dataset.scroll); target?.scrollIntoView({behavior:'smooth',block:'start'}); }));
$('searchBtn')?.addEventListener('click', () => { const q=$('siteSearch').value.trim(); if(q){ if(/^https?:\/\//i.test(q)) $('productUrl').value=q; else setMessage($('orderMsg'), 'ألصق رابط المنتج أو أرسل صورة المنتج.', 'error'); $('order').scrollIntoView({behavior:'smooth'}); } });
$('siteSearch')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') $('searchBtn')?.click(); });
$('countryBtn')?.addEventListener('click', () => document.getElementById('order')?.scrollIntoView({behavior:'smooth'}));
$('closeMarket')?.addEventListener('click', () => $('marketModal')?.classList.remove('show'));
$('marketModal')?.addEventListener('click', e => { if(e.target === $('marketModal')) $('marketModal').classList.remove('show'); });
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  $('authModal')?.classList.remove('show');
  $('marketModal')?.classList.remove('show');
  $('adminPanel')?.classList.remove('show');
  $('profileModal')?.classList.remove('show');
});

function updateAuthUI(user) {
  const label = user ? `مسجل: ${user.user_metadata?.full_name || user.user_metadata?.email || 'Google'}` : 'تسجيل الدخول';
  if ($('accountBtn')) $('accountBtn').title = label;
  if ($('mobileAccount')) $('mobileAccount').title = label;
}

async function uploadProductImage(userId) {
  const input = $('productImage');
  const file = input?.files?.[0];
  if (!file) return null;
  const allowed = ['image/jpeg','image/png','image/webp'];
  if (!allowed.includes(file.type)) throw new Error('الصورة يجب أن تكون JPG أو PNG أو WEBP.');
  if (file.size > 5 * 1024 * 1024) throw new Error('حجم الصورة يجب ألا يتجاوز 5MB.');
  const mimeExt = { 'image/jpeg':'jpg', 'image/png':'png', 'image/webp':'webp' };
  const ext = mimeExt[file.type] || 'jpg';
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await db.storage.from('product-images').upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw error;
  return path;
}

$('sendOrder')?.addEventListener('click', async () => {
  setMessage($('orderMsg'), '');
  const { data: { user } } = await db.auth.getUser();
  if (!user) return openAuth('سجّل الدخول باستخدام Google أولًا لإرسال الطلب.');
  if (!(await ensureProfileComplete(user, true))) return setMessage($('orderMsg'), 'أكمل بيانات الاسم واللقب ورقم الهاتف أولًا.', 'error');

  const productUrl = $('productUrl').value.trim();
  if (!productUrl && !$('productImage')?.files?.length) {
    return setMessage($('orderMsg'), 'أدخل رابط المنتج أو أرسل صورة المنتج.', 'error');
  }
  if (productUrl && !/^https?:\/\//i.test(productUrl)) {
    return setMessage($('orderMsg'), 'رابط المنتج يجب أن يبدأ بـ https:// أو http://', 'error');
  }

  const button = $('sendOrder');
  button.disabled = true;
  button.textContent = 'جارٍ إرسال الطلب…';
  try {
    const imagePath = await uploadProductImage(user.id);
    const payload = {
      user_id: user.id,
      product_url: productUrl || null,
      product_image_url: imagePath,
      source_site: selectedSite,
      quantity: qty
    };
    const { data, error } = await db.from('orders').insert(payload).select('id,order_number').single();
    if (error) throw error;
    setMessage($('orderMsg'), `تم إرسال الطلب #${data.order_number}. سنراجع المنتج ونرسل لك السعر.`, 'success');
    $('productUrl').value = '';
    $('productImage').value = '';
    if ($('imagePreview')) { $('imagePreview').removeAttribute('src'); $('imagePreview').classList.remove('show'); }
    if ($('imageName')) $('imageName').textContent = '';
    qty = 1; $('qty').textContent = '1';
  } catch (error) {
    console.error(error);
    setMessage($('orderMsg'), error?.message || 'تعذر إرسال الطلب. حاول مرة أخرى.', 'error');
  } finally {
    button.disabled = false;
    button.textContent = 'إرسال الطلب ➤';
  }
});

async function isAdmin() {
  const { data: { user } } = await db.auth.getUser();
  if (!user) return false;
  const { data, error } = await db.from('admins').select('user_id').eq('user_id', user.id).maybeSingle();
  if (error) { console.warn('Admin check:', error.message); return false; }
  return !!data;
}

async function openAdmin() {
  if (!(await isAdmin())) return openAuth('هذا الحساب ليس Admin.');
  closeAuth();
  $('adminPanel').classList.add('show');
  const { data: { user } } = await db.auth.getUser();
  $('adminEmail').textContent = user?.email || '';
  await refreshAdmin();
}
$('adminBtn')?.addEventListener('click', openAdmin);
$('closeAdmin')?.addEventListener('click', () => $('adminPanel').classList.remove('show'));

document.querySelectorAll('.admin-tab').forEach((button) => button.addEventListener('click', () => {
  document.querySelectorAll('.admin-tab').forEach((b) => b.classList.remove('active'));
  document.querySelectorAll('.admin-view').forEach((v) => v.classList.add('hidden'));
  button.classList.add('active');
  $('tab-' + button.dataset.tab)?.classList.remove('hidden');
}));

function orderRow(order) {
  const label = order.product_url || 'صورة المنتج';
  return `<div class="mini-order"><b>#${esc(order.order_number)}</b><span>${esc(order.source_site || '—')}</span><span>${esc(label).slice(0, 80)}</span><strong>${esc(statusNames[order.status] || order.status || '—')}</strong></div>`;
}
function renderOrders(orders) {
  const query = ($('orderSearch')?.value || '').trim().toLowerCase();
  const filter = $('statusFilter')?.value || '';
  const rows = orders.filter((o) => {
    const number = String(o.order_number || '').toLowerCase();
    return (!query || number.includes(query)) && (!filter || o.status === filter);
  });
  if (!rows.length) { $('ordersTable').innerHTML = '<div class="empty">لا توجد طلبات مطابقة.</div>'; return; }
  $('ordersTable').innerHTML = `<div class="table-wrap"><table class="admin-table"><thead><tr><th>الطلب</th><th>الموقع</th><th>الكمية</th><th>السعر</th><th>الحالة</th><th>التاريخ</th></tr></thead><tbody>${rows.map((o) => `<tr><td>#${esc(o.order_number)}</td><td>${esc(o.source_site)}</td><td>${Number(o.quantity) || 1}</td><td>${formatMoney(o.total_price, o.currency)}</td><td><select class="status-select" data-order-id="${esc(o.id)}">${Object.entries(statusNames).map(([key,label]) => `<option value="${key}" ${key === o.status ? 'selected' : ''}>${label}</option>`).join('')}</select></td><td>${formatDate(o.created_at)}</td></tr>`).join('')}</tbody></table></div>`;
  document.querySelectorAll('.status-select').forEach((select) => select.addEventListener('change', () => changeStatus(select.dataset.orderId, select.value)));
}

async function refreshAdmin() {
  const [ordersResult, usersResult, bannersResult] = await Promise.all([
    db.from('orders').select('*').order('created_at', { ascending: false }),
    db.from('profiles').select('*').order('created_at', { ascending: false }),
    db.from('banners').select('*').order('sort_order', { ascending: true })
  ]);
  if (ordersResult.error) { console.error(ordersResult.error); $('recentOrders').innerHTML = '<div class="empty">تعذر تحميل الطلبات.</div>'; return; }
  cachedOrders = ordersResult.data || [];
  $('sTotal').textContent = cachedOrders.length;
  $('sNew').textContent = cachedOrders.filter((o) => o.status === 'received').length;
  $('sPaid').textContent = cachedOrders.filter((o) => o.status === 'paid').length;
  $('sDone').textContent = cachedOrders.filter((o) => o.status === 'delivered').length;
  $('recentOrders').innerHTML = cachedOrders.length ? cachedOrders.slice(0, 8).map(orderRow).join('') : '<div class="empty">لا توجد طلبات بعد.</div>';
  initIcons();
  renderOrders(cachedOrders);

  const users = usersResult.data || [];
  $('usersTable').innerHTML = users.length ? `<div class="table-wrap"><table class="admin-table"><thead><tr><th>الاسم</th><th>اللقب</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>${users.map((u) => `<tr><td>${esc(u.first_name || u.full_name || '—')}</td><td>${esc(u.last_name || '—')}</td><td>${esc(u.phone || '—')}</td><td>${formatDate(u.created_at)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا يوجد مستخدمون بعد.</div>';

  const banners = bannersResult.data || [];
  $('bannersList').innerHTML = banners.length ? banners.map((b) => `<div class="banner-row"><b>${esc(b.title || 'بنر')}</b><span>${b.active ? 'فعال' : 'متوقف'}</span></div>`).join('') : '<div class="empty">لا توجد بنرات بعد.</div>';
}

async function changeStatus(id, status) {
  if (!id || !status) return;
  const { data, error } = await db.from('orders').update({ status }).eq('id', id).select().single();
  if (error) return alert(error.message);
  await db.from('order_status_history').insert({ order_id: id, status, note: 'تم التحديث من لوحة الإدارة' });
  // notifications are created by the database trigger; do not duplicate them here.
  await notifyTelegram(data);
  await refreshAdmin();
}

async function notifyTelegram(order) {
  try {
    const { error } = await db.functions.invoke('telegram-notify', { body: { order_id: order.id } });
    if (error) console.warn('Telegram:', error.message);
  } catch (e) { console.warn('Telegram:', e); }
}

$('orderSearch')?.addEventListener('input', () => renderOrders(cachedOrders));
$('statusFilter')?.addEventListener('change', () => renderOrders(cachedOrders));

$('telegramTest')?.addEventListener('click', async () => {
  const msg = $('telegramMsg');
  setMessage(msg, 'جارٍ اختبار Telegram…', 'success');
  const { data: { user } } = await db.auth.getUser();
  if (!user || !(await isAdmin())) return setMessage(msg, 'يجب تسجيل الدخول بحساب Admin.', 'error');
  const sample = cachedOrders[0];
  if (!sample) return setMessage(msg, 'أنشئ طلبًا أولًا لاختبار Telegram.', 'error');
  try {
    const { error } = await db.functions.invoke('telegram-notify', { body: { order_id: sample.id } });
    if (error) throw error;
    setMessage(msg, 'تم إرسال اختبار Telegram بنجاح ✓', 'success');
  } catch (e) { setMessage(msg, e?.message || 'تعذر إرسال اختبار Telegram.', 'error'); }
});

$('newsletterSubscribe')?.addEventListener('click', () => {
  const input = $('newsletterEmail');
  const value = input?.value.trim() || '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return alert('أدخل بريدًا إلكترونيًا صحيحًا.');
  alert('تم تسجيل بريدك بنجاح. شكرًا لثقتك في FENK DZ.');
  input.value = '';
});

// Keep admin state correct after login/logout and provide realtime refresh for admins.
db.auth.onAuthStateChange((_event, session) => {
  updateAuthUI(session?.user || null);
  if (session) {
    setTimeout(async () => {
      await refreshTelegramLinkUI(session.user);
      const admin = await isAdmin();
      if ($('adminBtn')) $('adminBtn').style.display = admin ? 'block' : 'none';
      if (!(await ensureProfileComplete(session.user, false))) await openProfileModal(session.user);
    }, 0);
  } else {
    if ($('adminBtn')) $('adminBtn').style.display = 'none';
    if ($('telegramLinkBox')) $('telegramLinkBox').innerHTML = '';
  }
});

(async () => {
  const { data: { session } } = await db.auth.getSession();
  updateAuthUI(session?.user || null);
  if (session) {
    await refreshTelegramLinkUI(session.user);
    if (await isAdmin()) $('adminBtn').style.display = 'block';
  }
})();

// Basic runtime diagnostics for the deployment.
document.querySelectorAll('video').forEach(v => v.addEventListener('error', () => v.closest('.video-card')?.classList.add('video-fallback')));
window.FENK = { version: 'V11-GOOGLE-PROFILE-MESSAGES', supabaseUrl: SUPABASE_URL };
