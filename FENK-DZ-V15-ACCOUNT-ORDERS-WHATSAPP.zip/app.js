const SUPABASE_URL = 'https://zfnlgzwvvytophdxtoks.supabase.co';
const FENK_WHATSAPP='213778939292';
const SUPABASE_KEY = 'sb_publishable_d8kkB1Nyfjlx8LD9LQ5Ogw_WZPbxL5k';
const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const $ = (id) => document.getElementById(id);

function initIcons(){try{window.lucide?.createIcons({attrs:{'stroke-width':2.1}})}catch(e){console.warn('Icons:',e)}}
function setMessage(el,text,type=''){if(!el)return;el.textContent=text||'';el.className=type}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function formatDate(v){try{return new Date(v).toLocaleString('ar-DZ')}catch{return '—'}}
function formatMoney(v,c='DZD'){const n=Number(v);return Number.isFinite(n)?`${n.toLocaleString('ar-DZ')} ${c==='DZD'?'دج':c}`:'بانتظار التسعير'}
function openAuth(message=''){ $('authModal')?.classList.add('show'); if(message)setMessage($('authMsg'),message,'error') }
function closeAuth(){ $('authModal')?.classList.remove('show') }

let qty=1, selectedSite='AliExpress', cachedOrders=[], selectedOrderId=null;
const statusNames={received:'قيد المعالجة',price_confirmation:'تم تحديد السعر',awaiting_payment:'بانتظار الدفع',payment_proof_received:'تم استلام وصل الدفع',paid:'تم تأكيد الدفع',shipping:'قيد التوصيل',delivered:'تم التسليم',cancelled:'ملغى'};

async function getProfile(user){
  if(!user)return null;
  const {data,error}=await db.from('profiles').select('id,first_name,last_name,full_name,phone,avatar_url').eq('id',user.id).maybeSingle();
  if(error){console.warn('Profile:',error.message);return null} return data||null;
}
function profileValues(user,profile=null){
  const m=user?.user_metadata||{}, full=profile?.full_name||m.full_name||'';
  const p=String(full).trim().split(/\s+/).filter(Boolean);
  return {first_name:profile?.first_name||m.first_name||p.shift()||'',last_name:profile?.last_name||m.last_name||p.join(' ')||'',phone:profile?.phone||m.phone||''};
}
async function fillOrderContact(user){
  const p=await getProfile(user),v=profileValues(user,p);
  ['orderFirstName','orderLastName','orderPhone'].forEach((id,i)=>{if($(id)&&!$(id).value)$(id).value=[v.first_name,v.last_name,v.phone][i]||''});
}
async function ensureProfileComplete(user,show=true){
  const p=await getProfile(user),v=profileValues(user,p),ok=!!(v.first_name.trim()&&v.last_name.trim()&&v.phone.trim());
  if(!ok&&show)await openProfileModal(user); return ok;
}
async function openProfileModal(user=null,message=''){
  const current=user||(await db.auth.getUser()).data.user;if(!current)return openAuth('سجّل الدخول أولًا باستخدام Google.');
  const p=await getProfile(current),v=profileValues(current,p);
  $('firstName').value=v.first_name;$('lastName').value=v.last_name;$('phone').value=v.phone;$('profileModal')?.classList.add('show');
  if(message)setMessage($('profileMsg'),message,'error');
}

$('googleLogin')?.addEventListener('click',async()=>{
  const b=$('googleLogin');if(b)b.disabled=true;setMessage($('authMsg'),'جارٍ فتح تسجيل الدخول بحساب Google…','success');
  try{
    // Preserve the GitHub Pages sub-path; using origin alone would return to the wrong page.
    const redirectTo=`${location.origin}${location.pathname}`;
    const {error}=await db.auth.signInWithOAuth({provider:'google',options:{redirectTo,queryParams:{prompt:'select_account'}}});
    if(error)setMessage($('authMsg'),error.message,'error');
  }catch(e){setMessage($('authMsg'),e?.message||'تعذر بدء تسجيل الدخول عبر Google.','error')}finally{if(b)b.disabled=false}
});

$('profileForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('انتهت الجلسة. سجّل الدخول باستخدام Google.');
  const firstName=$('firstName').value.trim(),lastName=$('lastName').value.trim(),phone=$('phone').value.trim();
  if(!firstName||!lastName||!phone)return setMessage($('profileMsg'),'أكمل الاسم واللقب ورقم الهاتف.','error');
  if(!/^[0-9+()\s-]{8,20}$/.test(phone))return setMessage($('profileMsg'),'أدخل رقم هاتف صحيح.','error');
  const b=$('saveProfile');b.disabled=true;b.textContent='جارٍ الحفظ…';
  try{
    const fullName=`${firstName} ${lastName}`.trim();
    const {error}=await db.from('profiles').upsert({id:user.id,first_name:firstName,last_name:lastName,full_name:fullName,phone,avatar_url:user.user_metadata?.avatar_url||null,updated_at:new Date().toISOString()},{onConflict:'id'});if(error)throw error;
    await db.auth.updateUser({data:{first_name:firstName,last_name:lastName,full_name:fullName,phone}});
    setMessage($('profileMsg'),'تم حفظ بياناتك بنجاح ✓','success');
    $('orderFirstName').value=firstName;$('orderLastName').value=lastName;$('orderPhone').value=phone;
    setTimeout(()=>$('profileModal')?.classList.remove('show'),450);
  }catch(e){console.error(e);setMessage($('profileMsg'),e?.message||'تعذر حفظ البيانات. حاول مرة أخرى.','error')}finally{b.disabled=false;b.textContent='حفظ البيانات'}
});

// Product image
const imageInput=$('productImage');
imageInput?.addEventListener('change',()=>{
  const file=imageInput.files?.[0];if(!file){$('imagePreview')?.classList.remove('show');if($('imageName'))$('imageName').textContent='';return}
  if(!['image/jpeg','image/png','image/webp'].includes(file.type)){imageInput.value='';return setMessage($('orderMsg'),'اختر صورة JPG أو PNG أو WEBP فقط.','error')}
  if(file.size>5*1024*1024){imageInput.value='';return setMessage($('orderMsg'),'حجم الصورة يجب ألا يتجاوز 5MB.','error')}
  $('imageName').textContent=file.name;$('imagePreview').src=URL.createObjectURL(file);$('imagePreview').classList.add('show');setMessage($('orderMsg'),'تم اختيار الصورة بنجاح ✓','success');
});

document.querySelectorAll('[data-scroll]').forEach(el=>el.addEventListener('click',()=>document.querySelector(el.dataset.scroll)?.scrollIntoView({behavior:'smooth'})));
$('searchBtn')?.addEventListener('click',()=>{const q=$('siteSearch')?.value.trim()||'';if(/^https?:\/\//i.test(q)){$('productUrl').value=q;document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}else if(q){setMessage($('orderMsg'),'ألصق رابط المنتج أو اكتب رابطًا يبدأ بـ https://.','error');document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}});
$('siteSearch')?.addEventListener('keydown',e=>{if(e.key==='Enter')$('searchBtn')?.click()});
$('countryBtn')?.addEventListener('click',()=>document.querySelector('#order')?.scrollIntoView({behavior:'smooth'}));
$('closeMarket')?.addEventListener('click',()=>$('marketModal')?.classList.remove('show'));
$('marketModal')?.addEventListener('click',e=>{if(e.target===$('marketModal'))$('marketModal').classList.remove('show')});

for(const b of document.querySelectorAll('#sites button'))b.addEventListener('click',()=>{document.querySelectorAll('#sites button').forEach(x=>x.classList.remove('active'));b.classList.add('active');selectedSite=b.dataset.site||'موقع آخر'});
$('plus')?.addEventListener('click',()=>{$('qty').textContent=String(++qty)});
$('minus')?.addEventListener('click',()=>{$('qty').textContent=String(qty=Math.max(1,qty-1))});

async function handleAccountClick(){const {data:{user}}=await db.auth.getUser();if(user)return openAccountModal(user);openAuth()}
$('accountBtn')?.addEventListener('click',handleAccountClick);$('mobileAccount')?.addEventListener('click',handleAccountClick);

function renderTimeline(status){
  const steps=[
    ['received','✓','تم استلام الطلب'],
    ['price_confirmation','💰','تم تحديد السعر'],
    ['awaiting_payment','💳','بانتظار الدفع'],
    ['payment_proof_received','🧾','تم استلام وصل الدفع'],
    ['paid','✓','تم تأكيد الدفع'],
    ['shipping','🚚','قيد التوصيل'],
    ['delivered','🏠','تم التسليم']
  ];
  if(status==='cancelled')return `<div class="order-timeline cancelled"><div class="timeline-current">✕ ملغى</div></div>`;
  const current=Math.max(0,steps.findIndex(x=>x[0]===status));
  return `<div class="order-timeline">${steps.map((x,i)=>`<div class="timeline-step ${i<current?'done':''} ${i===current?'current':''}"><span>${i<=current?x[1]:'○'}</span><small>${x[2]}</small></div>`).join('')}</div>`;
}

async function openCustomerOrders(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض طلباتك.');
  $('customerOrdersList').innerHTML='<div class="empty">جارٍ تحميل الطلبات…</div>';$('customerOrdersModal')?.classList.add('show');
  const {data,error}=await db.from('orders').select('id,order_number,status,source_site,product_name,product_info,quantity,total_price,currency,created_at').eq('user_id',user.id).order('created_at',{ascending:false});
  if(error)return $('customerOrdersList').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';
  $('customerOrdersList').innerHTML=data?.length?data.map(o=>`<article class="notification-item order-card" data-order-id="${esc(o.id)}"><div class="order-card-head"><b>#${esc(o.order_number)}</b><strong>${esc(statusNames[o.status]||'قيد المعالجة')}</strong></div><p>${esc(o.product_name||o.product_info||o.source_site||'طلب منتج')} • الكمية: ${Number(o.quantity)||1}</p><small>${formatMoney(o.total_price,o.currency)} • ${formatDate(o.created_at)}</small>${renderTimeline(o.status)}</article>`).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';
  initIcons();
}
$('closeCustomerOrders')?.addEventListener('click',()=>$('customerOrdersModal')?.classList.remove('show'));
$('customerOrdersModal')?.addEventListener('click',e=>{if(e.target===$('customerOrdersModal'))$('customerOrdersModal').classList.remove('show')});

async function openMessages(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا للتواصل مع FENK.');
  $('messagesList').innerHTML='<div class="empty">جارٍ تحميل المحادثة…</div>';$('messagesModal')?.classList.add('show');
  await loadCustomerMessages(user.id);
}
async function loadCustomerMessages(userId){
  const {data,error}=await db.from('support_messages').select('id,message,sender_role,is_read,created_at,order_id').eq('user_id',userId).order('created_at',{ascending:true}).limit(100);
  if(error)return setMessage($('messageMsg'),'تعذر تحميل الرسائل.','error');
  $('messagesList').innerHTML=data?.length?data.map(m=>`<div class="chat-bubble ${m.sender_role==='customer'?'mine':'admin-msg'}"><p>${esc(m.message)}</p><small>${m.sender_role==='customer'?'أنت':'FENK'} • ${formatDate(m.created_at)}</small></div>`).join(''):'<div class="empty">لا توجد رسائل بعد. اكتب رسالتك وسيرد عليك فريق FENK.</div>';
  $('messagesList').scrollTop=$('messagesList').scrollHeight;
}
$('messageForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');
  const input=$('messageInput'),msg=input?.value.trim();if(!msg)return setMessage($('messageMsg'),'اكتب رسالتك أولًا.','error');
  const b=e.submitter||$('messageForm button');b.disabled=true;setMessage($('messageMsg'),'جارٍ إرسال الرسالة…','success');
  try{const {error}=await db.from('support_messages').insert({user_id:user.id,sender_role:'customer',message:msg});if(error)throw error;input.value='';setMessage($('messageMsg'),'تم إرسال رسالتك ✓','success');await loadCustomerMessages(user.id);}
  catch(err){setMessage($('messageMsg'),err?.message||'تعذر إرسال الرسالة.','error')}finally{b.disabled=false}
});
$('messagesBtn')?.addEventListener('click',openMessages);$('mobileMessages')?.addEventListener('click',openMessages);
$('closeMessages')?.addEventListener('click',()=>$('messagesModal')?.classList.remove('show'));
$('messagesModal')?.addEventListener('click',e=>{if(e.target===$('messagesModal'))$('messagesModal').classList.remove('show')});

async function openNotifications(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض الإشعارات.');
  $('notificationsList').innerHTML='<div class="empty">جارٍ تحميل الإشعارات…</div>';$('notificationsModal')?.classList.add('show');
  const {data,error}=await db.from('notifications').select('id,title,message,is_read,order_id,created_at').eq('user_id',user.id).order('created_at',{ascending:false}).limit(50);
  if(error)return $('notificationsList').innerHTML='<div class="empty">تعذر تحميل الإشعارات.</div>';
  $('notificationsList').innerHTML=data?.length?data.map(n=>`<article class="notification-item ${n.is_read?'':'unread'}"><div class="notification-title"><i data-lucide="bell"></i><b>${esc(n.title)}</b></div><p>${esc(n.message)}</p><small>${formatDate(n.created_at)}</small></article>`).join(''):'<div class="empty">لا توجد إشعارات بعد.</div>';
  const ids=(data||[]).filter(n=>!n.is_read).map(n=>n.id);if(ids.length)await db.from('notifications').update({is_read:true}).in('id',ids);updateNotificationBadge(user.id);initIcons();
}
$('notificationsBtn')?.addEventListener('click',openNotifications);
$('closeNotifications')?.addEventListener('click',()=>$('notificationsModal')?.classList.remove('show'));
$('notificationsModal')?.addEventListener('click',e=>{if(e.target===$('notificationsModal'))$('notificationsModal').classList.remove('show')});

async function updateNotificationBadge(userId=null){
  if(!userId){const {data:{user}}=await db.auth.getUser();userId=user?.id}
  const badge=$('notificationBadge');if(!badge)return;
  if(!userId){badge.textContent='0';badge.style.display='none';return}
  const {count}=await db.from('notifications').select('id',{count:'exact',head:true}).eq('user_id',userId).eq('is_read',false);
  const n=Number(count||0);badge.textContent=n>99?'99+':String(n);badge.style.display=n?'flex':'none';
}
$('closeProfile')?.addEventListener('click',()=>$('profileModal')?.classList.remove('show'));
$('profileModal')?.addEventListener('click',e=>{if(e.target===$('profileModal'))$('profileModal').classList.remove('show')});
$('closeAuth')?.addEventListener('click',closeAuth);$('authModal')?.addEventListener('click',e=>{if(e.target===$('authModal'))closeAuth()});

async function uploadProductImage(userId){
  const file=imageInput?.files?.[0];if(!file)return null;
  const ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[file.type];
  if(!ext)throw new Error('الصورة يجب أن تكون JPG أو PNG أو WEBP.');if(file.size>5*1024*1024)throw new Error('حجم الصورة يجب ألا يتجاوز 5MB.');
  const path=`${userId}/${crypto.randomUUID()}.${ext}`;const {error}=await db.storage.from('product-images').upload(path,file,{contentType:file.type,upsert:false});if(error)throw error;return path;
}

async function sendTelegramOrder(orderId){
  try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:orderId,event:'created'}});if(error)console.warn('Telegram:',error.message)}catch(e){console.warn('Telegram:',e)}
}

$('sendOrder')?.addEventListener('click',async()=>{
  setMessage($('orderMsg'),'');const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول باستخدام Google أولًا لإرسال الطلب.');
  const first=$('orderFirstName').value.trim(),last=$('orderLastName').value.trim(),phone=$('orderPhone').value.trim(),wilaya=$('orderWilaya').value.trim(),commune=$('orderCommune').value.trim(),postal=$('orderPostalCode').value.trim(),address=$('orderAddress').value.trim(),url=$('productUrl').value.trim(),productName=$('productName').value.trim(),info=$('productInfo').value.trim();
  if(!first||!last||!phone||!wilaya||!commune||!address)return setMessage($('orderMsg'),'أكمل الاسم واللقب والهاتف والولاية والبلدية والعنوان.','error');
  if(!/^[0-9+()\s-]{8,20}$/.test(phone))return setMessage($('orderMsg'),'أدخل رقم هاتف صحيح.','error');
  if(!url&&!imageInput?.files?.length)return setMessage($('orderMsg'),'أدخل رابط المنتج أو أرسل صورة المنتج.','error');
  if(url&&!/^https?:\/\//i.test(url))return setMessage($('orderMsg'),'رابط المنتج يجب أن يبدأ بـ https:// أو http://','error');
  const b=$('sendOrder');b.disabled=true;b.textContent='جارٍ إرسال الطلب…';
  try{
    const fullName=`${first} ${last}`.trim();
    const profileError=(await db.from('profiles').upsert({id:user.id,first_name:first,last_name:last,full_name:fullName,phone,avatar_url:user.user_metadata?.avatar_url||null,updated_at:new Date().toISOString()},{onConflict:'id'})).error;if(profileError)throw profileError;
    const imagePath=await uploadProductImage(user.id);
    const payload={user_id:user.id,product_url:url||null,product_name:productName||null,product_info:info||null,product_image_url:imagePath,source_site:selectedSite,quantity:qty,customer_first_name:first,customer_last_name:last,customer_phone:phone,wilaya,commune,address,postal_code:postal||null,status:'received'};
    const {data,error}=await db.from('orders').insert(payload).select('id,order_number').single();if(error)throw error;
    await sendTelegramOrder(data.id);
    setMessage($('orderMsg'),`✅ تم إرسال طلبك بنجاح\n📦 طلبك قيد المعالجة\n💬 سنتواصل معك عبر WhatsApp لتأكيد السعر والدفع.\nرقم الطلب: #${data.order_number}`,'success');
    const saved=getSavedAddresses(); const currentAddr={id:crypto.randomUUID(),label:'العنوان الرئيسي',first_name:first,last_name:last,full_name,phone,wilaya,commune,address,postal_code:postal||'',primary:saved.length===0||saved.every(x=>!x.primary)}; let merged=saved.filter(x=>!(x.primary&&currentAddr.primary)); if(currentAddr.primary)merged=merged.map(x=>({...x,primary:false})); merged.unshift(currentAddr); setSavedAddresses(merged);
    $('productUrl').value='';$('productName').value='';$('productInfo').value='';imageInput.value='';$('imagePreview')?.classList.remove('show');$('imageName').textContent='';qty=1;$('qty').textContent='1';
  }catch(e){console.error('Order:',e);setMessage($('orderMsg'),e?.message||'تعذر إرسال الطلب. حاول مرة أخرى.','error')}finally{b.disabled=false;b.textContent='إرسال الطلب ➤'}
});

async function isAdmin(){const {data:{user}}=await db.auth.getUser();if(!user)return false;const {data,error}=await db.from('admins').select('user_id').eq('user_id',user.id).maybeSingle();if(error){console.warn('Admin:',error.message);return false}return !!data}
async function openAdmin(){if(!(await isAdmin()))return openAuth('هذا الحساب ليس Admin.');closeAuth();$('adminPanel').classList.add('show');const {data:{user}}=await db.auth.getUser();$('adminEmail').textContent=user?.email||'';await refreshAdmin();await refreshAdminMessages();}
$('adminBtn')?.addEventListener('click',openAdmin);$('closeAdmin')?.addEventListener('click',()=>$('adminPanel').classList.remove('show'));
document.querySelectorAll('.admin-tab').forEach(b=>b.addEventListener('click',async()=>{document.querySelectorAll('.admin-tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.admin-view').forEach(x=>x.classList.add('hidden'));b.classList.add('active');$('tab-'+b.dataset.tab)?.classList.remove('hidden');if(b.dataset.tab==='messages')await refreshAdminMessages();}));

function orderRow(o){return `<div class="mini-order"><b>#${esc(o.order_number)}</b><span>${esc(o.customer_first_name||'')} ${esc(o.customer_last_name||'')}</span><span>${esc(o.customer_phone||'—')}</span><strong>${esc(statusNames[o.status]||o.status||'—')}</strong><button type="button" class="detail-btn" data-order-id="${esc(o.id)}">فتح الطلب</button></div>`}
function renderOrders(orders){
  const q=($('orderSearch')?.value||'').trim().toLowerCase(),f=$('statusFilter')?.value||'';
  const rows=orders.filter(o=>(!q||String(o.order_number||'').toLowerCase().includes(q)||String(o.customer_phone||'').toLowerCase().includes(q))&&(!f||o.status===f));
  if(!rows.length){$('ordersTable').innerHTML='<div class="empty">لا توجد طلبات مطابقة.</div>';return}
  $('ordersTable').innerHTML=`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الطلب</th><th>العميل</th><th>الهاتف</th><th>الموقع</th><th>الكمية</th><th>السعر</th><th>الحالة</th><th>التاريخ</th><th></th></tr></thead><tbody>${rows.map(o=>`<tr><td>#${esc(o.order_number)}</td><td>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim()||'—')}</td><td>${esc(o.customer_phone||'—')}</td><td>${esc(o.source_site||'—')}</td><td>${Number(o.quantity)||1}</td><td>${formatMoney(o.total_price,o.currency)}</td><td>${esc(statusNames[o.status]||o.status||'—')}</td><td>${formatDate(o.created_at)}</td><td><button class="detail-btn" data-order-id="${esc(o.id)}">فتح</button></td></tr>`).join('')}</tbody></table></div>`;
  document.querySelectorAll('.detail-btn').forEach(b=>b.addEventListener('click',()=>openOrderDetail(b.dataset.orderId)));
}

async function refreshAdminMessages(){
  const box=$('adminMessagesList');if(!box)return;
  box.innerHTML='<div class="empty">جارٍ تحميل رسائل العملاء…</div>';
  const {data,error}=await db.from('support_messages').select('id,user_id,message,sender_role,is_read,created_at,order_id').order('created_at',{ascending:false}).limit(200);
  if(error)return box.innerHTML='<div class="empty">تعذر تحميل رسائل العملاء.</div>';
  const groups=new Map();for(const m of data||[]){if(!groups.has(m.user_id))groups.set(m.user_id,[]);groups.get(m.user_id).push(m)}
  const ids=[...groups.keys()];let profiles=[];if(ids.length){const r=await db.from('profiles').select('id,first_name,last_name,phone').in('id',ids);profiles=r.data||[]}
  const pm=new Map(profiles.map(x=>[x.id,x]));
  box.innerHTML=ids.length?[...groups.entries()].map(([uid,msgs])=>{const p=pm.get(uid)||{};const last=msgs[0];return `<article class="admin-chat-card"><div class="admin-chat-head"><div><b>${esc(`${p.first_name||''} ${p.last_name||''}`.trim()||'عميل')}</b><small>${esc(p.phone||'')}</small></div><span>${formatDate(last.created_at)}</span></div><div class="admin-chat-thread">${msgs.slice().reverse().map(m=>`<div class="chat-bubble ${m.sender_role==='admin'?'admin-msg':'mine'}"><p>${esc(m.message)}</p><small>${m.sender_role==='admin'?'FENK':'العميل'} • ${formatDate(m.created_at)}</small></div>`).join('')}</div><form class="admin-reply-form" data-user-id="${esc(uid)}"><textarea rows="2" maxlength="4000" placeholder="اكتب ردًا للعميل..."></textarea><button class="send" type="submit">إرسال الرد</button></form></article>`}).join(''):'<div class="empty">لا توجد رسائل من العملاء بعد.</div>';
  box.querySelectorAll('.admin-reply-form').forEach(form=>form.addEventListener('submit',async e=>{e.preventDefault();const textarea=form.querySelector('textarea'),message=textarea.value.trim(),uid=form.dataset.userId;if(!message)return;const btn=form.querySelector('button');btn.disabled=true;try{const {error}=await db.from('support_messages').insert({user_id:uid,sender_role:'admin',message});if(error)throw error;textarea.value='';await refreshAdminMessages();}catch(err){alert(err?.message||'تعذر إرسال الرد.')}finally{btn.disabled=false}}));
  initIcons();
}

async function refreshAdmin(){
  const [or,ur,br]=await Promise.all([db.from('orders').select('*').order('created_at',{ascending:false}),db.from('profiles').select('*').order('created_at',{ascending:false}),db.from('banners').select('*').order('sort_order',{ascending:true})]);
  if(or.error){$('recentOrders').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';return}
  cachedOrders=or.data||[];$('sTotal').textContent=cachedOrders.length;$('sNew').textContent=cachedOrders.filter(o=>['received','checking'].includes(o.status)).length;$('sPaid').textContent=cachedOrders.filter(o=>o.status==='paid').length;$('sDone').textContent=cachedOrders.filter(o=>o.status==='delivered').length;$('recentOrders').innerHTML=cachedOrders.length?cachedOrders.slice(0,8).map(orderRow).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';renderOrders(cachedOrders);initIcons();
  const users=ur.data||[];$('usersTable').innerHTML=users.length?`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الاسم</th><th>اللقب</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>${users.map(u=>`<tr><td>${esc(u.first_name||'—')}</td><td>${esc(u.last_name||'—')}</td><td>${esc(u.phone||'—')}</td><td>${formatDate(u.created_at)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا يوجد مستخدمون بعد.</div>';
  const banners=br.data||[];$('bannersList').innerHTML=banners.length?banners.map(b=>`<div class="banner-row"><b>${esc(b.title||'بنر')}</b><span>${b.active?'فعال':'متوقف'}</span></div>`).join(''):'<div class="empty">لا توجد بنرات بعد.</div>';
}

async function openOrderDetail(id){
  const order=cachedOrders.find(o=>o.id===id);if(!order)return;selectedOrderId=id;
  $('detailOrderNumber').textContent=`#${order.order_number}`;$('detailTotalPrice').value=order.total_price??'';$('detailShipping').value=order.shipping_fee??0;$('detailService').value=order.service_fee??0;$('detailStatus').value=statusNames[order.status]?order.status:'received';$('detailPaymentInfo').value=order.payment_info||'';$('detailAdminNote').value=order.admin_note||'';
  const wa=normalizeWhatsApp(order.customer_phone||'');$('whatsappOrder').href=wa?`https://wa.me/${wa}?text=${encodeURIComponent(`مرحبًا ${order.customer_first_name||''}، معك FENK DZ بخصوص طلبك #${order.order_number}.`)}`:'#';
  $('orderDetailContent').innerHTML=`<div class="detail-grid"><div><b>الاسم واللقب</b><span>${esc(`${order.customer_first_name||''} ${order.customer_last_name||''}`.trim()||'—')}</span></div><div><b>الهاتف</b><span>${esc(order.customer_phone||'—')}</span></div><div><b>الولاية</b><span>${esc(order.wilaya||'—')}</span></div><div><b>البلدية</b><span>${esc(order.commune||'—')}</span></div><div><b>الرمز البريدي</b><span>${esc(order.postal_code||'—')}</span></div><div class="full-field"><b>العنوان</b><span>${esc(order.address||'—')}</span></div><div><b>السلعة</b><span>${esc(order.product_name||'—')}</span></div><div><b>معلومات السلعة</b><span>${esc(order.product_info||'—')}</span></div><div><b>رابط السلعة</b><span>${order.product_url?`<a href="${esc(order.product_url)}" target="_blank" rel="noopener">فتح الرابط</a>`:'—'}</span></div><div><b>الكمية</b><span>${Number(order.quantity)||1}</span></div><div><b>تاريخ الطلب</b><span>${formatDate(order.created_at)}</span></div></div>`;
  $('orderDetailModal')?.classList.add('show');const proofHost=document.createElement('div');proofHost.className='proof-host';$('orderDetailContent')?.appendChild(proofHost);showProofLink(order,proofHost);initIcons();
}
function normalizeWhatsApp(phone){let p=String(phone||'').replace(/\D/g,'');if(p.startsWith('00'))p=p.slice(2);if(p.startsWith('0'))p='213'+p.slice(1);return p}
function openFenkWhatsApp(message='مرحبًا FENK DZ، أريد الاستفسار عن خدمة الطلب.') { window.open(`https://wa.me/${FENK_WHATSAPP}?text=${encodeURIComponent(message)}`,'_blank','noopener'); }
$('closeOrderDetail')?.addEventListener('click',()=>$('orderDetailModal')?.classList.remove('show'));
$('orderDetailModal')?.addEventListener('click',e=>{if(e.target===$('orderDetailModal'))$('orderDetailModal').classList.remove('show')});
$('saveOrderDetail')?.addEventListener('click',async()=>{
  if(!selectedOrderId)return;const b=$('saveOrderDetail');b.disabled=true;b.textContent='جارٍ الحفظ…';
  try{
    const total=$('detailTotalPrice').value===''?null:Number($('detailTotalPrice').value),shipping=Number($('detailShipping').value||0),service=Number($('detailService').value||0),status=$('detailStatus').value;
    const {data,error}=await db.from('orders').update({total_price:total,shipping_fee:shipping,service_fee:service,status,payment_info:$('detailPaymentInfo').value.trim()||null,admin_note:$('detailAdminNote').value.trim()||null,updated_at:new Date().toISOString()}).eq('id',selectedOrderId).select().single();if(error)throw error;
    await db.from('order_status_history').insert({order_id:selectedOrderId,status,note:'تم التحديث من لوحة الإدارة'});await notifyTelegram(data);setMessage($('orderDetailMsg'),'تم حفظ التعديلات وإرسال التحديث ✓','success');await refreshAdmin();
  }catch(e){setMessage($('orderDetailMsg'),e?.message||'تعذر حفظ التعديلات.','error')}finally{b.disabled=false;b.textContent='حفظ التعديلات'}
});
async function notifyTelegram(order){try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:order.id,event:'updated'}});if(error)console.warn('Telegram:',error.message)}catch(e){console.warn('Telegram:',e)}}
$('orderSearch')?.addEventListener('input',()=>renderOrders(cachedOrders));$('statusFilter')?.addEventListener('change',()=>renderOrders(cachedOrders));
$('telegramTest')?.addEventListener('click',async()=>{const m=$('telegramMsg');setMessage(m,'جارٍ اختبار Telegram…','success');if(!(await isAdmin()))return setMessage(m,'يجب تسجيل الدخول بحساب Admin.','error');const sample=cachedOrders[0];if(!sample)return setMessage(m,'أنشئ طلبًا أولًا لاختبار Telegram.','error');try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:sample.id,event:'test'}});if(error)throw error;setMessage(m,'تم إرسال اختبار Telegram بنجاح ✓','success')}catch(e){setMessage(m,e?.message||'تعذر إرسال اختبار Telegram.','error')}});
$('newsletterSubscribe')?.addEventListener('click',()=>{const i=$('newsletterEmail'),v=i?.value.trim()||'';if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))return alert('أدخل بريدًا إلكترونيًا صحيحًا.');alert('تم تسجيل بريدك بنجاح. شكرًا لثقتك في FENK DZ.');i.value=''})

function updateAuthUI(user){const label=user?`مسجل: ${user.user_metadata?.full_name||user.email||'Google'}`:'تسجيل الدخول';if($('accountBtn'))$('accountBtn').title=label;if($('mobileAccount'))$('mobileAccount').title=label}

db.auth.onAuthStateChange((_event,session)=>{
  updateAuthUI(session?.user||null);
  updateNotificationBadge(session?.user?.id||null);
  if(session){setTimeout(async()=>{await fillOrderContact(session.user);const admin=await isAdmin();if($('adminBtn'))$('adminBtn').style.display=admin?'block':'none'},0)}else{if($('adminBtn'))$('adminBtn').style.display='none'}
});
(async()=>{const {data:{session}}=await db.auth.getSession();updateAuthUI(session?.user||null);updateNotificationBadge(session?.user?.id||null);if(session){await fillOrderContact(session.user);if(await isAdmin())$('adminBtn').style.display='block'}})();

document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;['authModal','profileModal','messagesModal','notificationsModal','customerOrdersModal','orderDetailModal','marketModal','adminPanel'].forEach(id=>$(id)?.classList.remove('show'))});
document.querySelectorAll('video').forEach(v=>v.addEventListener('error',()=>v.closest('.video-card')?.classList.add('video-fallback')));
document.querySelectorAll('[data-fenk-whatsapp]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();openFenkWhatsApp();}));
initIcons();window.FENK={version:'V15-ACCOUNT-SETTINGS-ORDERS',supabaseUrl:SUPABASE_URL};

/* V15 account, settings, saved addresses, customer order detail, payment proof, review and smart assistant */
const FENK_APP_THEME_KEY='fenk_theme_v1', FENK_ADDR_KEY='fenk_addresses_v1', FENK_NOTIF_KEY='fenk_notifications_pref_v1';
const customerStatusOrder=['received','price_confirmation','awaiting_payment','payment_proof_received','paid','shipping','delivered'];
function getSavedAddresses(){try{return JSON.parse(localStorage.getItem(FENK_ADDR_KEY)||'[]')}catch{return []}}
function setSavedAddresses(a){localStorage.setItem(FENK_ADDR_KEY,JSON.stringify(a))}
function applyTheme(theme){const t=theme||localStorage.getItem(FENK_APP_THEME_KEY)||'system';document.documentElement.dataset.theme=t;document.body.classList.toggle('fenk-dark',t==='dark');if(t==='system'){const dark=window.matchMedia?.('(prefers-color-scheme: dark)').matches;document.body.classList.toggle('fenk-dark',!!dark)}}
applyTheme();window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change',()=>{if((localStorage.getItem(FENK_APP_THEME_KEY)||'system')==='system')applyTheme('system')});

async function openAccountModal(user=null){
  const current=user||(await db.auth.getUser()).data.user;if(!current)return openAuth('سجّل الدخول أولًا باستخدام Google.');
  const p=await getProfile(current),v=profileValues(current,p);
  $('accountName')&&( $('accountName').textContent=`${v.first_name} ${v.last_name}`.trim()||'مستخدم FENK');
  $('accountPhone')&&($('accountPhone').textContent=v.phone||'أضف رقم هاتفك');
  $('accountEmail')&&($('accountEmail').textContent=current.email||'حساب Google');
  const n=await getUnreadCount(current.id);if($('accountNotifCount'))$('accountNotifCount').textContent=n?String(n):'';
  $('accountModal')?.classList.add('show');initIcons();
}
async function getUnreadCount(uid){const {count}=await db.from('notifications').select('id',{count:'exact',head:true}).eq('user_id',uid).eq('is_read',false);return Number(count||0)}
$('accountEditProfile')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openProfileModal(); });
$('accountOrders')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openCustomerOrders(); });
$('accountNotifications')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openNotifications(); });
$('accountMessages')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openMessages(); });
$('accountAddresses')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openAddresses(); });
$('accountSettings')?.addEventListener('click',()=>{ $('accountModal')?.classList.remove('show'); openSettings(); });
$('accountAI')?.addEventListener('click',()=>{ $('accountModal')?.classList.remove('show'); $('fenkAiModal')?.classList.add('show');initIcons(); });
$('accountWhatsApp')?.addEventListener('click',()=>openFenkWhatsApp());
$('accountHelp')?.addEventListener('click',()=>openFenkWhatsApp('مرحبًا FENK DZ، أحتاج مساعدة بخصوص خدمة الطلب.'));
$('accountData')?.addEventListener('click',()=>alert('يمكنك تعديل معلوماتك وإدارة عناوينك من حسابك. لحماية الحساب، لا نعرض بياناتك للزوار.'));
$('accountLogout')?.addEventListener('click',async()=>{if(!confirm('هل تريد تسجيل الخروج من FENK DZ؟'))return;await db.auth.signOut();$('accountModal')?.classList.remove('show');location.reload();});
$('closeAccount')?.addEventListener('click',()=>$('accountModal')?.classList.remove('show'));
$('accountModal')?.addEventListener('click',e=>{if(e.target===$('accountModal'))$('accountModal').classList.remove('show')});

function openSettings(){
  const theme=localStorage.getItem(FENK_APP_THEME_KEY)||'system';const notif=localStorage.getItem(FENK_NOTIF_KEY)!=='off';
  document.querySelectorAll('input[name="fenkTheme"]').forEach(x=>x.checked=x.value===theme);if($('settingsNotifications'))$('settingsNotifications').checked=notif;$('settingsModal')?.classList.add('show');initIcons();
}
document.querySelectorAll('input[name="fenkTheme"]').forEach(x=>x.addEventListener('change',()=>{localStorage.setItem(FENK_APP_THEME_KEY,x.value);applyTheme(x.value)}));
$('settingsNotifications')?.addEventListener('change',e=>localStorage.setItem(FENK_NOTIF_KEY,e.target.checked?'on':'off'));
$('closeSettings')?.addEventListener('click',()=>$('settingsModal')?.classList.remove('show'));$('settingsModal')?.addEventListener('click',e=>{if(e.target===$('settingsModal'))$('settingsModal').classList.remove('show')});

async function openAddresses(){
  const list=getSavedAddresses();renderAddresses(list);$('addressesModal')?.classList.add('show');initIcons();
}
function renderAddresses(list){const box=$('addressesList');if(!box)return;box.innerHTML=list.length?list.map((a,i)=>`<article class="saved-address ${a.primary?'primary':''}"><div><b>${esc(a.label||'العنوان الرئيسي')}</b>${a.primary?'<span class="address-badge">الرئيسي</span>':''}</div><p>${esc(a.full_name||'')} • ${esc(a.phone||'')}<br>${esc(a.wilaya||'')}، ${esc(a.commune||'')}<br>${esc(a.address||'')} ${a.postal_code?`• ${esc(a.postal_code)}`:''}</p><div class="address-actions"><button type="button" data-use-address="${i}">استخدام</button><button type="button" data-primary-address="${i}">جعله رئيسيًا</button><button type="button" data-delete-address="${i}">حذف</button></div></article>`).join(''):'<div class="empty">لا توجد عناوين محفوظة. أضف عنوانك مرة واحدة وسيتم استعماله في الطلبات القادمة.</div>';
  box.querySelectorAll('[data-use-address]').forEach(b=>b.addEventListener('click',()=>{fillOrderFromAddress(list[Number(b.dataset.useAddress)]);$('addressesModal')?.classList.remove('show');document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}));
  box.querySelectorAll('[data-primary-address]').forEach(b=>b.addEventListener('click',()=>{const i=Number(b.dataset.primaryAddress);const n=list.map((a,j)=>({...a,primary:i===j}));setSavedAddresses(n);renderAddresses(n)}));
  box.querySelectorAll('[data-delete-address]').forEach(b=>b.addEventListener('click',()=>{const i=Number(b.dataset.deleteAddress);list.splice(i,1);setSavedAddresses(list);renderAddresses(list)}));
}
function fillOrderFromAddress(a){if(!a)return;[['orderFirstName',a.first_name||a.full_name?.split(' ')[0]||''],['orderLastName',a.last_name||a.full_name?.split(' ').slice(1).join(' ')||''],['orderPhone',a.phone||''],['orderWilaya',a.wilaya||''],['orderCommune',a.commune||''],['orderPostalCode',a.postal_code||''],['orderAddress',a.address||'']].forEach(([id,v])=>{if($(id))$(id).value=v})}
$('addAddress')?.addEventListener('click',async()=>{const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');$('addressForm')?.reset();const p=await getProfile(user),v=profileValues(user,p);if($('addressFirstName'))$('addressFirstName').value=v.first_name;if($('addressLastName'))$('addressLastName').value=v.last_name;if($('addressPhone'))$('addressPhone').value=v.phone;$('addressEditModal')?.classList.add('show')});
$('closeAddresses')?.addEventListener('click',()=>$('addressesModal')?.classList.remove('show'));$('addressesModal')?.addEventListener('click',e=>{if(e.target===$('addressesModal'))$('addressesModal').classList.remove('show')});
$('closeAddressEdit')?.addEventListener('click',()=>$('addressEditModal')?.classList.remove('show'));$('addressEditModal')?.addEventListener('click',e=>{if(e.target===$('addressEditModal'))$('addressEditModal').classList.remove('show')});
$('addressForm')?.addEventListener('submit',e=>{e.preventDefault();const a={id:crypto.randomUUID(),label:$('addressLabel').value.trim()||'العنوان الرئيسي',first_name:$('addressFirstName').value.trim(),last_name:$('addressLastName').value.trim(),full_name:`${$('addressFirstName').value.trim()} ${$('addressLastName').value.trim()}`.trim(),phone:$('addressPhone').value.trim(),wilaya:$('addressWilaya').value.trim(),commune:$('addressCommune').value.trim(),address:$('addressText').value.trim(),postal_code:$('addressPostal').value.trim(),primary:$('addressPrimary').checked};if(!a.first_name||!a.last_name||!a.phone||!a.wilaya||!a.commune||!a.address)return setMessage($('addressMsg'),'أكمل بيانات العنوان.','error');let list=getSavedAddresses();if(a.primary)list=list.map(x=>({...x,primary:false}));if(!list.length)a.primary=true;list.unshift(a);setSavedAddresses(list);$('addressEditModal')?.classList.remove('show');renderAddresses(list);$('addressesModal')?.classList.add('show')});

async function openCustomerOrderDetail(id){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');
  $('customerOrderDetailContent').innerHTML='<div class="empty">جارٍ تحميل تفاصيل الطلب…</div>';$('customerOrderDetailModal')?.classList.add('show');
  const {data:o,error}=await db.from('orders').select('*').eq('id',id).eq('user_id',user.id).single();if(error||!o)return $('customerOrderDetailContent').innerHTML='<div class="empty">تعذر تحميل تفاصيل الطلب.</div>';
  const total=o.total_price!=null?Number(o.total_price):null,ship=Number(o.shipping_fee||0),service=Number(o.service_fee||0);
  const priceHtml=total!=null?`<div class="price-card"><div><span>سعر المنتج</span><b>${formatMoney((total-ship-service),o.currency)}</b></div><div><span>الشحن</span><b>${formatMoney(ship,o.currency)}</b></div><div><span>خدمة FENK</span><b>${formatMoney(service,o.currency)}</b></div><div class="price-total"><span>المجموع</span><b>${formatMoney(total,o.currency)}</b></div></div>`:'<div class="pending-price">💰 السعر النهائي سيظهر هنا بعد أن يراجع فريق FENK طلبك.</div>';
  $('customerOrderDetailNumber').textContent=`#${o.order_number}`;
  $('customerOrderDetailContent').innerHTML=`<div class="customer-order-summary">${o.product_image_url?`<div class="order-image-note">🖼️ تم إرفاق صورة المنتج</div>`:''}<h3>${esc(o.product_name||o.product_info||'طلب منتج')}</h3><p>الكمية: ${Number(o.quantity)||1} • ${formatDate(o.created_at)}</p>${priceHtml}${renderTimeline(o.status)}<div class="order-contact-actions"><a class="whatsapp-order-btn" href="https://wa.me/${FENK_WHATSAPP}?text=${encodeURIComponent(`مرحبًا FENK DZ، بخصوص طلبي #${o.order_number}.`)}" target="_blank" rel="noopener">💬 تواصل عبر WhatsApp</a>${o.status==='awaiting_payment'||o.status==='price_confirmation'?'<button class="send" type="button" id="customerPayProofBtn">💳 إرسال وصل الدفع</button>':''}${o.status==='delivered'?'<button class="send secondary" type="button" id="reorderBtn">🔄 طلب نفس المنتج مرة أخرى</button>':''}</div>${o.status==='delivered'?'<div class="review-box"><h4>⭐ كيف كانت تجربتك مع FENK؟</h4><div class="stars" id="reviewStars">'+[1,2,3,4,5].map(i=>`<button type="button" data-rating="${i}">★</button>`).join('')+'</div><textarea id="reviewNote" rows="3" placeholder="ملاحظة اختيارية"></textarea><button type="button" class="send" id="sendReview">إرسال التقييم</button><p id="reviewMsg"></p></div>':''}</div>`;
  $('customerPayProofBtn')?.addEventListener('click',()=>openPaymentProof(o));$('reorderBtn')?.addEventListener('click',()=>reorderFromOrder(o));
  document.querySelectorAll('#reviewStars [data-rating]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#reviewStars [data-rating]').forEach(x=>x.classList.toggle('selected',Number(x.dataset.rating)<=Number(b.dataset.rating)));$('reviewStars').dataset.value=b.dataset.rating}));
  $('sendReview')?.addEventListener('click',async()=>{const rating=Number($('reviewStars')?.dataset.value||0);if(!rating)return setMessage($('reviewMsg'),'اختر عدد النجوم أولًا.','error');const {data:{user}}=await db.auth.getUser();const note=$('reviewNote').value.trim()||null;const {error}=await db.from('order_reviews').insert({order_id:o.id,user_id:user.id,rating,note});if(error){let reviews=[];try{reviews=JSON.parse(localStorage.getItem('fenk_reviews_v1')||'[]')}catch{}reviews.push({order_id:o.id,user_id:user.id,rating,note,created_at:new Date().toISOString()});localStorage.setItem('fenk_reviews_v1',JSON.stringify(reviews));setMessage($('reviewMsg'),'تم حفظ تقييمك على هذا الجهاز ⭐','success')}else{setMessage($('reviewMsg'),'شكرًا لتقييمك ⭐','success')}$('sendReview').disabled=true});
  initIcons();
}
function reorderFromOrder(o){$('customerOrderDetailModal')?.classList.remove('show');if($('productUrl'))$('productUrl').value=o.product_url||'';if($('productName'))$('productName').value=o.product_name||'';if($('productInfo'))$('productInfo').value=o.product_info||'';qty=Number(o.quantity)||1;if($('qty'))$('qty').textContent=String(qty);document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}
$('closeCustomerOrderDetail')?.addEventListener('click',()=>$('customerOrderDetailModal')?.classList.remove('show'));$('customerOrderDetailModal')?.addEventListener('click',e=>{if(e.target===$('customerOrderDetailModal'))$('customerOrderDetailModal').classList.remove('show')});

async function openPaymentProof(order){$('paymentProofOrderId').value=order.id;$('paymentProofFile').value='';$('paymentProofMsg').textContent='';$('paymentProofModal')?.classList.add('show');}
$('closePaymentProof')?.addEventListener('click',()=>$('paymentProofModal')?.classList.remove('show'));$('paymentProofModal')?.addEventListener('click',e=>{if(e.target===$('paymentProofModal'))$('paymentProofModal').classList.remove('show')});
$('paymentProofForm')?.addEventListener('submit',async e=>{e.preventDefault();const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('انتهت الجلسة.');const file=$('paymentProofFile')?.files?.[0],orderId=$('paymentProofOrderId')?.value;if(!file)return setMessage($('paymentProofMsg'),'اختر صورة الوصل.','error');if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>5*1024*1024)return setMessage($('paymentProofMsg'),'اختر JPG أو PNG أو WEBP بحجم لا يتجاوز 5MB.','error');const b=e.submitter;b.disabled=true;try{const ext=file.type.split('/')[1].replace('jpeg','jpg');const path=`${user.id}/payment-proof-${orderId}-${Date.now()}.${ext}`;const {error:upErr}=await db.storage.from('product-images').upload(path,file,{contentType:file.type,upsert:false});if(upErr)throw upErr;const {error}=await db.from('orders').update({status:'payment_proof_received',payment_info:`PROOF_PATH:${path}`,updated_at:new Date().toISOString()}).eq('id',orderId).eq('user_id',user.id);if(error)throw error;$('paymentProofModal')?.classList.remove('show');setMessage($('orderMsg'),'تم استلام وصل الدفع، وسيراجعه فريق FENK ✓','success');await openCustomerOrders();}catch(err){setMessage($('paymentProofMsg'),err?.message||'تعذر إرسال الوصل.','error')}finally{b.disabled=false}});

async function showProofLink(order,container){const pi=String(order.payment_info||'');if(!pi.startsWith('PROOF_PATH:')||!container)return;const path=pi.slice(11);const {data,error}=await db.storage.from('product-images').createSignedUrl(path,3600);if(!error&&data?.signedUrl){const a=document.createElement('a');a.href=data.signedUrl;a.target='_blank';a.rel='noopener';a.className='proof-link';a.textContent='🧾 فتح وصل الدفع';container.appendChild(a)}}

// Make order cards clickable and show the richer detail view.
const _oldOpenCustomerOrders=openCustomerOrders;
openCustomerOrders=async function(){await _oldOpenCustomerOrders();const list=$('customerOrdersList');list?.querySelectorAll('.order-card').forEach(card=>{card.style.cursor='pointer';card.addEventListener('click',e=>{if(e.target.closest('a,button'))return;if(card.dataset.orderId)openCustomerOrderDetail(card.dataset.orderId)})})};

// Smart FENK AI: helpful on-device assistant until an AI API key is configured server-side.
function aiReply(text){const t=String(text||'').toLowerCase();if(/ali|amazon|ebay|temu|shein|aliexpress|https?:\/\//i.test(t))return 'أرسل رابط المنتج في خانة الرابط، وسأساعدك في تحديد الموقع والبيانات المطلوبة لإرسال الطلب. لا أستطيع تأكيد السعر النهائي من الموقع تلقائيًا من داخل المتصفح.';if(t.includes('سعر')||t.includes('دج'))return 'السعر النهائي يحدده فريق FENK بعد مراجعة سعر المنتج والشحن ورسوم الخدمة، ثم يظهر لك داخل تفاصيل الطلب.';if(t.includes('مقارنة')||t.includes('قارن'))return 'أرسل رابطَي المنتجين أو اكتب اسميهما، وسأساعدك في تنظيم مقارنة واضحة بين السعر والمواصفات والكمية والشحن.';if(t.includes('دفع')||t.includes('بريد موب'))return 'الدفع في FENK يتم عبر بريد موب فقط. بعد تحديد السعر سيظهر لك المبلغ النهائي، ثم يمكنك إرسال صورة وصل الدفع من تفاصيل الطلب.';if(t.includes('طلب'))return 'لإنشاء طلب: أرسل رابط المنتج أو صورته، أكمل معلوماتك وعنوانك، ثم اضغط إرسال الطلب. سنتواصل معك عبر WhatsApp.';return 'مرحبًا 👋 أنا مساعد FENK. اسألني عن طلبك، السعر، الشحن، الدفع عبر بريد موب، أو أرسل رابط المنتج.'}
$('aiForm')?.addEventListener('submit',e=>{e.preventDefault();const input=$('aiInput'),t=input.value.trim();if(!t)return;const box=$('aiChat');box.insertAdjacentHTML('beforeend',`<div class="ai-bubble mine">${esc(t)}</div><div class="ai-bubble">${esc(aiReply(t))}</div>`);input.value='';box.scrollTop=box.scrollHeight});
$('closeFenkAi')?.addEventListener('click',()=>$('fenkAiModal')?.classList.remove('show'));$('fenkAiModal')?.addEventListener('click',e=>{if(e.target===$('fenkAiModal'))$('fenkAiModal').classList.remove('show')});

// Keep the saved primary address in sync with the order form after successful profile/order entry.
const _oldSendOrderHandlerNote=true;
$('order')?.addEventListener('submit',()=>{});

// Fix notification title in the current UI and expose a small bell button in the mobile nav if present.
if(!$('mobileNotification')){const nav=document.querySelector('.mobile-nav');const messages=document.getElementById('mobileMessages');if(nav&&messages){const b=document.createElement('button');b.id='mobileNotification';b.type='button';b.innerHTML='<i data-lucide="bell"></i><small>الإشعارات</small><em id="mobileNotificationBadge"></em>';nav.insertBefore(b,messages);b.addEventListener('click',openNotifications);initIcons()}}
const _oldUpdateBadge=updateNotificationBadge;updateNotificationBadge=async function(uid=null){await _oldUpdateBadge(uid);const main=$('notificationBadge'),mob=$('mobileNotificationBadge');if(mob){const n=main?.textContent||'';mob.textContent=n;mob.style.display=main?.style.display==='none'?'none':'flex'}};

// Auto-fill primary saved address for new orders.
const primaryAddress=getSavedAddresses().find(a=>a.primary)||getSavedAddresses()[0];if(primaryAddress)fillOrderFromAddress(primaryAddress);

