# FENK V168 — Game Top-Up Full Page Control

Added an Admin-only **تحكم في شحن الألعاب** panel.

Controls:
- Page title, subtitle and heading icon.
- Page colors.
- Mobile/desktop columns, max width, card image height, gaps, card radius and page padding.
- Per-game card media: image or short video.
- Per-game icon media: image or short video.
- Animated promo slides with image/video, text and linked game.
- Quick page icons.
- Settings stored under `site_settings.homepage_config.game_topup_control`.
- Existing games, packages, orders and payment data are preserved.
