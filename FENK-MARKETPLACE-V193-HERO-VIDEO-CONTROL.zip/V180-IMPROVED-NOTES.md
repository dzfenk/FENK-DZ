# FENK V180 Improved

- Final mobile/RTL polish for game top-up UI.
- Prevent horizontal overflow.
- Improve mixed Arabic/English package names with unicode-bidi/plaintext handling.
- Add extra client-side guard for Flexy cap (600 DZD).
- Preserve existing payment logic and data.
- No logos were fabricated or replaced with guessed image URLs.
