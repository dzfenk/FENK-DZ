# FENK V174 — Remove global music

- Removed the old global `fenk-theme.mp3` background music from homepage, game top-up page, and admin page.
- Removed the homepage global music toggle.
- Kept per-game music only on the individual game page, controlled by `fenk-game-music.js`.
- The old Supabase object is no longer referenced by the site.
