# FENK V150 — Marketplace mobile/category UI fixes

- Compact mobile category hero to reduce vertical space.
- Marketplace category cards now show useful metadata (car year, mileage, fuel/gear, or location when available).
- Cards without a price show `السعر عند التواصل` instead of leaving an empty area.
- Improved image ratio for vehicle/marketplace listings and added a no-image fallback.
- Improved mobile card borders, spacing, typography, and shadows.
- Category hero text is contextual for Ads and Spare Parts sections.
- Spare-parts filters become horizontally scrollable on small screens.
- Existing FENK identity, Supabase data, pages, and functions are preserved.
