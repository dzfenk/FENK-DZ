# FENK mobile responsive fix

Updated the existing Products page for phones (360/390/430px): one product per row, consistent image area, constrained title, RTL prices, consistent rating, and a full-width touch-friendly "اختيار المنتج" button. Desktop/tablet layout is preserved. No Supabase data or purchase flow was removed.
