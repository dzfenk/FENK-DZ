# FENK V148 — Marketplace mobile layout

Updated the existing `products.html` only: compact mobile header/hero, live search,
scrollable category chips, dense 4-column mobile product grid, square product images,
two-line titles, compact prices/discount/rating/sales, and preserved existing product
detail/cart/checkout links and Supabase data source. No product data was added or deleted.
