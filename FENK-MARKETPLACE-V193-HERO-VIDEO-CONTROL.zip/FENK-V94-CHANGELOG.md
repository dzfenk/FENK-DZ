# FENK V94 — Marketplace UI/function fixes

- Fixed invisible publication-price text inside the green hero.
- Made publication price chips high-contrast and readable on mobile.
- Category cards keep real links: products, stores, cars, realestate, land.
- Category images are responsive and no longer distort on mobile.
- Empty category states remain usable and provide a publish action.
- Fixed the land category label to “أراضي للبيع”.

## V189 — 2026-09-23
- Fixed permanent deletion of cancelled orders using an Admin-only Supabase RPC.
- Preserved RLS and blocked anonymous/public execution.
- Added safe bulk deletion support through the same RPC.
