// V174: Global background music removed. Per-game music is handled by fenk-game-music.js on game pages only.
