# FENK V171 — Game Page Dedicated Music

- Added per-game background music settings in Admin > تحكم كامل في شحن الألعاب.
- Each game can have its own MP3/M4A/OGG URL or uploaded audio file.
- Music starts when a game page is opened; browser autoplay restrictions are handled with a visible play button.
- Previous game's music stops when another game is opened.
- Per-game volume and autoplay can be configured.
- Music controls are shown only when that game has music configured.
- Existing FENK identity, games, packages, Supabase data, and page controls remain unchanged.
