# FENK — تسجيل العملاء عبر Google فقط

هذا الإصدار يستخدم Google OAuth للعملاء فقط، ولا يعرض تسجيل الدخول بالبريد الإلكتروني وكلمة المرور أو Phone Auth للعملاء.

## Supabase
في Authentication > Providers:
- Google: ON
- Email: OFF للعملاء
- Phone: OFF
- Anonymous: OFF
- Manual linking: OFF
- Confirm email: لا ينطبق على تسجيل Google بالطريقة نفسها.

## Google OAuth
- Supabase project: `https://wqfnzahjwlukncxlxdkp.supabase.co`
- Google callback: `https://wqfnzahjwlukncxlxdkp.supabase.co/auth/v1/callback`
- FENK production redirect: `https://boutique.dzfenk.workers.dev/`

لا تضع Google Client Secret أو Supabase Service Role Key داخل ملفات الواجهة.

## ملاحظة Admin
صفحة Admin تستخدم حسابًا منفصلًا بالبريد وكلمة المرور، وتتحقق من وجود المستخدم في جدول صلاحيات الإدارة قبل إظهار لوحة التحكم.
