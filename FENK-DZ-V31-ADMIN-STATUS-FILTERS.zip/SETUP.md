# FENK V6 Setup

1. ارفع محتويات هذا المجلد إلى Netlify.
2. تأكد أن Site URL في Supabase هو رابط Netlify النهائي.
3. Google OAuth يجب أن يكون مفعلاً في Supabase، مع Client ID/Secret الصحيحين.
4. Auth provider: Google Enabled، Email Disabled إذا كان المطلوب Google فقط.
5. Storage bucket: `product-images` خاص، حد 5MB، الأنواع JPEG/PNG/WEBP.
6. لا تضع Telegram Bot Token أو Supabase Secret Key في الواجهة. تبقى في Supabase Edge Function Secrets.
