-- Fix order notification trigger: OLD is only valid for UPDATE triggers.
create or replace function public.notify_order_status()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
declare
  status_label text;
  actor uuid;
  price_changed boolean := false;
begin
  actor := auth.uid();
  status_label := case new.status
    when 'received' then 'تم استلام الطلب'
    when 'pricing' then 'تم تحديد السعر'
    when 'awaiting_payment' then 'بانتظار الدفع'
    when 'payment_submitted' then 'تم إرسال وصل الدفع'
    when 'payment_confirmed' then 'تم تأكيد الدفع'
    when 'purchasing' then 'جارٍ شراء المنتج'
    when 'shipped' then 'تم شحن المنتج'
    when 'arrived_algeria' then 'وصل إلى الجزائر'
    when 'out_for_delivery' then 'خرج للتوصيل'
    when 'delivered' then 'تم التسليم'
    when 'cancelled' then 'تم إلغاء الطلب'
    else 'تم تحديث الطلب'
  end;
  if tg_op = 'INSERT' then
    insert into public.order_status_history(order_id,status,changed_by,note)
    values(new.id,new.status,actor,'تم إنشاء الطلب');
    insert into public.notifications(user_id,order_id,title,message)
    values(new.user_id,new.id,'تم استلام طلبك','تم استلام طلبك '||new.order_number||' بنجاح. اضغط لفتح الطلب.');
  elsif tg_op = 'UPDATE' then
    price_changed :=
      new.product_price is distinct from old.product_price or
      new.shipping_fee is distinct from old.shipping_fee or
      new.service_fee is distinct from old.service_fee or
      new.total_price is distinct from old.total_price;
    if new.status is distinct from old.status then
      insert into public.order_status_history(order_id,status,changed_by,note)
      values(new.id,new.status,actor,'تم تحديث الحالة');
      insert into public.notifications(user_id,order_id,title,message)
      values(new.user_id,new.id,'تحديث الطلب','تم تغيير حالة الطلب '||new.order_number||' إلى: '||status_label||'. اضغط لفتح الطلب.');
    elsif new.status = 'pricing' and price_changed then
      insert into public.notifications(user_id,order_id,title,message)
      values(new.user_id,new.id,'تم تحديث سعر طلبك','تم تحديث سعر الطلب '||new.order_number||'. افتح الطلب للاطلاع على السعر الجديد.');
    end if;
  end if;
  return new;
end;
$function$;
