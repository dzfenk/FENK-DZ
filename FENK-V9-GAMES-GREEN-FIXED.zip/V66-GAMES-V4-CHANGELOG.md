# FENK Games V4

## Core
- Preserved the existing FENK project and Supabase data.
- Kept the existing game/package/checkout-field architecture.
- Added per-user `game_favorites` with RLS.
- Added `games.category` for games/apps/cards/accounts filtering.
- Added private `fenk-game-payment-proofs` storage bucket with owner/admin RLS.
- Added `orders.payment_proof_path`, `payment_verified_at`, and `payment_verified_by`.
- Game orders now upload payment proof before insert and use `payment_submitted` status.
- Payment method remains BaridiMob only.

## Mobile UX
- Reduced game-card height and spacing.
- Smaller, non-obstructive live badge.
- Added favorite button.
- Improved search/filter layout and Arabic search normalization.
- Improved promo image selection to use each game's database HD banner.
- Added empty states instead of fake products.
- Added app/digital-card/game-account sections backed by Supabase service records.

## Game configuration
- Admin game settings now include category.
- Admin can manage per-game checkout fields including password/email types.
- Database checkout field constraint now supports `text`, `number`, `select`, `email`, and `password`.

## Account UX
- Added a quick logout action near the account header on mobile while keeping the existing logout action.

## Yalla Ludo
- Added `yalla-ludo` to Supabase as inactive until a proper local HD asset and real FENK package/pricing data are supplied. No placeholder image or fake price was added.

## Verification
- Existing `assets/game-hd/` contains 27 independent WebP game images.
- All 27 existing HD assets are 1600x900.
- No existing game/order/package data was deleted.
