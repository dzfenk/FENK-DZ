# FENK V66 Games Fix V2

- Fixed the game-topup HTML where the second `<style>` block was not closed, causing CSS source text to appear above the FENK header on mobile.
- eFootball phone type fallback now includes Android and iPhone.
- Supabase `game_checkout_fields` was populated so all 27 active games have at least one active game-specific checkout field.
- Existing FENK data, games, packages and orders were not deleted.
