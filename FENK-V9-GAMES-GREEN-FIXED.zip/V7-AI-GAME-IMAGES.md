# FENK V7 — AI Game Images

Added six new 1600x900 WebP game banners generated for the FENK games catalog:

- Mobile Legends Global → assets/game-hd/mobile-legends-global.webp
- Mobile Legends Regional → assets/game-hd/mobile-legends-regional.webp
- Blood Strike MENA → assets/game-hd/blood-strike-mena.webp
- Blood Strike Global → assets/game-hd/blood-strike-global.webp
- Delta Force Garena → assets/game-hd/delta-force-garena.webp
- Brawl Stars → assets/game-hd/brawl-stars.webp

The existing filenames were replaced in the publish package so the existing Supabase `games.banner_url` mappings continue to work without changing database records.

No existing game data was deleted.
