# FENK V66 — DzairPay Games Sync + HD + Game Music

- Preserved FENK header/identity.
- Removed the large promo carousel from the games catalog so the page follows the DzairPay top-ups flow: search/filter -> game cards.
- Direct game URL (`?game=Free%20Fire`) opens the selected game detail directly, hiding the catalog/promo until the user returns.
- Added a return-to-games button.
- Kept Supabase games/packages/orders and BaridiMob checkout unchanged.
- Verified active FENK game catalog contains 27 games matching the current DzairPay 27-game direct top-up catalog checked on 2026-09-19.
- Added 27 local HD game card/banner assets under `assets/game-hd/` for consistent rendering.
- Kept one dedicated music file per active game under `assets/game-music/`.
- Music source is selected from the game's slug, never randomly.
- Browser autoplay restrictions are handled: if autoplay is blocked, the music dock says to press play; after user interaction the selected game's track starts.
- No official copyrighted game soundtrack was added; existing local tracks remain dedicated per game.

## V66.1 — Games pages repair / no music
- Removed all local game music/audio files and active audio references.
- Every active game keeps a dedicated 1600x900 HD image under `assets/game-hd/`.
- Clicking a game now opens its dedicated URL (`game-topup.html?game=<slug>`) instead of only scrolling a shared section.
- Game checkout fields are loaded from `game_checkout_fields` and fall back to per-game defaults when not configured.
- eFootball checkout now matches the requested DzairPay-style fields: KONAMI email, KONAMI password, and phone type (Android).
- Admin order details now show submitted game-specific fields; password values are masked with an explicit reveal control.
- Game-page accent was kept purple/FENK; green UI accents were removed from the game page.


## V66.1 — Games/Admin connection fix
- Removed leaked CSS text from game-topup.html.
- Game pages now read banner_url, logo_url, and description from Supabase, with local 1600x900 game-HD fallback.
- Added Admin > إعدادات الألعاب for game metadata and per-game checkout fields.
- eFootball checkout phone type supports Android and iPhone.
