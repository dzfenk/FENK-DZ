# FENK V66 Games Fix V3

- Fixed mobile account modal accessibility: close button remains reachable while scrolling and logout stays reachable.
- Fixed game card image source mapping: each active game now uses its own `assets/game-hd/<slug>.webp` asset (1600x900 set).
- Repaired Supabase `games.banner_url` values for all 27 active games to point to the matching HD asset path.
- Improved mobile game cards: shorter image area, compact spacing, consistent badge placement, no horizontal overflow.
- Improved promo/banner sizing on mobile.
- Package thumbnails now use the selected game's own banner image rather than unrelated generic logos.
- Added `email` and `password` as supported `game_checkout_fields.field_type` values in Supabase; eFootball KONAMI fields use the correct input types.
- Preserved existing games, packages, orders, authentication, admin logic, and FENK identity.
