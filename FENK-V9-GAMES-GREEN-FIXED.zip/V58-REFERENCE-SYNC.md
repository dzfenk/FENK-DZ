# FENK V58 — Gaming reference sync

- Gaming page redesigned to follow the requested reference layout: purple top bar, secondary navigation, large promotional slider, two-column mobile game cards, detail area, benefits, and package selection.
- FENK branding is retained; no DzairPay branding is copied into the FENK interface.
- Added original local background music loops for each supported game. Music starts after the user selects a game (browser autoplay rules are respected) and can be muted/unmuted.
- Added offer/original-price display to packages.
- Admin package editor now supports an optional original price before discount.
- Synced currently verified reference prices for PUBG Mobile, Free Fire, and eFootball into Supabase. Existing referenced orders were preserved; obsolete active packages were deactivated instead of deleted.
- Barid Mob remains the payment method and the configured RIP remains 00799999002385072872.
- Verified a transactional test insert with rollback: package price, total, payment destination, and payment information were populated correctly.
- JavaScript syntax checked for game-topup.html and admin.js.
