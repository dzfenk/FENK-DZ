# FENK Games V7 — Deployment Package

This package is the current FENK Games release prepared for deployment.

- FENK identity preserved.
- Arabic RTL / mobile-first layout.
- Game catalog connected to Supabase.
- 27 dedicated game HD images under `assets/game-hd/`.
- No audio/music files included.
- BaridiMob payment flow and payment-proof upload are included in the current game top-up page.
- Admin files included.

## Netlify
Upload/deploy the contents of this package as the site root. Keep the existing Supabase project/configuration; do not recreate the database.
