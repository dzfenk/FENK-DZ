# FENK Mobile UX V2 — additive patch

- Preserves existing FENK pages, Supabase, authentication, cart, orders, ads, favorites, AI, games and data.
- Adds `fenk-global-mobile-v2.css` to existing HTML pages as an additive mobile-only layer.
- Improves mobile grids, product/ad cards, game cards, images, spacing, banners, bottom navigation safe area and floating controls.
- Keeps desktop styling unchanged except shared overflow/box-sizing safeguards.
- Strengthens the existing price calculator using the existing inputs and formula: USD × exchange rate + shipping + FENK service.
- No demo data or replacement database was introduced.
