
(function(){
  const audio=document.getElementById('fenkBackgroundMusic');
  if(!audio)return;
  audio.volume=0.35;
  const start=()=>{audio.play().catch(()=>{});};
  start();
  ['pointerdown','touchstart','keydown','scroll'].forEach(ev=>window.addEventListener(ev,start,{once:true,passive:true}));
})();
