const SUPABASE_URL='https://wqfnzahjwlukncxlxdkp.supabase.co';
const SUPABASE_KEY='sb_publishable__QR4tJ9p5RYOQkIuHkoYKQ_mbDa9tuA';
const FENK_WHATSAPP='213778939292';
const db=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);const $=id=>document.getElementById(id);
let cachedOrders=[],selectedOrderId=null;
const processingStatuses=new Set(['received','pricing','purchasing','shipped','arrived_algeria','out_for_delivery']);
const statusNames={received:'تم استلام الطلب',pricing:'تم تحديد السعر',awaiting_payment:'بانتظار الدفع',payment_submitted:'تم إرسال وصل الدفع',payment_confirmed:'تم تأكيد الدفع',purchasing:'جارٍ شراء المنتج',shipped:'تم شحن المنتج',arrived_algeria:'وصل إلى الجزائر',out_for_delivery:'خرج للتوصيل',delivered:'تم التسليم',cancelled:'تم إلغاء الطلب'};
const canonicalStatus=s=>({checking:'received',price_confirmation:'pricing',payment_proof_received:'payment_submitted',paid:'payment_confirmed',shipping:'shipped'}[s]||s||'received');
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const formatDate=v=>{const d=new Date(v);return !v||Number.isNaN(d.getTime())?'—':d.toLocaleDateString('ar-DZ',{day:'2-digit',month:'2-digit',year:'numeric'})+' • '+d.toLocaleTimeString('ar-DZ',{hour:'2-digit',minute:'2-digit'})};
const formatMoney=(v,c='DZD')=>{const n=Number(v);return Number.isFinite(n)&&n>0?`${n.toLocaleString('ar-DZ')} ${c==='DZD'?'دج':c}`:'قيد التحديد'};
const msg=(t,type='')=>{const e=$('adminLoginMsg');if(e){e.textContent=t;e.className='admin-msg '+type}};
const initIcons=()=>{try{window.lucide?.createIcons({attrs:{'stroke-width':2.1}})}catch{}};
async function isAdmin(){const {data:{user}}=await db.auth.getUser();if(!user)return false;const {data,error}=await db.from('admin_users').select('user_id').eq('user_id',user.id).maybeSingle();return !error&&!!data}
function showPanel(user){$('adminLogin').style.display='none';$('adminPanel').classList.add('show');$('adminPanel').setAttribute('aria-hidden','false');$('adminEmail').textContent=user?.email||'';initIcons();}
function showLogin(t=''){ $('adminLogin').style.display='grid';$('adminPanel').classList.remove('show');$('adminPanel').setAttribute('aria-hidden','true');if(t)msg(t,'error'); }
function setAdminMenu(open){const p=$('adminPanel');if(!p)return;p.classList.toggle('menu-open',!!open);$('adminMenuBtn')?.setAttribute('aria-expanded',String(!!open));$('adminSideBackdrop')?.classList.toggle('show',!!open)}
$('adminMenuBtn')?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();setAdminMenu(!$('adminPanel').classList.contains('menu-open'))});
$('adminSideBackdrop')?.addEventListener('click',e=>{e.preventDefault();setAdminMenu(false)});
$('adminMobileRefresh')?.addEventListener('click',async()=>{const b=$('adminMobileRefresh');b.disabled=true;try{await refreshAdmin();await refreshAdminMessages()}finally{b.disabled=false}});

async function boot(){const {data:{session}}=await db.auth.getSession();if(!session)return showLogin();if(await isAdmin()){showPanel(session.user);await refreshAdmin();await refreshAdminMessages()}else{await db.auth.signOut();showLogin('هذا الحساب ليس مرتبطًا بصلاحية Admin.');}}
$('adminLoginForm')?.addEventListener('submit',async e=>{e.preventDefault();const email=$('adminLoginEmail').value.trim();const password=$('adminLoginPassword').value;const b=$('adminLoginSubmit');b.disabled=true;msg('جارٍ تسجيل الدخول…','success');try{const {data,error}=await db.auth.signInWithPassword({email,password});if(error)throw error;if(!data?.user||!(await isAdmin())){await db.auth.signOut();throw new Error('هذا الحساب ليس مرتبطًا بصلاحية Admin.');}showPanel(data.user);await refreshAdmin();await refreshAdminMessages();}catch(err){console.error(err);msg(err?.message==='Invalid login credentials'?'البريد الإلكتروني أو كلمة المرور غير صحيحة.':(err?.message||'تعذر تسجيل الدخول.'),'error');}finally{b.disabled=false;}});
db.auth.onAuthStateChange((_event,session)=>{if(!session){showLogin();return;} setTimeout(async()=>{try{if(await isAdmin()){showPanel(session.user);await refreshAdmin();await refreshAdminMessages()}else{await db.auth.signOut();showLogin('هذا الحساب ليس مرتبطًا بصلاحية Admin.')}}catch(err){console.error(err);showLogin('حدث خطأ أثناء التحقق من صلاحية الإدارة.')}} ,0)});
$('adminLogoutBtn').onclick=async e=>{e.preventDefault();const b=e.currentTarget;b.disabled=true;try{await db.auth.signOut()}finally{location.reload()}};$('adminSiteBtn').onclick=e=>{e.preventDefault();location.href=location.pathname.replace(/admin\.html.*$/,'')||'/'};
async function handleAdminDetailButton(e){
  const detail=e.target?.closest?.('.detail-btn');
  if(!detail || detail.disabled) return;
  e.preventDefault();
  e.stopPropagation();
  const id=detail.getAttribute('data-order-id');
  if(!id){ console.error('FENK: missing order id'); return; }
  detail.disabled=true;
  try{ await openOrderDetail(id); }catch(err){
    console.error('FENK: failed to open order',err);
    const m=$('orderDetailMsg'); if(m) m.textContent='تعذر فتح تفاصيل الطلب. أعد المحاولة.';
  }finally{ detail.disabled=false; }
}

document.addEventListener('click',async e=>{
  const tab=e.target.closest?.('.admin-tab');
  if(tab){
    e.preventDefault(); e.stopPropagation();
    document.querySelectorAll('.admin-tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.admin-view').forEach(x=>x.classList.add('hidden'));
    tab.classList.add('active');
    const view=$('tab-'+tab.dataset.tab);
    if(view) view.classList.remove('hidden');
    setAdminMenu(false);
    if(tab.dataset.tab==='messages') await refreshAdminMessages();
    if(tab.dataset.tab==='orders') renderOrders(cachedOrders);
    return;
  }
  if(e.target.closest?.('.detail-btn')) await handleAdminDetailButton(e);
});

// Android/mobile reliability: pointerup is fired even when a browser delays/suppresses click.
document.addEventListener('pointerup',async e=>{
  if(e.pointerType==='mouse') return;
  if(e.target.closest?.('.detail-btn')) await handleAdminDetailButton(e);
},{passive:false});
function orderRow(o){return `<div class="mini-order"><b>#${esc(o.order_number)}</b><span>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim())}</span><span>${esc(o.customer_phone||'—')}</span><strong>${esc(statusNames[canonicalStatus(o.status)]||o.status||'—')}</strong><button type="button" class="detail-btn" data-order-id="${esc(o.id)}">فتح الطلب</button></div>`}
function renderOrders(orders){
  const q=($('orderSearch').value||'').trim().toLowerCase();
  const f=$('statusFilter').value||'';
  const rows=orders.filter(o=>{
    const st=canonicalStatus(o.status);
    const search=!q||String(o.order_number||'').toLowerCase().includes(q)||String(o.customer_phone||'').toLowerCase().includes(q);
    const statusOk=f==='cancelled'?st==='cancelled':(st!=='cancelled'&&(!f||(f==='processing'?processingStatuses.has(st):st===f)));
    return search&&statusOk;
  });
  $('ordersTable').innerHTML=rows.length?`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الطلب</th><th>العميل</th><th>الهاتف</th><th>الموقع</th><th>الكمية</th><th>السعر</th><th>الحالة</th><th>التاريخ</th><th></th></tr></thead><tbody>${rows.map(o=>`<tr><td>#${esc(o.order_number)}</td><td>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim()||'—')}</td><td>${esc(o.customer_phone||'—')}</td><td>${esc(o.source_site||'—')}</td><td>${Number(o.quantity)||1}</td><td>${formatMoney(o.total_price,o.currency)}</td><td>${esc(statusNames[canonicalStatus(o.status)]||o.status||'—')}</td><td>${formatDate(o.created_at)}</td><td><button type="button" class="detail-btn" data-order-id="${esc(o.id)}">فتح</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد طلبات مطابقة.</div>';
}
async function refreshAdmin(){const [or,ur,br]=await Promise.all([db.from('orders').select('*').order('created_at',{ascending:false}),db.from('profiles').select('*').order('created_at',{ascending:false})]);if(or.error){$('recentOrders').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';return}cachedOrders=or.data||[];const activeOrders=cachedOrders.filter(o=>canonicalStatus(o.status)!=='cancelled');$('sTotal').textContent=activeOrders.length;$('sNew').textContent=activeOrders.filter(o=>processingStatuses.has(canonicalStatus(o.status))).length;$('sAwaiting').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='awaiting_payment').length;$('sProof').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='payment_submitted').length;$('sPaid').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='payment_confirmed').length;$('sDone').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='delivered').length;$('sCancelled').textContent=cachedOrders.filter(o=>canonicalStatus(o.status)==='cancelled').length;$('recentOrders').innerHTML=activeOrders.length?activeOrders.slice(0,8).map(orderRow).join(''):'<div class="empty">لا توجد طلبات نشطة.</div>';renderOrders(cachedOrders);const users=ur.data||[];$('usersTable').innerHTML=users.length?`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الاسم</th><th>اللقب</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>${users.map(u=>`<tr><td>${esc(u.first_name||'—')}</td><td>${esc(u.last_name||'—')}</td><td>${esc(u.phone||'—')}</td><td>${formatDate(u.created_at)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا يوجد مستخدمون بعد.</div>';initIcons()}
async function refreshAdminMessages(){const box=$('adminMessagesList');box.innerHTML='<div class="empty">جارٍ تحميل رسائل العملاء…</div>';const {data,error}=await db.from('support_messages').select('id,user_id,message,sender_role,created_at,order_id').order('created_at',{ascending:false}).limit(200);if(error){box.innerHTML='<div class="empty">تعذر تحميل رسائل العملاء.</div>';return}const groups=new Map();for(const m of data||[]){if(!groups.has(m.user_id))groups.set(m.user_id,[]);groups.get(m.user_id).push(m)}const ids=[...groups.keys()];let profiles=[];if(ids.length){const r=await db.from('profiles').select('id,first_name,last_name,phone').in('id',ids);profiles=r.data||[]}const pm=new Map(profiles.map(x=>[x.id,x]));box.innerHTML=ids.length?[...groups.entries()].map(([uid,arr])=>{const p=pm.get(uid)||{};return `<article class="admin-chat-card"><div class="admin-chat-head"><div><b>${esc(`${p.first_name||''} ${p.last_name||''}`.trim()||'عميل')}</b><small>${esc(p.phone||'')}</small></div><span>${formatDate(arr[0].created_at)}</span></div><div class="admin-chat-thread">${arr.slice().reverse().map(m=>`<div class="chat-bubble ${m.sender_role==='admin'?'admin-msg':'mine'}"><p>${esc(m.message)}</p><small>${m.sender_role==='admin'?'FENK':'العميل'} • ${formatDate(m.created_at)}</small></div>`).join('')}</div><form class="admin-reply-form" data-user-id="${esc(uid)}"><textarea rows="2" maxlength="4000" placeholder="اكتب ردًا للعميل..."></textarea><button class="send" type="submit">إرسال الرد</button></form></article>`}).join(''):'<div class="empty">لا توجد رسائل من العملاء بعد.</div>';box.querySelectorAll('.admin-reply-form').forEach(f=>f.onsubmit=async e=>{e.preventDefault();const ta=f.querySelector('textarea'),text=ta.value.trim();if(!text)return;const b=f.querySelector('button');b.disabled=true;const {error}=await db.from('support_messages').insert({user_id:f.dataset.userId,sender_role:'admin',message:text});if(!error){ta.value='';await refreshAdminMessages()}else alert('تعذر إرسال الرد.');b.disabled=false});initIcons()}
async function createCustomerStatusNotification(order, oldStatus, newStatus, oldPaymentInfo=''){
  if(!order?.user_id)return {ok:false,reason:'NO_USER'};
  const paymentInfo=String(order.payment_info||'').trim();
  const adminNote=String(order.admin_note||'').trim();
  const total=Number(order.total_price);
  const paymentChanged=paymentInfo!==String(oldPaymentInfo||'').trim();
  // Important: if the order is already confirmed and the admin only adds/changes
  // the payment information, still send the payment details to the customer.
  // Notify when payment information becomes available, even while the order is still waiting for payment.
  // Also notify on confirmation, and when payment information is changed after confirmation.
  if(oldStatus===newStatus && !(paymentChanged && paymentInfo))return {ok:true,skipped:true};
  const labels={received:'تم استلام طلبك',pricing:'تم تحديد سعر طلبك',awaiting_payment:'طلبك بانتظار الدفع',payment_submitted:'تم استلام وصل الدفع الخاص بطلبك',payment_confirmed:'تم قبول طلبك وتأكيد الدفع ✓',purchasing:'جارٍ تجهيز طلبك للشراء',shipped:'تم شحن طلبك',arrived_algeria:'وصل طلبك إلى الجزائر',out_for_delivery:'طلبك خرج للتوصيل',delivered:'تم تسليم طلبك',cancelled:'تم إلغاء طلبك'};
  const paymentAvailable=!!paymentInfo && paymentChanged;
  const title=newStatus==='payment_confirmed'?'تم قبول طلبك وتأكيد الدفع ✓':(paymentAvailable?'معلومات الدفع متاحة 💳':(labels[newStatus]||'تم تحديث طلبك'));
  let message=paymentAvailable && newStatus==='awaiting_payment'
    ? `تم تحديد سعر طلبك #${order.order_number||''} وأصبحت معلومات الدفع متاحة.`
    : `تم تحديث حالة طلبك #${order.order_number||''}: ${labels[newStatus]||'تم تحديث طلبك'}.`;
  if(paymentInfo) message += `\n\n💳 معلومات الدفع: ${paymentInfo}`;
  if(adminNote) message += `\n📝 ملاحظة الإدارة: ${adminNote}`;
  if(Number.isFinite(total)&&total>0) message += `\n💰 المبلغ الإجمالي: ${total.toLocaleString('ar-DZ')} دج`;
  if(paymentInfo || newStatus==='payment_confirmed') message += '\n\nيمكنك فتح الطلب من الإشعار لمشاهدة التفاصيل كاملة.';
  const {error}=await db.from('order_notifications').insert({recipient_user_id:order.user_id,order_id:order.id,title,message,is_read:false});
  if(error){console.warn('Customer notification insert failed:',error);return {ok:false,error};}
  return {ok:true};
}

async function openOrderDetail(id){const o=cachedOrders.find(x=>String(x.id)===String(id));if(!o){console.warn('FENK: order not found',id,cachedOrders.length);const m=$('orderDetailMsg');if(m)m.textContent='لم يتم العثور على هذا الطلب.';return;}selectedOrderId=id;$('detailOrderNumber').textContent='#'+o.order_number;$('detailProductPrice').value=o.product_price??'';$('detailShipping').value=o.shipping_fee??'';$('detailService').value=o.service_fee??'';$('detailTotalPrice').value=o.total_price??'';$('detailStatus').value=canonicalStatus(o.status);$('detailCarrierName').value=o.carrier_name||'';$('detailTrackingNumber').value=o.tracking_number||'';$('detailTrackingUrl').value=o.tracking_url||'';$('detailPaymentInfo').value=o.payment_info||'';$('detailAdminNote').value=o.admin_note||'';const p=String(o.customer_phone||'').replace(/\D/g,'').replace(/^0/,'213');$('whatsappOrder').href=p?`https://wa.me/${p}?text=${encodeURIComponent(`مرحبًا ${o.customer_first_name||''}، معك FENK بخصوص طلبك #${o.order_number}.`)}`:'#';$('orderDetailContent').innerHTML=`<div class="detail-grid"><div><b>الاسم واللقب</b><span>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim()||'—')}</span></div><div><b>الهاتف</b><span>${esc(o.customer_phone||'—')}</span></div><div><b>الولاية</b><span>${esc(o.wilaya||'—')}</span></div><div><b>البلدية</b><span>${esc(o.commune||'—')}</span></div><div><b>الرمز البريدي</b><span>${esc(o.postal_code||'—')}</span></div><div class="full-field"><b>العنوان</b><span>${esc(o.address||'—')}</span></div><div><b>السلعة</b><span>${esc(o.product_name||'—')}</span></div><div><b>معلومات السلعة</b><span>${esc(o.product_info||'—')}</span></div><div><b>رابط السلعة</b><span>${o.product_url?`<a href="${esc(o.product_url)}" target="_blank" rel="noopener">فتح الرابط</a>`:'—'}</span></div><div><b>الكمية</b><span>${Number(o.quantity)||1}</span></div><div><b>تاريخ الطلب</b><span>${formatDate(o.created_at)}</span></div></div>`;$('orderDetailModal').classList.add('show')}
$('closeOrderDetail').onclick=()=>$('orderDetailModal').classList.remove('show');$('orderDetailModal').onclick=e=>{if(e.target===$('orderDetailModal'))$('orderDetailModal').classList.remove('show')};
$('saveOrderDetail').onclick=async()=>{if(!selectedOrderId)return;const b=$('saveOrderDetail');b.disabled=true;try{const pr=$('detailProductPrice').value===''?null:Number($('detailProductPrice').value),sh=$('detailShipping').value===''?null:Number($('detailShipping').value),sv=$('detailService').value===''?null:Number($('detailService').value);if([pr,sh,sv].some(x=>x!==null&&(!Number.isFinite(x)||x<0)))throw Error();const total=pr!==null&&sh!==null&&sv!==null?pr+sh+sv:null;let status=$('detailStatus').value;if(status==='pricing'&&(!Number.isFinite(total)||total<=0))throw Error();if(total!==null&&total>0&&status==='received')status='pricing';const previousOrder=cachedOrders.find(x=>String(x.id)===String(selectedOrderId))||{};const oldStatus=canonicalStatus(previousOrder.status);const oldPaymentInfo=String(previousOrder.payment_info||'').trim();const {error}=await db.from('orders').update({product_price:pr,shipping_fee:sh,service_fee:sv,status,carrier_name:$('detailCarrierName').value.trim()||null,tracking_number:$('detailTrackingNumber').value.trim()||null,tracking_url:$('detailTrackingUrl').value.trim()||null,payment_info:$('detailPaymentInfo').value.trim()||null,admin_note:$('detailAdminNote').value.trim()||null,updated_at:new Date().toISOString()}).eq('id',selectedOrderId);if(error)throw error;const updatedOrder={...previousOrder,status,payment_info:$('detailPaymentInfo').value.trim()||null,admin_note:$('detailAdminNote').value.trim()||null,total_price:total};const notif=await createCustomerStatusNotification(updatedOrder,oldStatus,status,oldPaymentInfo);$('orderDetailMsg').textContent=notif?.ok===false?'تم حفظ التعديلات، لكن تعذر إنشاء إشعار للزبون.':'تم حفظ التعديلات ✓';if(status==='cancelled'){$('orderDetailModal').classList.remove('show');selectedOrderId=null;}await refreshAdmin()}catch{$('orderDetailMsg').textContent='تعذر حفظ التعديلات.'}finally{b.disabled=false}};
$('orderSearch').oninput=()=>renderOrders(cachedOrders);$('statusFilter').onchange=()=>renderOrders(cachedOrders);
document.querySelectorAll('.stat-filter').forEach(card=>{const apply=()=>{const filter=card.dataset.filter||'';$('statusFilter').value=filter;const ordersTab=document.querySelector('.admin-tab[data-tab="orders"]');if(ordersTab){ordersTab.click();}else renderOrders(cachedOrders);};card.addEventListener('click',apply);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();apply();}});});
function recalcDetailTotal(){const a=Number($('detailProductPrice')?.value),b=Number($('detailShipping')?.value),c=Number($('detailService')?.value);const vals=[$('detailProductPrice')?.value,$('detailShipping')?.value,$('detailService')?.value];$('detailTotalPrice').value=vals.every(v=>v!=='')&&[a,b,c].every(Number.isFinite)?a+b+c:'';}
['detailProductPrice','detailShipping','detailService'].forEach(id=>$(id)?.addEventListener('input',recalcDetailTotal));
window.fenkOpenOrderDetail=openOrderDetail;
boot();
