# FENK V85 — Paid Advertisements

Added paid ads with Supabase-backed pricing, submissions, Baridimob proof upload, admin review, publishing/expiry, and revenue totals.

Apply the migration `supabase/migrations/20260921_paid_advertisements_v85.sql` to the existing FENK Supabase project before testing the feature.
