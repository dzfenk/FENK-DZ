
-- FENK V85: paid advertisements marketplace
create table if not exists public.ad_pricing (
  id uuid primary key default gen_random_uuid(),
  duration_days integer not null unique check (duration_days > 0),
  price_dzd numeric(12,2) not null check (price_dzd >= 0),
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.advertisements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  ad_type text not null default 'product',
  title text not null,
  description text,
  image_url text,
  contact_url text,
  contact_phone text,
  duration_days integer not null,
  price_dzd numeric(12,2) not null default 0,
  payment_method text not null default 'baridimob',
  payment_status text not null default 'pending'
    check (payment_status in ('pending','accepted','rejected')),
  ad_status text not null default 'pending'
    check (ad_status in ('pending','approved','rejected','expired','paused')),
  payment_proof_path text,
  starts_at timestamptz,
  ends_at timestamptz,
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists advertisements_user_created_idx
  on public.advertisements(user_id, created_at desc);
create index if not exists advertisements_public_idx
  on public.advertisements(ad_status, payment_status, starts_at, ends_at);
create index if not exists advertisements_payment_idx
  on public.advertisements(payment_status, created_at desc);

create or replace function public.advertisements_set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists advertisements_set_updated_at on public.advertisements;
create trigger advertisements_set_updated_at
before update on public.advertisements
for each row execute function public.advertisements_set_updated_at();

alter table public.ad_pricing enable row level security;
alter table public.advertisements enable row level security;

drop policy if exists ad_pricing_public_read on public.ad_pricing;
create policy ad_pricing_public_read on public.ad_pricing
for select to anon, authenticated
using (is_active = true or (select public.is_admin()));

drop policy if exists ad_pricing_admin_insert on public.ad_pricing;
drop policy if exists ad_pricing_admin_update on public.ad_pricing;
drop policy if exists ad_pricing_admin_delete on public.ad_pricing;
create policy ad_pricing_admin_insert on public.ad_pricing
for insert to authenticated with check ((select public.is_admin()));
create policy ad_pricing_admin_update on public.ad_pricing
for update to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));
create policy ad_pricing_admin_delete on public.ad_pricing
for delete to authenticated using ((select public.is_admin()));

drop policy if exists advertisements_public_read on public.advertisements;
create policy advertisements_public_read on public.advertisements
for select to anon, authenticated
using (
  (ad_status = 'approved'
   and payment_status = 'accepted'
   and starts_at is not null
   and ends_at is not null
   and starts_at <= now()
   and ends_at > now())
  or user_id = (select auth.uid())
  or (select public.is_admin())
);

drop policy if exists advertisements_self_insert on public.advertisements;
create policy advertisements_self_insert on public.advertisements
for insert to authenticated
with check (user_id = (select auth.uid()));

drop policy if exists advertisements_self_update on public.advertisements;
create policy advertisements_self_update on public.advertisements
for update to authenticated
using (user_id = (select auth.uid()) and ad_status in ('pending','rejected'))
with check (user_id = (select auth.uid()) and ad_status in ('pending','rejected'));

drop policy if exists advertisements_admin_update on public.advertisements;
create policy advertisements_admin_update on public.advertisements
for update to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));

-- Storage buckets for ad creative and payment proof.
insert into storage.buckets (id, name, public)
values ('advertisement-images','advertisement-images',true)
on conflict (id) do update set public = true;

insert into storage.buckets (id, name, public)
values ('advertisement-proofs','advertisement-proofs',false)
on conflict (id) do update set public = false;

drop policy if exists advertisement_images_public_read on storage.objects;
create policy advertisement_images_public_read on storage.objects
for select to anon, authenticated
using (bucket_id = 'advertisement-images');

drop policy if exists advertisement_images_self_insert on storage.objects;
create policy advertisement_images_self_insert on storage.objects
for insert to authenticated
with check (
  bucket_id = 'advertisement-images'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists advertisement_images_self_update on storage.objects;
create policy advertisement_images_self_update on storage.objects
for update to authenticated
using (
  bucket_id = 'advertisement-images'
  and (storage.foldername(name))[1] = (select auth.uid())::text
)
with check (
  bucket_id = 'advertisement-images'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists advertisement_images_self_delete on storage.objects;
create policy advertisement_images_self_delete on storage.objects
for delete to authenticated
using (
  bucket_id = 'advertisement-images'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists advertisement_proofs_self_insert on storage.objects;
create policy advertisement_proofs_self_insert on storage.objects
for insert to authenticated
with check (
  bucket_id = 'advertisement-proofs'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists advertisement_proofs_self_read on storage.objects;
create policy advertisement_proofs_self_read on storage.objects
for select to authenticated
using (
  bucket_id = 'advertisement-proofs'
  and (
    (storage.foldername(name))[1] = (select auth.uid())::text
    or (select public.is_admin())
  )
);

drop policy if exists advertisement_proofs_admin_delete on storage.objects;
create policy advertisement_proofs_admin_delete on storage.objects
for delete to authenticated
using (bucket_id = 'advertisement-proofs' and (select public.is_admin()));

-- Default prices requested for the first launch. Admin can edit them without code changes.
insert into public.ad_pricing (duration_days, price_dzd, sort_order)
values (3,500,1),(7,1000,2),(15,1500,3),(30,2500,4)
on conflict (duration_days) do nothing;
