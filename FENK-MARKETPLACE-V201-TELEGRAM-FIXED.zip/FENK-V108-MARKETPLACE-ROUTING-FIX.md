# FENK V108 — Marketplace routing fix

- Rebuilt marketplace-category.html with full head/CSS so it no longer renders as unstyled plain HTML.
- Cars, Products, Real Estate/Land are isolated category pages.
- General ads stay only on Marketplace (#ads).
- Added marketplace-publish.html?v=199 so “انشر إعلانك” opens the publishing form directly.
- Spare-parts icons point to Products.
- Marketplace advertising promo points to the Marketplace ads section only.
