# FENK Telegram Login — جاهز

Supabase Project URL:
https://wqfnzahjwlukncxlxdkp.supabase.co

Telegram Edge Function:
https://wqfnzahjwlukncxlxdkp.supabase.co/functions/v1/telegram-login

BotFather domain:
fenk.site

لا تضع Bot Token في ملفات الواجهة.
لا تغيّر Google Login أو بيانات Supabase الحالية.
