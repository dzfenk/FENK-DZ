# FENK V194 — Logo Control

Added Admin controls for the FENK logo used in the homepage header/footer.

## Admin → تحكم كامل في الصفحة → تحكم في شعار FENK العلوي
- Show/hide logo
- Image or video logo
- Upload image
- Upload video (MP4/WebM/MOV, max 50MB)
- Desktop width
- Mobile width
- Horizontal offset (left/right)
- Vertical offset (up/down)
- Alt text
- Restore original `assets/logo-clean.webp`

Existing logo remains the default and is not deleted or replaced automatically.
Hero image/video and Hero carousel controls remain intact.
