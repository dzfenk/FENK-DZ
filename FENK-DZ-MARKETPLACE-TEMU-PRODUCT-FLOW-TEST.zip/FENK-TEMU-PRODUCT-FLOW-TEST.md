# FENK — Temu Product Flow Test

This patch keeps the existing Marketplace architecture and adds a product-page/link flow using the existing `marketplace_ads.details` JSON field (no new database column required).

## Test example
- Product: Men's Quartz Watch
- FENK price: 1000 دج
- Product URL: https://share.temu.com/I40Hlh9w15B

## Flow
Marketplace ad → `marketplace-ad.html?id=...` → **🛒 تسوق الآن** → original product URL.

Publishers can enter the product URL in **رابط المنتج / الصفحة**. Admin can edit it from the Marketplace ad editor. The existing contact URL remains separate.
