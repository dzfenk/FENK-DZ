# FENK V13 — Google + WhatsApp + Orders

تم بناء هذه النسخة فوق مشروع FENK الحالي بدون إزالة الوظائف الأساسية.

## ما تم إضافته
- تسجيل الدخول Google مع Redirect يحافظ على مسار GitHub Pages `/FENK-DZ/`.
- الاسم، اللقب، الهاتف، الولاية، البلدية، الرمز البريدي، العنوان.
- اسم السلعة ومعلومات السلعة، رابط/صورة، الكمية.
- رسالة نجاح الطلب + حفظ الطلب في Supabase.
- شاشة «طلباتي» للزبون وشاشة «رسائلك» للإشعارات.
- لوحة Admin لفتح الطلب، السعر النهائي، الشحن، الخدمة، معلومات الدفع، الملاحظات والحالة.
- زر WhatsApp مباشر من تفاصيل الطلب إلى رقم الزبون.
- Telegram للإدارة فقط عبر Edge Function `telegram-order-notify`.
- صورة المنتج تُرسل إلى Telegram عبر Signed URL مؤقت؛ لا توجد مفاتيح سرية في الواجهة.

## الاختبارات
- `node --check app.js` ناجح.
- تم فحص توازن عناصر HTML الأساسية.
- لا يوجد نص «وصف المنتج» في نموذج الطلب.
- Supabase الحالي يحتوي مسبقًا على حقول الطلب الجديدة والحالات المطلوبة.


## V15 additions
- Customer account dashboard with profile editing, settings, logout, notifications, messages, addresses, FENK AI assistant, and WhatsApp.
- Customer order detail with visual status timeline, price breakdown, payment-proof upload, reorder, and rating UI.
- WhatsApp contact number: +213 778 939 292.
- Telegram remains admin-only for order notifications.
- Theme selection: light, dark, system.


## V33 — mobile polish and current wilayas
- Improved the actual mobile hero used by the current markup, with the lighter mobile artwork and a clear «أرسل رابط المنتج» CTA.
- Improved mobile order-form spacing, fields, upload card, marketplace buttons, modals, footer accordion behavior, and bottom navigation safe-area spacing.
- Added validation/sanitization for the postal code and local phone input without changing the database schema.
- Updated the customer Wilaya list from 58 to 69 using the 2026 territorial division; existing address/order fields and Supabase flow are preserved.
- No existing database data, tables, migrations, authentication flow, or Admin authorization code was removed.
