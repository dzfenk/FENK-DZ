const SUPABASE_URL = 'https://zfnlgzwvvytophdxtoks.supabase.co';
const FENK_WHATSAPP='213778939292';
const SUPABASE_KEY = 'sb_publishable_d8kkB1Nyfjlx8LD9LQ5Ogw_WZPbxL5k';
const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const $ = (id) => document.getElementById(id);

function initIcons(){try{window.lucide?.createIcons({attrs:{'stroke-width':2.1}})}catch(e){console.warn('Icons:',e)}}
function setMessage(el,text,type=''){if(!el)return;el.textContent=text||'';el.className=type}
function fenkToast(message,type='info'){
  let host=document.getElementById('fenkToastHost');
  if(!host){host=document.createElement('div');host.id='fenkToastHost';host.setAttribute('aria-live','polite');document.body.appendChild(host);}
  const item=document.createElement('div');item.className=`fenk-toast ${type}`;item.textContent=String(message||'');host.appendChild(item);
  requestAnimationFrame(()=>item.classList.add('show'));
  setTimeout(()=>{item.classList.remove('show');setTimeout(()=>item.remove(),220)},3000);
}
function fenkConfirm(message){
  return new Promise(resolve=>{
    let modal=document.getElementById('fenkConfirmModal');
    if(!modal){modal=document.createElement('div');modal.id='fenkConfirmModal';modal.className='fenk-confirm-modal';modal.innerHTML='<div class="fenk-confirm-box" role="dialog" aria-modal="true"><h3>تأكيد العملية</h3><p id="fenkConfirmText"></p><div class="fenk-confirm-actions"><button type="button" data-confirm-cancel>إلغاء</button><button type="button" data-confirm-ok>تأكيد</button></div></div>';document.body.appendChild(modal);}
    modal.querySelector('#fenkConfirmText').textContent=message;modal.classList.add('show');
    const finish=value=>{modal.classList.remove('show');resolve(value)};
    modal.querySelector('[data-confirm-cancel]').onclick=()=>finish(false);modal.querySelector('[data-confirm-ok]').onclick=()=>finish(true);
    modal.onclick=e=>{if(e.target===modal)finish(false)};
  });
}
function resolveProductImageUrl(raw){
  const value=String(raw||'').trim();if(!value)return Promise.resolve('assets/logo-clean.png');
  if(/^https?:\/\//i.test(value))return Promise.resolve(value);
  return db.storage.from('product-images').createSignedUrl(value,1800).then(({data,error})=>!error&&data?.signedUrl?data.signedUrl:'assets/logo-clean.png').catch(()=> 'assets/logo-clean.png');
}
async function hydrateProductImages(root=document){
  const imgs=[...root.querySelectorAll('img[data-product-image]')];
  await Promise.all(imgs.map(async img=>{const src=await resolveProductImageUrl(img.dataset.productImage);img.src=src;img.onerror=()=>{img.onerror=null;img.src='assets/logo-clean.png'};}));
}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function formatDate(v){try{const d=new Date(v);if(!v||Number.isNaN(d.getTime()))return '—';return d.toLocaleDateString('ar-DZ',{day:'2-digit',month:'2-digit',year:'numeric'})+' • '+d.toLocaleTimeString('ar-DZ',{hour:'2-digit',minute:'2-digit',hour12:true})}catch{return '—'}}
function formatMoney(v,c='DZD'){if(v===null||v===undefined||v==='')return 'قيد التحديد';const n=Number(v);return Number.isFinite(n)&&n>0?`${n.toLocaleString('ar-DZ')} ${c==='DZD'?'دج':c}`:'قيد التحديد'}
function formatFinalMoney(v,c='DZD'){const n=Number(v);return Number.isFinite(n)?`${n.toLocaleString('ar-DZ')} ${c==='DZD'?'دج':c}`:'قيد التحديد'}
function openAuth(message=''){ $('authModal')?.classList.add('show'); if(message)setMessage($('authMsg'),message,'error') }
function closeAuth(){ $('authModal')?.classList.remove('show') }

let qty=1, selectedSite='AliExpress', cachedOrders=[], selectedOrderId=null, orderSubmitting=false;
const statusNames={received:'تم استلام الطلب',pricing:'تم تحديد السعر',awaiting_payment:'بانتظار الدفع',payment_submitted:'تم إرسال وصل الدفع',payment_confirmed:'تم تأكيد الدفع',purchasing:'جارٍ شراء المنتج',shipped:'تم شحن المنتج',arrived_algeria:'وصل إلى الجزائر',out_for_delivery:'خرج للتوصيل',delivered:'تم التسليم',cancelled:'تم إلغاء الطلب'};
const statusOrder=['received','pricing','awaiting_payment','payment_submitted','payment_confirmed','purchasing','shipped','arrived_algeria','out_for_delivery','delivered'];
function canonicalStatus(s){const map={checking:'received',price_confirmation:'pricing',payment_proof_received:'payment_submitted',paid:'payment_confirmed',shipping:'shipped'};return map[s]||s||'received';}
function notificationMessage(n){const m=String(n?.message||'');const status=n?.order_id?((m.match(/(?:إلى:|الآن:)\s*([^\.]+?)(?:\.|$)/)||[])[1]||''):'';return m.replace(/\b(checking|price_confirmation|payment_proof_received|paid|shipping)\b/g, x=>statusNames[canonicalStatus(x)]||x);}

async function getProfile(user){
  if(!user)return null;
  const {data,error}=await db.from('profiles').select('id,first_name,last_name,full_name,phone,avatar_url').eq('id',user.id).maybeSingle();
  if(error){console.warn('Profile:',error.message);return null} return data||null;
}
function profileValues(user,profile=null){
  const m=user?.user_metadata||{}, full=profile?.full_name||m.full_name||'';
  const p=String(full).trim().split(/\s+/).filter(Boolean);
  return {first_name:profile?.first_name||m.first_name||p.shift()||'',last_name:profile?.last_name||m.last_name||p.join(' ')||'',phone:profile?.phone||m.phone||''};
}
async function fillOrderContact(user){
  const p=await getProfile(user),v=profileValues(user,p);
  ['orderFirstName','orderLastName','orderPhone'].forEach((id,i)=>{if($(id)&&!$(id).value)$(id).value=[v.first_name,v.last_name,v.phone][i]||''});
}
async function ensureProfileComplete(user,show=true){
  const p=await getProfile(user),v=profileValues(user,p),ok=!!(v.first_name.trim()&&v.last_name.trim()&&v.phone.trim());
  if(!ok&&show)await openProfileModal(user); return ok;
}
async function openProfileModal(user=null,message=''){
  const current=user||(await db.auth.getUser()).data.user;if(!current)return openAuth('سجّل الدخول أولًا باستخدام Google.');
  const p=await getProfile(current),v=profileValues(current,p);
  $('firstName').value=v.first_name;$('lastName').value=v.last_name;$('phone').value=v.phone;$('profileModal')?.classList.add('show');
  if(message)setMessage($('profileMsg'),message,'error');
}

$('googleLogin')?.addEventListener('click',async()=>{
  const b=$('googleLogin');if(b)b.disabled=true;setMessage($('authMsg'),'جارٍ فتح تسجيل الدخول بحساب Google…','success');
  try{
    // Preserve the GitHub Pages sub-path; using origin alone would return to the wrong page.
    const redirectTo=`${location.origin}${location.pathname}`;
    const {error}=await db.auth.signInWithOAuth({provider:'google',options:{redirectTo,queryParams:{prompt:'select_account'}}});
    if(error)setMessage($('authMsg'),error.message,'error');
  }catch(e){setMessage($('authMsg'),e?.message||'تعذر بدء تسجيل الدخول عبر Google.','error')}finally{if(b)b.disabled=false}
});

$('profileForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('انتهت الجلسة. سجّل الدخول باستخدام Google.');
  const firstName=$('firstName').value.trim(),lastName=$('lastName').value.trim(),phone=$('phone').value.trim();
  if(!firstName||!lastName||!phone)return setMessage($('profileMsg'),'أكمل الاسم واللقب ورقم الهاتف.','error');
  const normalizedPhone=normalizeAlgerianPhone(phone);if(!normalizedPhone)return setMessage($('profileMsg'),'أدخل رقمًا جزائريًا صحيحًا يبدأ بـ 05 أو 06 أو 07.','error');
  const b=$('saveProfile');b.disabled=true;b.textContent='جارٍ الحفظ…';
  try{
    const fullName=`${firstName} ${lastName}`.trim();
    const {error}=await db.from('profiles').upsert({id:user.id,first_name:firstName,last_name:lastName,full_name:fullName,phone:normalizedPhone,avatar_url:user.user_metadata?.avatar_url||null,updated_at:new Date().toISOString()},{onConflict:'id'});if(error)throw error;
    await db.auth.updateUser({data:{first_name:firstName,last_name:lastName,full_name:fullName,phone:normalizedPhone}});
    setMessage($('profileMsg'),'تم حفظ بياناتك بنجاح ✓','success');
    $('orderFirstName').value=firstName;$('orderLastName').value=lastName;$('orderPhone').value=normalizedPhone;
    setTimeout(()=>$('profileModal')?.classList.remove('show'),450);
  }catch(e){console.error(e);setMessage($('profileMsg'),e?.message||'تعذر حفظ البيانات. حاول مرة أخرى.','error')}finally{b.disabled=false;b.textContent='حفظ البيانات'}
});

// Product image
const imageInput=$('productImage');
imageInput?.addEventListener('change',()=>{
  const file=imageInput.files?.[0];if(!file){$('imagePreview')?.classList.remove('show');if($('imageName'))$('imageName').textContent='';return}
  if(!['image/jpeg','image/png','image/webp'].includes(file.type)){imageInput.value='';return setMessage($('orderMsg'),'اختر صورة JPG أو PNG أو WEBP فقط.','error')}
  if(file.size>5*1024*1024){imageInput.value='';return setMessage($('orderMsg'),'حجم الصورة يجب ألا يتجاوز 5MB.','error')}
  $('imageName').textContent=file.name;$('imagePreview').src=URL.createObjectURL(file);$('imagePreview').classList.add('show');setMessage($('orderMsg'),'تم اختيار الصورة بنجاح ✓','success');
});

document.querySelectorAll('[data-scroll]').forEach(el=>el.addEventListener('click',()=>document.querySelector(el.dataset.scroll)?.scrollIntoView({behavior:'smooth'})));
$('searchBtn')?.addEventListener('click',()=>{const q=$('siteSearch')?.value.trim()||'';if(/^https?:\/\//i.test(q)){$('productUrl').value=q;document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}else if(q){setMessage($('orderMsg'),'ألصق رابط المنتج أو اكتب رابطًا يبدأ بـ https://.','error');document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}});
$('siteSearch')?.addEventListener('keydown',e=>{if(e.key==='Enter')$('searchBtn')?.click()});
$('countryBtn')?.addEventListener('click',()=>document.querySelector('#order')?.scrollIntoView({behavior:'smooth'}));
$('closeMarket')?.addEventListener('click',()=>$('marketModal')?.classList.remove('show'));
$('marketModal')?.addEventListener('click',e=>{if(e.target===$('marketModal'))$('marketModal').classList.remove('show')});

for(const b of document.querySelectorAll('#sites button'))b.addEventListener('click',()=>{document.querySelectorAll('#sites button').forEach(x=>x.classList.remove('active'));b.classList.add('active');selectedSite=b.dataset.site||'موقع آخر'});
$('plus')?.addEventListener('click',()=>{$('qty').textContent=String(++qty)});
$('minus')?.addEventListener('click',()=>{$('qty').textContent=String(qty=Math.max(1,qty-1))});

async function handleAccountClick(){const {data:{user}}=await db.auth.getUser();if(user)return openAccountModal(user);openAuth()}
$('accountBtn')?.addEventListener('click',handleAccountClick);$('mobileAccount')?.addEventListener('click',handleAccountClick);
$('ordersBtn')?.addEventListener('click',()=>openCustomerOrders());

function renderTimeline(status){
  const steps=[['received','تم استلام الطلب'],['pricing','تم تحديد السعر'],['awaiting_payment','بانتظار الدفع'],['payment_submitted','تم إرسال وصل الدفع'],['payment_confirmed','تم تأكيد الدفع'],['purchasing','جارٍ شراء المنتج'],['shipped','تم الشحن'],['arrived_algeria','وصل إلى الجزائر'],['out_for_delivery','خرج للتوصيل'],['delivered','تم التسليم']];
  const currentStatus=canonicalStatus(status);
  if(currentStatus==='cancelled')return '<div class="order-timeline cancelled"><div class="timeline-current">تم إلغاء الطلب</div></div>';
  const current=Math.max(0,steps.findIndex(x=>x[0]===currentStatus));
  return `<div class="order-timeline">${steps.map((x,i)=>`<div class="timeline-step ${i<current?'done':''} ${i===current?'current':''}"><span>${i<current?'✓':i===current?'●':'○'}</span><small>${x[1]}</small></div>`).join('')}</div>`;
}

async function openCustomerOrders(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض طلباتك.');
  $('customerOrdersList').innerHTML='<div class="empty">جارٍ تحميل الطلبات…</div>';$('customerOrdersModal')?.classList.add('show');
  const {data,error}=await db.from('orders').select('id,order_number,status,source_site,product_name,product_info,product_image_url,quantity,product_price,shipping_fee,service_fee,total_price,currency,created_at').eq('user_id',user.id).order('created_at',{ascending:false});
  if(error)return $('customerOrdersList').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';
  $('customerOrdersList').innerHTML=data?.length?data.map(o=>`<article class="notification-item order-card" data-order-id="${esc(o.id)}"><div class="order-card-head"><b>#${esc(o.order_number)}</b><strong>${esc(statusNames[o.status]||'قيد المعالجة')}</strong></div><p>${esc(o.product_name||o.product_info||o.source_site||'طلب منتج')} • الكمية: ${Number(o.quantity)||1}</p><small>${formatMoney(o.total_price,o.currency)} • ${formatDate(o.created_at)}</small>${renderTimeline(o.status)}</article>`).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';
  initIcons();
}
$('closeCustomerOrders')?.addEventListener('click',()=>$('customerOrdersModal')?.classList.remove('show'));
$('customerOrdersModal')?.addEventListener('click',e=>{if(e.target===$('customerOrdersModal'))$('customerOrdersModal').classList.remove('show')});

async function openMessages(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا للتواصل مع FENK.');
  $('messagesList').innerHTML='<div class="empty">جارٍ تحميل المحادثة…</div>';$('messagesModal')?.classList.add('show');
  await loadCustomerMessages(user.id);
}
async function loadCustomerMessages(userId){
  const {data,error}=await db.from('support_messages').select('id,message,sender_role,is_read,created_at,order_id').eq('user_id',userId).order('created_at',{ascending:true}).limit(100);
  if(error){$('messagesList').innerHTML='<div class="empty error-empty">تعذر تحميل الرسائل الآن. حاول مرة أخرى.</div>';return setMessage($('messageMsg'),'تعذر تحميل الرسائل.','error')}
  $('messagesList').innerHTML=data?.length?data.map(m=>`<div class="chat-bubble ${m.sender_role==='customer'?'mine':'admin-msg'}"><p>${esc(m.message)}</p><small>${m.sender_role==='customer'?'أنت':'FENK'} • ${formatDate(m.created_at)}</small></div>`).join(''):'<div class="empty">لا توجد رسائل بعد. اكتب رسالتك وسيرد عليك فريق FENK.</div>';
  $('messagesList').scrollTop=$('messagesList').scrollHeight;
}
$('messageForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');
  const input=$('messageInput'),msg=input?.value.trim();if(!msg)return setMessage($('messageMsg'),'اكتب رسالتك أولًا.','error');
  const b=e.submitter||$('messageForm button');b.disabled=true;setMessage($('messageMsg'),'جارٍ إرسال الرسالة…','success');
  try{const {error}=await db.rpc('send_my_support_message',{p_message:msg,p_order_id:null});if(error)throw error;input.value='';setMessage($('messageMsg'),'تم إرسال رسالتك ✓','success');await loadCustomerMessages(user.id);}
  catch(err){console.warn('Messages send:',err);setMessage($('messageMsg'),'تعذر إرسال الرسالة. حاول مرة أخرى.','error')}finally{b.disabled=false}
});
$('messagesBtn')?.addEventListener('click',openMessages);$('mobileMessages')?.addEventListener('click',openMessages);
$('closeMessages')?.addEventListener('click',()=>$('messagesModal')?.classList.remove('show'));
$('messagesModal')?.addEventListener('click',e=>{if(e.target===$('messagesModal'))$('messagesModal').classList.remove('show')});

async function openNotifications(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض الإشعارات.');
  $('notificationsList').innerHTML='<div class="empty">جارٍ تحميل الإشعارات…</div>';$('notificationsModal')?.classList.add('show');
  const {data,error}=await db.from('notifications').select('id,title,message,is_read,order_id,created_at').eq('user_id',user.id).order('created_at',{ascending:false}).limit(50);
  if(error)return $('notificationsList').innerHTML='<div class="empty">تعذر تحميل الإشعارات.</div>';
  $('notificationsList').innerHTML=data?.length?data.map(n=>`<article class="notification-item notification-clickable ${n.is_read?'':'unread'}" data-notification-id="${esc(n.id)}" data-order-id="${esc(n.order_id||'')}"><div class="notification-title"><i data-lucide="bell"></i><b>${esc(n.title||'تحديث الطلب')}</b></div><p>${esc(notificationMessage(n))}</p><small>${formatDate(n.created_at)} ${n.order_id?'• اضغط لفتح الطلب':''}</small></article>`).join(''):'<div class="empty">لا توجد إشعارات بعد.</div>';
  $('notificationsList').querySelectorAll('.notification-clickable').forEach(item=>item.addEventListener('click',async()=>{const nid=item.dataset.notificationId,oid=item.dataset.orderId;item.classList.remove('unread');if(nid)await db.from('notifications').update({is_read:true}).eq('id',nid);updateNotificationBadge(user.id);if(oid){$('notificationsModal')?.classList.remove('show');await openCustomerOrders();setTimeout(()=>openCustomerOrderDetail(oid),120)}}));
  updateNotificationBadge(user.id);initIcons();
}
$('notificationsBtn')?.addEventListener('click',()=>openNotifications());
$('closeNotifications')?.addEventListener('click',()=>$('notificationsModal')?.classList.remove('show'));
$('notificationsModal')?.addEventListener('click',e=>{if(e.target===$('notificationsModal'))$('notificationsModal').classList.remove('show')});

async function updateNotificationBadge(userId=null){
  if(!userId){const {data:{user}}=await db.auth.getUser();userId=user?.id}
  const badge=$('notificationBadge');if(!badge)return;
  if(!userId){badge.textContent='0';badge.style.display='none';return}
  const {count}=await db.from('notifications').select('id',{count:'exact',head:true}).eq('user_id',userId).eq('is_read',false);
  const n=Number(count||0);badge.textContent=n>99?'99+':String(n);badge.style.display=n?'flex':'none';
}
$('closeProfile')?.addEventListener('click',()=>$('profileModal')?.classList.remove('show'));
$('profileModal')?.addEventListener('click',e=>{if(e.target===$('profileModal'))$('profileModal').classList.remove('show')});
$('closeAuth')?.addEventListener('click',closeAuth);$('authModal')?.addEventListener('click',e=>{if(e.target===$('authModal'))closeAuth()});

async function uploadProductImage(userId){
  const file=imageInput?.files?.[0];if(!file)return null;
  const ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[file.type];
  if(!ext)throw new Error('الصورة يجب أن تكون JPG أو PNG أو WEBP.');if(file.size>5*1024*1024)throw new Error('حجم الصورة يجب ألا يتجاوز 5MB.');
  const path=`${userId}/${crypto.randomUUID()}.${ext}`;const {error}=await db.storage.from('product-images').upload(path,file,{contentType:file.type,upsert:false});if(error)throw error;return path;
}

async function sendTelegramOrder(orderId){
  try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:orderId,event:'created'}});if(error)console.warn('Telegram:',error.message)}catch(e){console.warn('Telegram:',e)}
}

$('sendOrder')?.addEventListener('click',async()=>{
  if(orderSubmitting)return;
  setMessage($('orderMsg'),'');const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول باستخدام Google أولًا لإرسال الطلب.');
  const first=$('orderFirstName').value.trim(),last=$('orderLastName').value.trim(),phone=$('orderPhone').value.trim(),wilaya=$('orderWilaya').value.trim(),commune=$('orderCommune').value.trim(),postal=$('orderPostalCode').value.trim(),address=$('orderAddress').value.trim(),url=$('productUrl').value.trim(),productName=$('productName').value.trim(),info=$('productInfo').value.trim();
  if(!first||!last||!phone||!wilaya||!commune||!address)return setMessage($('orderMsg'),'أكمل الاسم واللقب والهاتف والولاية والبلدية والعنوان.','error');if(postal&&!/^\d{5}$/.test(postal))return setMessage($('orderMsg'),'الرمز البريدي يجب أن يتكون من 5 أرقام.','error');
  const normalizedOrderPhone=normalizeAlgerianPhone(phone);if(!normalizedOrderPhone)return setMessage($('orderMsg'),'أدخل رقمًا جزائريًا صحيحًا يبدأ بـ 05 أو 06 أو 07.','error');
  if(!url&&!imageInput?.files?.length)return setMessage($('orderMsg'),'أدخل رابط المنتج أو أرسل صورة المنتج.','error');
  if(url&&!/^https?:\/\//i.test(url))return setMessage($('orderMsg'),'رابط المنتج يجب أن يبدأ بـ https:// أو http://','error');
  orderSubmitting=true;
  const b=$('sendOrder');b.disabled=true;b.textContent='جارٍ إرسال الطلب…';
  try{
    const fullName=`${first} ${last}`.trim();
    const profileError=(await db.from('profiles').upsert({id:user.id,first_name:first,last_name:last,full_name:fullName,phone:normalizedOrderPhone,avatar_url:user.user_metadata?.avatar_url||null,updated_at:new Date().toISOString()},{onConflict:'id'})).error;if(profileError)throw profileError;
    const imagePath=await uploadProductImage(user.id);
    const payload={user_id:user.id,product_url:url||null,product_name:productName||null,product_info:info||null,product_image_url:imagePath,source_site:selectedSite,quantity:qty,customer_first_name:first,customer_last_name:last,customer_phone:normalizedOrderPhone,wilaya,commune,address,postal_code:postal||null,product_price:null,shipping_fee:null,service_fee:null,status:'received'};
    // IMPORTANT: a successful INSERT is the point of truth. Do not let any optional
    // follow-up (SELECT/Telegram/address sync/UI cleanup) turn a created order into
    // a false 'تعذر إرسال الطلب' message. This was the cause of the mismatch seen
    // on mobile: the DB trigger created the notification/order, while a later step
    // could still reject the whole click handler.
    const {error}=await db.from('orders').insert(payload);if(error)throw error;
    let createdOrderId=null, createdOrderNumber='';
    try{
      const r=await db.from('orders').select('id,order_number').eq('user_id',user.id).eq('status','received').order('created_at',{ascending:false}).limit(1).maybeSingle();
      if(!r.error&&r.data){createdOrderId=r.data.id;createdOrderNumber=r.data.order_number||'';}
    }catch(e){console.warn('Order confirmation lookup:',e)}
    setMessage($('orderMsg'),`✅ تم إرسال طلبك بنجاح\n📦 طلبك قيد المعالجة\n💬 سنتواصل معك عبر WhatsApp لتأكيد السعر والدفع.${createdOrderNumber?`\nرقم الطلب: #${createdOrderNumber}`:''}`,'success');
    if(createdOrderId)void sendTelegramOrder(createdOrderId);
    try{
      const saved=getSavedAddresses(); const currentAddr={id:crypto.randomUUID(),label:'العنوان الرئيسي',first_name:first,last_name:last,full_name,phone:normalizedOrderPhone,wilaya,commune,address,postal_code:postal||'',primary:saved.length===0||saved.every(x=>!x.primary)}; let merged=saved.filter(x=>(!(x.primary&&currentAddr.primary))); if(currentAddr.primary)merged=merged.map(x=>({...x,primary:false})); merged.unshift(currentAddr); setSavedAddresses(merged);
      await saveOrderAddressToDb(user,{first,last,phone:normalizedOrderPhone,wilaya,commune,address,postal});
    }catch(e){console.warn('Post-order address sync:',e)}
    try{$('productUrl').value='';$('productName').value='';$('productInfo').value='';imageInput.value='';$('imagePreview')?.classList.remove('show');$('imageName').textContent='';qty=1;$('qty').textContent='1';}catch(e){console.warn('Post-order UI cleanup:',e)}
  }catch(e){console.error('Order:',e);const msg=String(e?.message||'');let friendly='تعذر إرسال الطلب. حاول مرة أخرى.';if(/JWT|session|auth|unauthorized/i.test(msg))friendly='انتهت جلسة الدخول. سجّل الدخول مرة أخرى ثم أرسل الطلب.';else if(/row-level|policy|permission|not authorized|42501/i.test(msg))friendly='تعذر حفظ الطلب بسبب صلاحيات قاعدة البيانات. حاول مرة أخرى.';else if(/generated|total_price|column/i.test(msg))friendly='حدث خطأ في حساب السعر. تم تسجيل المشكلة.';setMessage($('orderMsg'),friendly,'error')}finally{b.disabled=false;b.textContent='إرسال الطلب ➤';orderSubmitting=false}
});

async function isAdmin(){const {data:{user}}=await db.auth.getUser();if(!user)return false;const {data,error}=await db.from('admins').select('user_id').eq('user_id',user.id).maybeSingle();if(error){console.warn('Admin:',error.message);return false}return !!data}
async function openAdmin(){if(!(await isAdmin()))return openAuth('هذا الحساب ليس Admin.');closeAuth();$('adminPanel').classList.add('show');const {data:{user}}=await db.auth.getUser();$('adminEmail').textContent=user?.email||'';await refreshAdmin();await refreshAdminMessages();}
$('adminBtn')?.addEventListener('click',openAdmin);$('closeAdmin')?.addEventListener('click',()=>$('adminPanel').classList.remove('show'));
document.querySelectorAll('.admin-tab').forEach(b=>b.addEventListener('click',async()=>{document.querySelectorAll('.admin-tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.admin-view').forEach(x=>x.classList.add('hidden'));b.classList.add('active');$('tab-'+b.dataset.tab)?.classList.remove('hidden');if(b.dataset.tab==='messages')await refreshAdminMessages();}));

function orderRow(o){return `<div class="mini-order"><b>#${esc(o.order_number)}</b><span>${esc(o.customer_first_name||'')} ${esc(o.customer_last_name||'')}</span><span>${esc(o.customer_phone||'—')}</span><strong>${esc(statusNames[o.status]||o.status||'—')}</strong><button type="button" class="detail-btn" data-order-id="${esc(o.id)}">فتح الطلب</button></div>`}
function renderOrders(orders){
  const q=($('orderSearch')?.value||'').trim().toLowerCase(),f=$('statusFilter')?.value||'';
  const rows=orders.filter(o=>(!q||String(o.order_number||'').toLowerCase().includes(q)||String(o.customer_phone||'').toLowerCase().includes(q))&&(!f||o.status===f));
  if(!rows.length){$('ordersTable').innerHTML='<div class="empty">لا توجد طلبات مطابقة.</div>';return}
  $('ordersTable').innerHTML=`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الطلب</th><th>العميل</th><th>الهاتف</th><th>الموقع</th><th>الكمية</th><th>السعر</th><th>الحالة</th><th>التاريخ</th><th></th></tr></thead><tbody>${rows.map(o=>`<tr><td>#${esc(o.order_number)}</td><td>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim()||'—')}</td><td>${esc(o.customer_phone||'—')}</td><td>${esc(o.source_site||'—')}</td><td>${Number(o.quantity)||1}</td><td>${formatMoney(o.total_price,o.currency)}</td><td>${esc(statusNames[o.status]||o.status||'—')}</td><td>${formatDate(o.created_at)}</td><td><button class="detail-btn" data-order-id="${esc(o.id)}">فتح</button></td></tr>`).join('')}</tbody></table></div>`;
  document.querySelectorAll('.detail-btn').forEach(b=>b.addEventListener('click',()=>openOrderDetail(b.dataset.orderId)));
}

async function refreshAdminMessages(){
  const box=$('adminMessagesList');if(!box)return;
  box.innerHTML='<div class="empty">جارٍ تحميل رسائل العملاء…</div>';
  const {data,error}=await db.from('support_messages').select('id,user_id,message,sender_role,is_read,created_at,order_id').order('created_at',{ascending:false}).limit(200);
  if(error)return box.innerHTML='<div class="empty">تعذر تحميل رسائل العملاء.</div>';
  const groups=new Map();for(const m of data||[]){if(!groups.has(m.user_id))groups.set(m.user_id,[]);groups.get(m.user_id).push(m)}
  const ids=[...groups.keys()];let profiles=[];if(ids.length){const r=await db.from('profiles').select('id,first_name,last_name,phone').in('id',ids);profiles=r.data||[]}
  const pm=new Map(profiles.map(x=>[x.id,x]));
  box.innerHTML=ids.length?[...groups.entries()].map(([uid,msgs])=>{const p=pm.get(uid)||{};const last=msgs[0];return `<article class="admin-chat-card"><div class="admin-chat-head"><div><b>${esc(`${p.first_name||''} ${p.last_name||''}`.trim()||'عميل')}</b><small>${esc(p.phone||'')}</small></div><span>${formatDate(last.created_at)}</span></div><div class="admin-chat-thread">${msgs.slice().reverse().map(m=>`<div class="chat-bubble ${m.sender_role==='admin'?'admin-msg':'mine'}"><p>${esc(m.message)}</p><small>${m.sender_role==='admin'?'FENK':'العميل'} • ${formatDate(m.created_at)}</small></div>`).join('')}</div><form class="admin-reply-form" data-user-id="${esc(uid)}"><textarea rows="2" maxlength="4000" placeholder="اكتب ردًا للعميل..."></textarea><button class="send" type="submit">إرسال الرد</button></form></article>`}).join(''):'<div class="empty">لا توجد رسائل من العملاء بعد.</div>';
  box.querySelectorAll('.admin-reply-form').forEach(form=>form.addEventListener('submit',async e=>{e.preventDefault();const textarea=form.querySelector('textarea'),message=textarea.value.trim(),uid=form.dataset.userId;if(!message)return;const btn=form.querySelector('button');btn.disabled=true;try{const {error}=await db.from('support_messages').insert({user_id:uid,sender_role:'admin',message});if(error)throw error;textarea.value='';await refreshAdminMessages();}catch(err){fenkToast('تعذر إرسال الرد.','error')}finally{btn.disabled=false}}));
  initIcons();
}

async function refreshAdmin(){
  const [or,ur,br]=await Promise.all([db.from('orders').select('*').order('created_at',{ascending:false}),db.from('profiles').select('*').order('created_at',{ascending:false}),db.from('banners').select('*').order('sort_order',{ascending:true})]);
  if(or.error){$('recentOrders').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';return}
  cachedOrders=or.data||[];$('sTotal').textContent=cachedOrders.length;$('sNew').textContent=cachedOrders.filter(o=>canonicalStatus(o.status)==='received').length;$('sPaid').textContent=cachedOrders.filter(o=>canonicalStatus(o.status)==='payment_confirmed').length;$('sDone').textContent=cachedOrders.filter(o=>o.status==='delivered').length;$('recentOrders').innerHTML=cachedOrders.length?cachedOrders.slice(0,8).map(orderRow).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';renderOrders(cachedOrders);initIcons();
  const users=ur.data||[];$('usersTable').innerHTML=users.length?`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الاسم</th><th>اللقب</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>${users.map(u=>`<tr><td>${esc(u.first_name||'—')}</td><td>${esc(u.last_name||'—')}</td><td>${esc(u.phone||'—')}</td><td>${formatDate(u.created_at)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا يوجد مستخدمون بعد.</div>';
  const banners=br.data||[];$('bannersList').innerHTML=banners.length?banners.map(b=>`<div class="banner-row"><b>${esc(b.title||'بنر')}</b><span>${b.active?'فعال':'متوقف'}</span></div>`).join(''):'<div class="empty">لا توجد بنرات بعد.</div>';
}

async function openOrderDetail(id){
  const order=cachedOrders.find(o=>o.id===id);if(!order)return;selectedOrderId=id;
  $('detailOrderNumber').textContent=`#${order.order_number}`;$('detailProductPrice').value=(order.product_price!=null&&Number(order.product_price)>0)?order.product_price:'';$('detailShipping').value=(order.shipping_fee!=null&&Number(order.shipping_fee)>0)?order.shipping_fee:'';$('detailService').value=(order.service_fee!=null&&Number(order.service_fee)>0)?order.service_fee:'';$('detailTotalPrice').value=(order.total_price!=null&&Number(order.total_price)>0)?order.total_price:'';$('detailStatus').value=canonicalStatus(order.status);$('detailCarrierName').value=order.carrier_name||'';$('detailTrackingNumber').value=order.tracking_number||'';$('detailTrackingUrl').value=order.tracking_url||'';$('detailPaymentInfo').value=order.payment_info||'';$('detailAdminNote').value=order.admin_note||'';
  const wa=normalizeWhatsApp(order.customer_phone||'');$('whatsappOrder').href=wa?`https://wa.me/${wa}?text=${encodeURIComponent(`مرحبًا ${order.customer_first_name||''}، معك FENK بخصوص طلبك #${order.order_number}.`)}`:'#';
  $('orderDetailContent').innerHTML=`<div class="detail-grid"><div><b>الاسم واللقب</b><span>${esc(`${order.customer_first_name||''} ${order.customer_last_name||''}`.trim()||'—')}</span></div><div><b>الهاتف</b><span>${esc(order.customer_phone||'—')}</span></div><div><b>الولاية</b><span>${esc(order.wilaya||'—')}</span></div><div><b>البلدية</b><span>${esc(order.commune||'—')}</span></div><div><b>الرمز البريدي</b><span>${esc(order.postal_code||'—')}</span></div><div class="full-field"><b>العنوان</b><span>${esc(order.address||'—')}</span></div><div><b>السلعة</b><span>${esc(order.product_name||'—')}</span></div><div><b>معلومات السلعة</b><span>${esc(order.product_info||'—')}</span></div><div><b>رابط السلعة</b><span>${order.product_url?`<a href="${esc(order.product_url)}" target="_blank" rel="noopener">فتح الرابط</a>`:'—'}</span></div><div><b>الكمية</b><span>${Number(order.quantity)||1}</span></div><div><b>تاريخ الطلب</b><span>${formatDate(order.created_at)}</span></div></div>`;
  $('orderDetailModal')?.classList.add('show');const proofHost=document.createElement('div');proofHost.className='proof-host';$('orderDetailContent')?.appendChild(proofHost);showProofLink(order,proofHost);initIcons();
}
function normalizeWhatsApp(phone){let p=String(phone||'').replace(/\D/g,'');if(p.startsWith('00'))p=p.slice(2);if(p.startsWith('0'))p='213'+p.slice(1);return p}
function normalizeAlgerianPhone(phone){let p=String(phone||'').replace(/\D/g,'');if(p.startsWith('00213'))p=p.slice(2);if(p.startsWith('213'))p=p.slice(3);if(p.length===9&&/^[567]/.test(p))return '+213'+p;if(p.length===10&&/^0[567]/.test(p))return '+213'+p.slice(1);return ''}
function validAlgerianPhone(phone){return /^\+213[567]\d{8}$/.test(normalizeAlgerianPhone(phone));}
function openFenkWhatsApp(message='مرحبًا FENK، أريد الاستفسار عن خدمة الطلب.') { window.open(`https://wa.me/${FENK_WHATSAPP}?text=${encodeURIComponent(message)}`,'_blank','noopener'); }
$('closeOrderDetail')?.addEventListener('click',()=>$('orderDetailModal')?.classList.remove('show'));
$('orderDetailModal')?.addEventListener('click',e=>{if(e.target===$('orderDetailModal'))$('orderDetailModal').classList.remove('show')});
$('saveOrderDetail')?.addEventListener('click',async()=>{
  if(!selectedOrderId)return;const b=$('saveOrderDetail');b.disabled=true;b.textContent='جارٍ الحفظ…';
  try{
    const productRaw=$('detailProductPrice').value,shippingRaw=$('detailShipping').value,serviceRaw=$('detailService').value;const productPrice=productRaw===''?null:Number(productRaw),shipping=shippingRaw===''?null:Number(shippingRaw),service=serviceRaw===''?null:Number(serviceRaw);if([productPrice,shipping,service].some(x=>x!==null&&(!Number.isFinite(x)||x<0)))throw new Error('تحقق من قيم الأسعار.');const total=productPrice!==null&&shipping!==null&&service!==null?productPrice+shipping+service:null;let status=$('detailStatus').value;if(status==='pricing'&&(!Number.isFinite(total)||total<=0))throw new Error('لا يمكن اعتماد حالة «تم تحديد السعر» قبل إدخال سعر المنتج والشحن والخدمة والمجموع أكبر من صفر.');if(total!==null&&total>0&&status==='received')status='pricing';
    const {data,error}=await db.from('orders').update({product_price:productPrice,shipping_fee:shipping,service_fee:service,status,carrier_name:$('detailCarrierName').value.trim()||null,tracking_number:$('detailTrackingNumber').value.trim()||null,tracking_url:$('detailTrackingUrl').value.trim()||null,payment_info:$('detailPaymentInfo').value.trim()||null,admin_note:$('detailAdminNote').value.trim()||null,updated_at:new Date().toISOString()}).eq('id',selectedOrderId).select().single();if(error)throw error;
    await notifyTelegram(data);setMessage($('orderDetailMsg'),'تم حفظ التعديلات وإرسال التحديث ✓','success');await refreshAdmin();
  }catch(e){setMessage($('orderDetailMsg'),'تعذر حفظ التعديلات، حاول مرة أخرى.','error')}finally{b.disabled=false;b.textContent='حفظ التعديلات'}
});
async function notifyTelegram(order){try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:order.id,event:'updated'}});if(error)console.warn('Telegram:',error.message)}catch(e){console.warn('Telegram:',e)}}
$('orderSearch')?.addEventListener('input',()=>renderOrders(cachedOrders));$('statusFilter')?.addEventListener('change',()=>renderOrders(cachedOrders));
$('telegramTest')?.addEventListener('click',async()=>{const m=$('telegramMsg');setMessage(m,'جارٍ اختبار Telegram…','success');if(!(await isAdmin()))return setMessage(m,'يجب تسجيل الدخول بحساب Admin.','error');const sample=cachedOrders[0];if(!sample)return setMessage(m,'أنشئ طلبًا أولًا لاختبار Telegram.','error');try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:sample.id,event:'test'}});if(error)throw error;setMessage(m,'تم إرسال اختبار Telegram بنجاح ✓','success')}catch(e){setMessage(m,e?.message||'تعذر إرسال اختبار Telegram.','error')}});
$('newsletterSubscribe')?.addEventListener('click',async()=>{const i=$('newsletterEmail'),v=(i?.value||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))return fenkToast('أدخل بريدًا إلكترونيًا صحيحًا.','error');const b=$('newsletterSubscribe');if(b)b.disabled=true;try{const {error}=await db.from('newsletter_subscribers').insert({email:v});if(error&&error.code!=='23505')throw error;fenkToast(error?.code==='23505'?'هذا البريد مشترك بالفعل ✓':'تم الاشتراك بنجاح ✓','success');i.value='';}catch(e){console.warn('Newsletter:',e);fenkToast('تعذر تسجيل البريد الآن. حاول مرة أخرى.','error')}finally{if(b)b.disabled=false}})

function updateAuthUI(user){const label=user?`مسجل: ${user.user_metadata?.full_name||user.email||'Google'}`:'تسجيل الدخول';if($('accountBtn'))$('accountBtn').title=label;if($('mobileAccount'))$('mobileAccount').title=label}

db.auth.onAuthStateChange((_event,session)=>{
  updateAuthUI(session?.user||null);
  updateNotificationBadge(session?.user?.id||null);
  if(session){setTimeout(async()=>{await fillOrderContact(session.user);const admin=await isAdmin();if($('adminBtn'))$('adminBtn').style.display=admin?'block':'none'},0)}else{if($('adminBtn'))$('adminBtn').style.display='none'}
});
(async()=>{const {data:{session}}=await db.auth.getSession();updateAuthUI(session?.user||null);updateNotificationBadge(session?.user?.id||null);if(session){await fillOrderContact(session.user);if(await isAdmin())$('adminBtn').style.display='block'}})();

document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;['authModal','profileModal','messagesModal','notificationsModal','customerOrdersModal','orderDetailModal','marketModal','adminPanel'].forEach(id=>$(id)?.classList.remove('show'))});
document.querySelectorAll('video').forEach(v=>v.addEventListener('error',()=>v.closest('.video-card')?.classList.add('video-fallback')));
document.querySelectorAll('[data-fenk-whatsapp]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();openFenkWhatsApp();}));
initIcons();window.FENK={version:'V20-MOBILE-COMPACT-RELIABILITY',supabaseUrl:SUPABASE_URL};

/* V15 account, settings, saved addresses, customer order detail, payment proof, review and smart assistant */
const FENK_APP_THEME_KEY='fenk_theme_v1', FENK_ADDR_KEY='fenk_addresses_v1', FENK_NOTIF_KEY='fenk_notifications_pref_v1';
const customerStatusOrder=statusOrder;
function getSavedAddresses(){try{return JSON.parse(localStorage.getItem(FENK_ADDR_KEY)||'[]')}catch{return []}}
function setSavedAddresses(a){localStorage.setItem(FENK_ADDR_KEY,JSON.stringify(a))}
function applyTheme(theme){const t=theme||localStorage.getItem(FENK_APP_THEME_KEY)||'system';document.documentElement.dataset.theme=t;document.body.classList.toggle('fenk-dark',t==='dark');if(t==='system'){const dark=window.matchMedia?.('(prefers-color-scheme: dark)').matches;document.body.classList.toggle('fenk-dark',!!dark)}}
applyTheme();window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change',()=>{if((localStorage.getItem(FENK_APP_THEME_KEY)||'system')==='system')applyTheme('system')});

async function openAccountModal(user=null){
  const current=user||(await db.auth.getUser()).data.user;if(!current)return openAuth('سجّل الدخول أولًا باستخدام Google.');
  const p=await getProfile(current),v=profileValues(current,p);
  $('accountName')&&( $('accountName').textContent=`${v.first_name} ${v.last_name}`.trim()||'مستخدم FENK');
  $('accountPhone')&&($('accountPhone').textContent=v.phone||'أضف رقم هاتفك');
  $('accountEmail')&&($('accountEmail').textContent=current.email||'حساب Google');
  const n=await getUnreadCount(current.id);if($('accountNotifCount'))$('accountNotifCount').textContent=n?String(n):'';
  $('accountModal')?.classList.add('show');initIcons();
}
async function getUnreadCount(uid){const {count}=await db.from('notifications').select('id',{count:'exact',head:true}).eq('user_id',uid).eq('is_read',false);return Number(count||0)}
$('accountEditProfile')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openProfileModal(); });
$('accountOrders')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openCustomerOrders(); });
$('accountNotifications')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openNotifications(); });
$('accountMessages')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openMessages(); });
$('accountAddresses')?.addEventListener('click',async()=>{ $('accountModal')?.classList.remove('show'); await openAddresses(); });
$('accountSettings')?.addEventListener('click',()=>{ $('accountModal')?.classList.remove('show'); openSettings(); });
$('accountAI')?.addEventListener('click',()=>{ $('accountModal')?.classList.remove('show'); $('fenkAiModal')?.classList.add('show');initIcons(); });
$('accountWhatsApp')?.addEventListener('click',()=>openFenkWhatsApp());
$('accountHelp')?.addEventListener('click',()=>openFenkWhatsApp('مرحبًا FENK، أحتاج مساعدة بخصوص خدمة الطلب.'));
$('accountData')?.addEventListener('click',()=>fenkToast('يمكنك تعديل معلوماتك وإدارة عناوينك من حسابك. لحماية الحساب، لا نعرض بياناتك للزوار.','info'));
$('accountLogout')?.addEventListener('click',async()=>{if(!(await fenkConfirm('هل تريد تسجيل الخروج من FENK؟')))return;await db.auth.signOut();$('accountModal')?.classList.remove('show');location.reload();});
$('closeAccount')?.addEventListener('click',()=>$('accountModal')?.classList.remove('show'));
$('accountModal')?.addEventListener('click',e=>{if(e.target===$('accountModal'))$('accountModal').classList.remove('show')});

function openSettings(){
  const theme=localStorage.getItem(FENK_APP_THEME_KEY)||'system';const notif=localStorage.getItem(FENK_NOTIF_KEY)!=='off';
  document.querySelectorAll('input[name="fenkTheme"]').forEach(x=>x.checked=x.value===theme);if($('settingsNotifications'))$('settingsNotifications').checked=notif;$('settingsModal')?.classList.add('show');initIcons();
}
document.querySelectorAll('input[name="fenkTheme"]').forEach(x=>x.addEventListener('change',()=>{localStorage.setItem(FENK_APP_THEME_KEY,x.value);applyTheme(x.value)}));
$('settingsNotifications')?.addEventListener('change',e=>localStorage.setItem(FENK_NOTIF_KEY,e.target.checked?'on':'off'));
$('closeSettings')?.addEventListener('click',()=>$('settingsModal')?.classList.remove('show'));$('settingsModal')?.addEventListener('click',e=>{if(e.target===$('settingsModal'))$('settingsModal').classList.remove('show')});

async function openAddresses(){
  const list=getSavedAddresses();renderAddresses(list);$('addressesModal')?.classList.add('show');initIcons();
}
function renderAddresses(list){const box=$('addressesList');if(!box)return;box.innerHTML=list.length?list.map((a,i)=>`<article class="saved-address ${a.primary?'primary':''}"><div><b>${esc(a.label||'العنوان الرئيسي')}</b>${a.primary?'<span class="address-badge">الرئيسي</span>':''}</div><p>${esc(a.full_name||'')} • ${esc(a.phone||'')}<br>${esc(a.wilaya||'')}، ${esc(a.commune||'')}<br>${esc(a.address||'')} ${a.postal_code?`• ${esc(a.postal_code)}`:''}</p><div class="address-actions"><button type="button" data-use-address="${i}">استخدام</button><button type="button" data-primary-address="${i}">جعله رئيسيًا</button><button type="button" data-delete-address="${i}">حذف</button></div></article>`).join(''):'<div class="empty">لا توجد عناوين محفوظة. أضف عنوانك مرة واحدة وسيتم استعماله في الطلبات القادمة.</div>';
  box.querySelectorAll('[data-use-address]').forEach(b=>b.addEventListener('click',()=>{fillOrderFromAddress(list[Number(b.dataset.useAddress)]);$('addressesModal')?.classList.remove('show');document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}));
  box.querySelectorAll('[data-primary-address]').forEach(b=>b.addEventListener('click',()=>{const i=Number(b.dataset.primaryAddress);const n=list.map((a,j)=>({...a,primary:i===j}));setSavedAddresses(n);renderAddresses(n)}));
  box.querySelectorAll('[data-delete-address]').forEach(b=>b.addEventListener('click',()=>{const i=Number(b.dataset.deleteAddress);list.splice(i,1);setSavedAddresses(list);renderAddresses(list)}));
}
function fillOrderFromAddress(a){if(!a)return;[['orderFirstName',a.first_name||a.full_name?.split(' ')[0]||''],['orderLastName',a.last_name||a.full_name?.split(' ').slice(1).join(' ')||''],['orderPhone',a.phone||''],['orderWilaya',a.wilaya||''],['orderCommune',a.commune||''],['orderPostalCode',a.postal_code||''],['orderAddress',a.address||'']].forEach(([id,v])=>{if($(id))$(id).value=v})}
$('addAddress')?.addEventListener('click',async()=>{const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');$('addressForm')?.reset();const p=await getProfile(user),v=profileValues(user,p);if($('addressFirstName'))$('addressFirstName').value=v.first_name;if($('addressLastName'))$('addressLastName').value=v.last_name;if($('addressPhone'))$('addressPhone').value=v.phone;$('addressEditModal')?.classList.add('show')});
$('closeAddresses')?.addEventListener('click',()=>$('addressesModal')?.classList.remove('show'));$('addressesModal')?.addEventListener('click',e=>{if(e.target===$('addressesModal'))$('addressesModal').classList.remove('show')});
$('closeAddressEdit')?.addEventListener('click',()=>$('addressEditModal')?.classList.remove('show'));$('addressEditModal')?.addEventListener('click',e=>{if(e.target===$('addressEditModal'))$('addressEditModal').classList.remove('show')});


async function openCustomerOrderDetail(id){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');
  $('customerOrderDetailContent').innerHTML='<div class="empty">جارٍ تحميل تفاصيل الطلب…</div>';$('customerOrderDetailModal')?.classList.add('show');
  const {data:o,error}=await db.from('orders').select('*').eq('id',id).eq('user_id',user.id).single();if(error||!o)return $('customerOrderDetailContent').innerHTML='<div class="empty">تعذر تحميل تفاصيل الطلب.</div>';
  const total=(o.total_price!=null&&Number(o.total_price)>0)?Number(o.total_price):null;const ship=total!==null?Number(o.shipping_fee||0):null;const service=total!==null?Number(o.service_fee||0):null;const prod=total!==null?(o.product_price!=null?Number(o.product_price):total-ship-service):null;
  const priced=total!==null;const priceHtml=priced?`<div class="price-card"><div><span>سعر المنتج</span><b>${formatFinalMoney(prod,o.currency)}</b></div><div><span>الشحن</span><b>${formatFinalMoney(ship,o.currency)}</b></div><div><span>خدمة FENK</span><b>${formatFinalMoney(service,o.currency)}</b></div><div class="price-total"><span>المجموع</span><b>${formatFinalMoney(total,o.currency)}</b></div></div>`:'<div class="pending-price"><b>السعر قيد التحديد</b><div>سعر المنتج: قيد التحديد</div><div>الشحن: قيد التحديد</div><div>خدمة FENK: قيد التحديد</div><div>المجموع: قيد التحديد</div></div>'; 
  $('customerOrderDetailNumber').textContent=`#${o.order_number}`;
  $('customerOrderDetailContent').innerHTML=`<div class="customer-order-summary">${o.product_image_url?`<div class="order-image-note">🖼️ تم إرفاق صورة المنتج</div>`:''}<h3>${esc(o.product_name||o.product_info||'طلب منتج')}</h3><p>الكمية: ${Number(o.quantity)||1} • ${formatDate(o.created_at)}</p>${priceHtml}${renderTimeline(o.status)}<div class="order-contact-actions"><a class="whatsapp-order-btn" href="https://wa.me/${FENK_WHATSAPP}?text=${encodeURIComponent(`مرحبًا FENK، بخصوص طلبي #${o.order_number}.`)}" target="_blank" rel="noopener">💬 تواصل عبر WhatsApp</a>${canonicalStatus(o.status)==='awaiting_payment'?'<button class="send" type="button" id="customerPayProofBtn">💳 إرسال وصل الدفع</button>':''}${o.status==='delivered'?'<button class="send secondary" type="button" id="reorderBtn">🔄 طلب نفس المنتج مرة أخرى</button>':''}</div>${o.status==='delivered'?'<div class="review-box"><h4>⭐ كيف كانت تجربتك مع FENK؟</h4><div class="stars" id="reviewStars">'+[1,2,3,4,5].map(i=>`<button type="button" data-rating="${i}">★</button>`).join('')+'</div><textarea id="reviewNote" rows="3" placeholder="ملاحظة اختيارية"></textarea><button type="button" class="send" id="sendReview">إرسال التقييم</button><p id="reviewMsg"></p></div>':''}</div>`;
  $('customerPayProofBtn')?.addEventListener('click',()=>openPaymentProof(o));$('reorderBtn')?.addEventListener('click',()=>reorderFromOrder(o));
  document.querySelectorAll('#reviewStars [data-rating]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#reviewStars [data-rating]').forEach(x=>x.classList.toggle('selected',Number(x.dataset.rating)<=Number(b.dataset.rating)));$('reviewStars').dataset.value=b.dataset.rating}));
  $('sendReview')?.addEventListener('click',async()=>{const rating=Number($('reviewStars')?.dataset.value||0);if(!rating)return setMessage($('reviewMsg'),'اختر عدد النجوم أولًا.','error');const {data:{user}}=await db.auth.getUser();const note=$('reviewNote').value.trim()||null;const {error}=await db.from('order_reviews').insert({order_id:o.id,user_id:user.id,rating,note});if(error){let reviews=[];try{reviews=JSON.parse(localStorage.getItem('fenk_reviews_v1')||'[]')}catch{}reviews.push({order_id:o.id,user_id:user.id,rating,note,created_at:new Date().toISOString()});localStorage.setItem('fenk_reviews_v1',JSON.stringify(reviews));setMessage($('reviewMsg'),'تم حفظ تقييمك على هذا الجهاز ⭐','success')}else{setMessage($('reviewMsg'),'شكرًا لتقييمك ⭐','success')}$('sendReview').disabled=true});
  initIcons();
}
function reorderFromOrder(o){$('customerOrderDetailModal')?.classList.remove('show');if($('productUrl'))$('productUrl').value=o.product_url||'';if($('productName'))$('productName').value=o.product_name||'';if($('productInfo'))$('productInfo').value=o.product_info||'';qty=Number(o.quantity)||1;if($('qty'))$('qty').textContent=String(qty);document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}
$('closeCustomerOrderDetail')?.addEventListener('click',()=>$('customerOrderDetailModal')?.classList.remove('show'));$('customerOrderDetailModal')?.addEventListener('click',e=>{if(e.target===$('customerOrderDetailModal'))$('customerOrderDetailModal').classList.remove('show')});

async function openPaymentProof(order){$('paymentProofOrderId').value=order.id;$('paymentProofFile').value='';$('paymentProofMsg').textContent='';$('paymentProofModal')?.classList.add('show');}
$('closePaymentProof')?.addEventListener('click',()=>$('paymentProofModal')?.classList.remove('show'));$('paymentProofModal')?.addEventListener('click',e=>{if(e.target===$('paymentProofModal'))$('paymentProofModal').classList.remove('show')});
$('paymentProofForm')?.addEventListener('submit',async e=>{e.preventDefault();const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('انتهت الجلسة.');const file=$('paymentProofFile')?.files?.[0],orderId=$('paymentProofOrderId')?.value;if(!file)return setMessage($('paymentProofMsg'),'اختر صورة الوصل.','error');if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>5*1024*1024)return setMessage($('paymentProofMsg'),'اختر JPG أو PNG أو WEBP بحجم لا يتجاوز 5MB.','error');const b=e.submitter;b.disabled=true;try{const ext=file.type.split('/')[1].replace('jpeg','jpg');const path=`${user.id}/payment-proof-${orderId}-${Date.now()}.${ext}`;const {error:upErr}=await db.storage.from('product-images').upload(path,file,{contentType:file.type,upsert:false});if(upErr)throw upErr;const {data:submitted,error}=await db.rpc('submit_payment_proof',{p_order_id:orderId,p_proof_path:path});if(error)throw error;if(!submitted)throw new Error('تعذر تسجيل وصل الدفع.');$('paymentProofModal')?.classList.remove('show');setMessage($('orderMsg'),'تم استلام وصل الدفع، وسيراجعه فريق FENK ✓','success');await openCustomerOrders();}catch(err){setMessage($('paymentProofMsg'),err?.message||'تعذر إرسال الوصل.','error')}finally{b.disabled=false}});

async function showProofLink(order,container){const pi=String(order.payment_info||'');if(!pi.startsWith('PROOF_PATH:')||!container)return;const path=pi.slice(11);const {data,error}=await db.storage.from('product-images').createSignedUrl(path,3600);if(!error&&data?.signedUrl){const a=document.createElement('a');a.href=data.signedUrl;a.target='_blank';a.rel='noopener';a.className='proof-link';a.textContent='🧾 فتح وصل الدفع';container.appendChild(a)}}

// Make order cards clickable and show the richer detail view.
const _oldOpenCustomerOrders=openCustomerOrders;
openCustomerOrders=async function(){await _oldOpenCustomerOrders();const list=$('customerOrdersList');list?.querySelectorAll('.order-card').forEach(card=>{card.style.cursor='pointer';card.addEventListener('click',e=>{if(e.target.closest('a,button'))return;if(card.dataset.orderId)openCustomerOrderDetail(card.dataset.orderId)})})};

// Smart FENK AI: helpful on-device assistant until an AI API key is configured server-side.
function aiReply(text){const t=String(text||'').toLowerCase();if(/ali|amazon|ebay|temu|shein|aliexpress|https?:\/\//i.test(t))return 'أرسل رابط المنتج في خانة الرابط، وسأساعدك في تحديد الموقع والبيانات المطلوبة لإرسال الطلب. لا أستطيع تأكيد السعر النهائي من الموقع تلقائيًا من داخل المتصفح.';if(t.includes('سعر')||t.includes('دج'))return 'السعر النهائي يحدده فريق FENK بعد مراجعة سعر المنتج والشحن ورسوم الخدمة، ثم يظهر لك داخل تفاصيل الطلب.';if(t.includes('مقارنة')||t.includes('قارن'))return 'أرسل رابطَي المنتجين أو اكتب اسميهما، وسأساعدك في تنظيم مقارنة واضحة بين السعر والمواصفات والكمية والشحن.';if(t.includes('دفع')||t.includes('بريد موب'))return 'الدفع في FENK يتم عبر بريد موب فقط. بعد تحديد السعر سيظهر لك المبلغ النهائي، ثم يمكنك إرسال صورة وصل الدفع من تفاصيل الطلب.';if(t.includes('طلب'))return 'لإنشاء طلب: أرسل رابط المنتج أو صورته، أكمل معلوماتك وعنوانك، ثم اضغط إرسال الطلب. سنتواصل معك عبر WhatsApp.';return 'مرحبًا 👋 أنا مساعد FENK. اسألني عن طلبك، السعر، الشحن، الدفع عبر بريد موب، أو أرسل رابط المنتج.'}
$('aiForm')?.addEventListener('submit',e=>{e.preventDefault();const input=$('aiInput'),t=input.value.trim();if(!t)return;const box=$('aiChat');box.insertAdjacentHTML('beforeend',`<div class="ai-bubble mine">${esc(t)}</div><div class="ai-bubble">${esc(aiReply(t))}</div>`);input.value='';box.scrollTop=box.scrollHeight});
$('closeFenkAi')?.addEventListener('click',()=>$('fenkAiModal')?.classList.remove('show'));$('fenkAiModal')?.addEventListener('click',e=>{if(e.target===$('fenkAiModal'))$('fenkAiModal').classList.remove('show')});

// Keep the saved primary address in sync with the order form after successful profile/order entry.
const _oldSendOrderHandlerNote=true;
$('order')?.addEventListener('submit',()=>{});

// Mobile navigation uses a fixed five/six-item layout in the HTML; keep the badge synced.
const _oldUpdateBadge=updateNotificationBadge;updateNotificationBadge=async function(uid=null){await _oldUpdateBadge(uid);const main=$('notificationBadge'),mob=$('mobileNotificationBadge');if(mob){const n=main?.textContent||'';mob.textContent=n;mob.style.display=main?.style.display==='none'?'none':'flex'}};

// Do not auto-fill a saved address into a new order. Users can explicitly choose a saved address.



/* V17 reliability layer: canonical statuses, persistent addresses, direct notification routing and mobile-safe UI. */
const FENK_WILAYAS=['01 أدرار','02 الشلف','03 الأغواط','04 أم البواقي','05 باتنة','06 بجاية','07 بسكرة','08 بشار','09 البليدة','10 البويرة','11 تمنراست','12 تبسة','13 تلمسان','14 تيارت','15 تيزي وزو','16 الجزائر','17 الجلفة','18 جيجل','19 سطيف','20 سعيدة','21 سكيكدة','22 سيدي بلعباس','23 عنابة','24 قالمة','25 قسنطينة','26 المدية','27 مستغانم','28 المسيلة','29 معسكر','30 ورقلة','31 وهران','32 البيض','33 إليزي','34 برج بوعريريج','35 بومرداس','36 الطارف','37 تندوف','38 تيسمسيلت','39 الوادي','40 خنشلة','41 سوق أهراس','42 تيبازة','43 ميلة','44 عين الدفلى','45 النعامة','46 عين تموشنت','47 غرداية','48 غليزان','49 تيميمون','50 برج باجي مختار','51 أولاد جلال','52 بني عباس','53 إن صالح','54 إن قزام','55 تقرت','56 جانت','57 المغير','58 المنيعة','59 أفلو','60 بريكة','61 القنطرة','62 بئر العاتر','63 العريشة','64 قصر الشلالة','65 عين وسارة','66 مسعد','67 قصر البخاري','68 بوسعادة','69 الأبيض سيدي الشيخ'];
function populateWilayas(){['orderWilaya','addressWilaya'].forEach(id=>{const el=$(id);if(!el)return;const old=el.value;el.innerHTML='<option value="">اختر الولاية</option>'+FENK_WILAYAS.map(w=>`<option value="${esc(w)}">${esc(w)}</option>`).join('');if(old)el.value=old;});}
populateWilayas();
function phoneDisplayValue(v){const n=normalizeAlgerianPhone(v);return n?n.replace('+213',''):(String(v||'').startsWith('+213')?String(v).slice(4):String(v||''));}
['phone','orderPhone','addressPhone'].forEach(id=>{const el=$(id);if(el)el.value=phoneDisplayValue(el.value);el?.addEventListener('blur',()=>{const n=normalizeAlgerianPhone(el.value);if(n)el.value=n.replace('+213','');});});

// Direct notification -> exact order. No intermediate orders list.
openNotifications=async function(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض الإشعارات.');
  const box=$('notificationsList');box.innerHTML='<div class="empty">جارٍ تحميل الإشعارات…</div>';$('notificationsModal')?.classList.add('show');
  const {data,error}=await db.from('notifications').select('id,title,message,is_read,order_id,created_at').eq('user_id',user.id).order('created_at',{ascending:false}).limit(50);
  if(error){box.innerHTML='<div class="empty error-empty">تعذر تحميل الإشعارات الآن. حاول مرة أخرى.</div>';return;}
  box.innerHTML=data?.length?`<div class="notifications-toolbar"><span>اسحب الإشعار أو اضغط عليه لفتح الطلب</span><button type="button" id="deleteReadNotifications" class="delete-read-btn">حذف المقروءة</button></div>`+data.map(n=>`<article class="notification-item notification-clickable ${n.is_read?'':'unread'}" data-notification-id="${esc(n.id)}" data-order-id="${esc(n.order_id||'')}"><div class="notification-row"><div class="notification-main"><div class="notification-title"><i data-lucide="bell"></i><b>${esc(n.title||'تحديث الطلب')}</b></div><p>${esc(notificationMessage(n))}</p><small>${formatDate(n.created_at)}${n.order_id?' • اضغط لفتح الطلب':''}</small></div><button type="button" class="notification-delete" data-delete-notification="${esc(n.id)}" aria-label="حذف الإشعار" title="حذف الإشعار"><i data-lucide="trash-2"></i></button></div></article>`).join(''):'<div class="empty">لا توجد إشعارات بعد.</div>';
  box.querySelectorAll('.notification-clickable').forEach(item=>item.addEventListener('click',async(e)=>{if(e.target.closest('.notification-delete'))return;const nid=item.dataset.notificationId,oid=item.dataset.orderId;if(nid)await db.from('notifications').update({is_read:true}).eq('id',nid).eq('user_id',user.id);item.classList.remove('unread');await updateNotificationBadge(user.id);if(oid){$('notificationsModal')?.classList.remove('show');await openCustomerOrderDetail(oid);}}));
  box.querySelectorAll('[data-delete-notification]').forEach(btn=>btn.addEventListener('click',async(e)=>{e.stopPropagation();const nid=btn.dataset.deleteNotification;if(!nid)return;if(!(await fenkConfirm('هل تريد حذف هذا الإشعار؟')))return;btn.disabled=true;btn.innerHTML='<span class="delete-spinner">…</span>';const {data:deleted,error}=await db.rpc('delete_my_notification',{p_notification_id:Number(nid)});if(error||deleted!==true){btn.disabled=false;btn.innerHTML='<i data-lucide="trash-2"></i>';fenkToast('تعذر حذف الإشعار، حاول مرة أخرى.','error');initIcons();return;}document.querySelector(`[data-notification-id="${CSS.escape(nid)}"]`)?.remove();await updateNotificationBadge(user.id);if(!box.querySelector('.notification-clickable'))box.innerHTML='<div class="empty">لا توجد إشعارات بعد.</div>'; }));
  $('deleteReadNotifications')?.addEventListener('click',async()=>{const btn=$('deleteReadNotifications');if(!btn)return;if(!(await fenkConfirm('حذف جميع الإشعارات المقروءة؟')))return;btn.disabled=true;btn.textContent='جارٍ الحذف…';const {data:deleted,error}=await db.rpc('delete_my_read_notifications');if(error){btn.disabled=false;btn.textContent='حذف المقروءة';fenkToast('تعذر حذف الإشعارات، حاول مرة أخرى.','error');return;}await openNotifications();});
  initIcons();await updateNotificationBadge(user.id);
};
$('mobileNotification')?.addEventListener('click',openNotifications);

// Static bottom nav is initialized once and reserves its own space.
$('mobileNewOrder')?.addEventListener('click',e=>{e.preventDefault();document.querySelector('#order')?.scrollIntoView({behavior:'smooth',block:'start'});setTimeout(()=>{$('productUrl')?.focus({preventScroll:true});},450);});

// Customer orders: richer cards, no zero-price display.
openCustomerOrders=async function(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض طلباتك.');
  const list=$('customerOrdersList');list.innerHTML='<div class="empty">جارٍ تحميل الطلبات…</div>';$('customerOrdersModal')?.classList.add('show');
  const {data,error}=await db.from('orders').select('id,order_number,status,source_site,product_name,product_info,product_image_url,quantity,product_price,shipping_fee,service_fee,total_price,currency,created_at').eq('user_id',user.id).order('created_at',{ascending:false});
  if(error){list.innerHTML='<div class="empty error-empty">تعذر تحميل الطلبات الآن. حاول مرة أخرى.</div>';return;}
  list.innerHTML=data?.length?data.map(o=>{const priced=o.total_price!=null&&Number(o.total_price)>0;return `<article class="notification-item order-card" data-order-id="${esc(o.id)}"><div class="order-card-media">${o.product_image_url?`<div class="order-thumb"><span>صورة المنتج</span></div>`:'<div class="order-thumb placeholder-thumb"><i data-lucide="package"></i></div>'}<div class="order-card-body"><div class="order-card-head"><b>#${esc(o.order_number)}</b><strong>${esc(statusNames[canonicalStatus(o.status)]||'قيد المعالجة')}</strong></div><p>${esc(o.product_name||o.product_info||o.source_site||'طلب منتج')}</p><small>الكمية: ${Number(o.quantity)||1} • ${formatDate(o.created_at)}</small><div class="order-card-price">${priced?`المجموع: <b>${formatMoney(o.total_price,o.currency)}</b>`:'السعر: <b>قيد التحديد</b>'}</div><button type="button" class="detail-btn customer-detail-btn" data-order-id="${esc(o.id)}">تفاصيل الطلب</button></div></div></article>`}).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';
  list.querySelectorAll('.customer-detail-btn').forEach(b=>b.addEventListener('click',()=>openCustomerOrderDetail(b.dataset.orderId)));list.querySelectorAll('.order-card').forEach(card=>card.addEventListener('click',e=>{if(e.target.closest('button,a'))return;openCustomerOrderDetail(card.dataset.orderId)}));initIcons();
};
$('mobileOrders')?.addEventListener('click',()=>openCustomerOrders());

// Persistent address layer. Existing local addresses remain as a fallback/migration source.
async function getDbAddresses(userId){const {data,error}=await db.from('customer_addresses').select('*').eq('user_id',userId).order('is_primary',{ascending:false}).order('created_at',{ascending:false});if(error){console.warn('Addresses:',error.message);return null}return data||[]}
async function saveOrderAddressToDb(user,{first,last,phone,wilaya,commune,address,postal}){try{const {data:existing}=await db.from('customer_addresses').select('id').eq('user_id',user.id).limit(1);const r=await db.from('customer_addresses').insert({user_id:user.id,label:'العنوان الرئيسي',first_name:first,last_name:last,full_name:`${first} ${last}`,phone,wilaya,commune,address,postal_code:postal||null,is_primary:!existing?.length});if(r.error)console.warn('Order address:',r.error.message)}catch(e){console.warn('Order address:',e)}}
async function syncLegacyAddresses(user){const existing=await getDbAddresses(user.id);if(existing===null||existing.length)return existing;const local=getSavedAddresses();if(!local.length)return [];for(const a of local){const {error}=await db.from('customer_addresses').insert({user_id:user.id,label:a.label||'العنوان الرئيسي',first_name:a.first_name||'',last_name:a.last_name||'',full_name:a.full_name||`${a.first_name||''} ${a.last_name||''}`.trim(),phone:normalizeAlgerianPhone(a.phone)||a.phone,wilaya:a.wilaya||'',commune:a.commune||'',address:a.address||'',postal_code:a.postal_code||null,is_primary:!!a.primary});if(error)console.warn('Address migration:',error.message)}return await getDbAddresses(user.id)}
openAddresses=async function(){const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');const list=await syncLegacyAddresses(user);renderAddresses(list||[]);$('addressesModal')?.classList.add('show');initIcons();};
renderAddresses=function(list){
  const box=$('addressesList');if(!box)return;
  box.innerHTML=list.length?list.map((a,i)=>`<article class="saved-address ${a.is_primary?'primary':''}"><div><b>${esc(a.label||'العنوان الرئيسي')}</b>${a.is_primary?'<span class="address-badge">الرئيسي</span>':''}</div><p>${esc(a.full_name||'')} • ${esc(a.phone||'')}<br>${esc(a.wilaya||'')}، ${esc(a.commune||'')}<br>${esc(a.address||'')} ${a.postal_code?`• ${esc(a.postal_code)}`:''}</p><div class="address-actions"><button type="button" data-use-address="${i}">استخدام</button><button type="button" data-primary-address="${i}">جعله رئيسيًا</button><button type="button" data-delete-address="${i}">حذف</button></div></article>`).join(''):'<div class="empty">لا توجد عناوين محفوظة. أضف عنوانك مرة واحدة.</div>';
  box.querySelectorAll('[data-use-address]').forEach(b=>b.addEventListener('click',()=>{fillOrderFromAddress(list[Number(b.dataset.useAddress)]);$('addressesModal')?.classList.remove('show');document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}));
  box.querySelectorAll('[data-primary-address]').forEach(b=>b.addEventListener('click',async()=>{const a=list[Number(b.dataset.primaryAddress)];if(!a)return;const {data:{user}}=await db.auth.getUser();if(!user)return;const r1=await db.from('customer_addresses').update({is_primary:false}).eq('user_id',user.id).eq('is_primary',true);if(r1.error)return fenkToast('تعذر تحديث العنوان، حاول مرة أخرى.','error');const r2=await db.from('customer_addresses').update({is_primary:true,updated_at:new Date().toISOString()}).eq('id',a.id).eq('user_id',user.id);if(r2.error)return fenkToast('تعذر جعل العنوان رئيسيًا.','error');await openAddresses();}));
  box.querySelectorAll('[data-delete-address]').forEach(b=>b.addEventListener('click',async()=>{const a=list[Number(b.dataset.deleteAddress)];if(!a)return;if(!(await fenkConfirm('هل تريد حذف هذا العنوان؟')))return;const {data:{user}}=await db.auth.getUser();if(!user)return;const r=await db.from('customer_addresses').delete().eq('id',a.id).eq('user_id',user.id);if(r.error)return fenkToast('تعذر حذف العنوان.','error');await openAddresses();}));
};
$('addressForm')?.addEventListener('submit',async e=>{e.preventDefault();const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');const b=e.submitter||$('addressForm button[type=submit]');b.disabled=true;setMessage($('addressMsg'),'جارٍ حفظ العنوان…','success');try{const first=$('addressFirstName').value.trim(),last=$('addressLastName').value.trim(),rawPhone=$('addressPhone').value.trim(),phone=normalizeAlgerianPhone(rawPhone),wilaya=$('addressWilaya').value.trim(),commune=$('addressCommune').value.trim(),address=$('addressText').value.trim(),postal=$('addressPostal').value.trim();if(!first||!last||!phone||!wilaya||!commune||!address)throw new Error('أكمل بيانات العنوان المطلوبة.');if(!validAlgerianPhone(phone))throw new Error('أدخل رقمًا جزائريًا صحيحًا يبدأ بـ 05 أو 06 أو 07.');if(postal&&!/^\d{5}$/.test(postal))throw new Error('الرمز البريدي يجب أن يتكون من 5 أرقام.');const {data:existing}=await db.from('customer_addresses').select('id').eq('user_id',user.id).limit(1);if($('addressPrimary').checked){await db.from('customer_addresses').update({is_primary:false}).eq('user_id',user.id).eq('is_primary',true);}const {error}=await db.from('customer_addresses').insert({user_id:user.id,label:$('addressLabel').value.trim()||'العنوان الرئيسي',first_name:first,last_name:last,full_name:`${first} ${last}`,phone,wilaya,commune,address,postal_code:postal||null,is_primary:$('addressPrimary').checked||!existing?.length});if(error)throw error;setMessage($('addressMsg'),'تم حفظ العنوان بنجاح ✓','success');setTimeout(()=>{$('addressEditModal')?.classList.remove('show');openAddresses()},350)}catch(err){console.error('Address:',err);setMessage($('addressMsg'),'حدث خطأ أثناء حفظ البيانات، يرجى المحاولة مرة أخرى.','error')}finally{b.disabled=false;}});

// Saved addresses are loaded only when the user explicitly opens the address picker.

// Admin pricing inputs calculate the total instantly.
['detailProductPrice','detailShipping','detailService'].forEach(id=>$(id)?.addEventListener('input',()=>{const vals=['detailProductPrice','detailShipping','detailService'].map(x=>$(x)?.value);const nums=vals.map(x=>x===''?null:Number(x));$('detailTotalPrice').value=nums.every(x=>x!==null&&Number.isFinite(x)&&x>=0)?String(nums.reduce((a,b)=>a+b,0)):'';}));

/* V17 order wizard + final mobile polish */
(function initOrderWizard(){
  const section=document.querySelector('#order');if(!section)return;
  const steps=[...section.querySelectorAll('.order-steps > span')];const boxes=[...section.querySelectorAll('.form-grid > .form-box')];const productBox=boxes[0],siteBox=boxes[1],reviewBox=boxes[2],customer=siteBox?.querySelector('.customer-order-fields');
  let step=1;
  const nav=document.createElement('div');nav.className='wizard-actions';nav.innerHTML='<button type="button" class="wizard-prev" disabled>رجوع</button><button type="button" class="wizard-next">التالي</button>';
  section.querySelector('.order-steps')?.after(nav);
  const validPhone=()=>validAlgerianPhone($('orderPhone')?.value||'');
  function update(){
    steps.forEach((x,i)=>x.classList.toggle('active',i===step-1));
    productBox?.classList.toggle('wizard-hidden',step!==1);
    siteBox?.classList.toggle('wizard-hidden',!(step===2||step===3));
    customer?.classList.toggle('wizard-hidden',step!==3);
    reviewBox?.classList.toggle('wizard-hidden',step!==4);
    nav.querySelector('.wizard-prev').disabled=step===1;
    nav.querySelector('.wizard-next').textContent=step===4?'مراجعة وإرسال':'التالي';
    if(step===4)nav.querySelector('.wizard-next').style.display='none';else nav.querySelector('.wizard-next').style.display='inline-flex';
    section.classList.toggle('wizard-review',step===4);
  }
  nav.querySelector('.wizard-next').addEventListener('click',()=>{
    if(step===1){if(!$('productUrl')?.value.trim()&&!$('productImage')?.files?.length)return setMessage($('orderMsg'),'أدخل رابط المنتج أو اختر صورة أولًا.','error');if(step<4)step++;}
    else if(step===2){if(step<4)step++;}
    else if(step===3){if(!validPhone())return setMessage($('orderMsg'),'أدخل رقمًا جزائريًا صحيحًا يبدأ بـ 05 أو 06 أو 07.','error');if(!$('orderFirstName')?.value.trim()||!$('orderLastName')?.value.trim()||!$('orderWilaya')?.value||!$('orderCommune')?.value.trim()||!$('orderAddress')?.value.trim())return setMessage($('orderMsg'),'أكمل بيانات التوصيل قبل المتابعة.','error');if($('orderPostalCode')?.value.trim()&&!/^\d{5}$/.test($('orderPostalCode').value.trim()))return setMessage($('orderMsg'),'الرمز البريدي يجب أن يتكون من 5 أرقام.','error');if(step<4)step++;}
    update();section.scrollIntoView({behavior:'smooth',block:'start'});
  });
  nav.querySelector('.wizard-prev').addEventListener('click',()=>{if(step>1){step--;update();section.scrollIntoView({behavior:'smooth',block:'start'})}});
  steps.forEach((x,i)=>x.addEventListener('click',()=>{if(i<step-1||i===step){step=i+1;update()}}));
  update();
})();

// Mobile: keep the complete order form on one page; the legacy wizard remains available on desktop.
(function enableCompactMobileOrder(){
  if(!window.matchMedia?.('(max-width:800px)').matches)return;
  const section=document.querySelector('#order');if(!section)return;
  section.querySelectorAll('.wizard-hidden').forEach(el=>el.classList.remove('wizard-hidden'));
  section.querySelector('.wizard-actions')?.remove();
  section.querySelector('.order-steps')?.classList.add('mobile-order-steps-hidden');
})();

// Improve payment receipt UX without changing the existing storage flow.
$('paymentProofFile')?.addEventListener('change',()=>{const f=$('paymentProofFile').files?.[0],msg=$('paymentProofMsg');if(f){setMessage(msg,`✓ تم اختيار الصورة: ${f.name}`,'success')}});

// Product image in customer order detail: use a short-lived signed URL when the bucket is private.
async function appendCustomerProductImage(order,host){if(!order?.product_image_url||!host)return;try{const {data,error}=await db.storage.from('product-images').createSignedUrl(order.product_image_url,1800);if(error||!data?.signedUrl)return;host.innerHTML=`<button type="button" class="order-product-image-btn" aria-label="عرض صورة المنتج بالحجم الكامل"><img src="${esc(data.signedUrl)}" alt="صورة المنتج"></button>`;host.querySelector('button')?.addEventListener('click',()=>{const w=window.open('', '_blank');if(w){w.document.write('<title>صورة المنتج - FENK</title><style>body{margin:0;background:#000;display:grid;place-items:center;min-height:100vh}img{max-width:100%;max-height:100vh;object-fit:contain}</style><img src="'+data.signedUrl+'" alt="صورة المنتج">');w.document.close();}})}catch(e){console.warn('Product image:',e)}}

// Patch customer detail renderer to include the actual product image and canonical status text.
const _detailV17=openCustomerOrderDetail;
openCustomerOrderDetail=async function(id){await _detailV17(id);const {data:{user}}=await db.auth.getUser();if(!user)return;const {data:o}=await db.from('orders').select('product_image_url,status,order_number').eq('id',id).eq('user_id',user.id).maybeSingle();if(o){const root=$('customerOrderDetailContent');root?.querySelectorAll('.customer-product-image').forEach(x=>x.remove());const host=document.createElement('div');host.className='customer-product-image';root?.prepend(host);if(o.product_image_url)appendCustomerProductImage(o,host);else host.innerHTML='<div class="order-product-image-fallback">FENK</div>';}};

// Keep admin dashboard status counters canonical.
const _refreshAdminV17=refreshAdmin;
refreshAdmin=async function(){await _refreshAdminV17();if($('sNew'))$('sNew').textContent=cachedOrders.filter(o=>canonicalStatus(o.status)==='received').length;if($('sPaid'))$('sPaid').textContent=cachedOrders.filter(o=>canonicalStatus(o.status)==='payment_confirmed').length;};

// Educational images: open without cropping on tap/click.
document.querySelectorAll('.tutorial img').forEach(img=>img.addEventListener('click',()=>{const w=window.open('', '_blank');if(!w)return;w.document.write('<title>FENK - شرح</title><style>body{margin:0;background:#111;display:grid;place-items:center;min-height:100vh}img{max-width:100%;max-height:100vh;object-fit:contain}</style><img src="'+esc(img.src)+'" alt="شرح FENK">');w.document.close();}));


/* V19 — AliExpress-style customer orders + tracking */
function trackingStatusLabelV19(s){return statusNames[canonicalStatus(s)]||'قيد المعالجة'}
function trackingEventMarkupV19(history,currentStatus){
  const current=canonicalStatus(currentStatus);
  if(current==='cancelled')return '<div class="tracking-cancelled">تم إلغاء الطلب</div>' ;
  const byStatus={};
  (history||[]).forEach(h=>{const key=canonicalStatus(h.status);if(!byStatus[key])byStatus[key]=h});
  const currentIndex=Math.max(0,statusOrder.indexOf(current));
  return `<div class="tracking-line">${statusOrder.map((status,i)=>{const h=byStatus[status],state=i<currentIndex?'done':i===currentIndex?'current':'pending';return `<article class="tracking-event ${state}"><span class="tracking-dot">${state==='done'?'✓':state==='current'?'●':'○'}</span><div><b>${esc(statusNames[status])}</b>${h?.note?`<p>${esc(h.note)}</p>`:''}${h?.created_at?`<small>${esc(formatDate(h.created_at))}</small>`:''}</div></article>`}).join('')}</div>`;
}
async function openCustomerTrackingV19(id){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا.');
  const modal=$('customerTrackingModal');if(!modal)return openCustomerOrderDetail(id);
  $('trackingEvents').innerHTML='<div class="tracking-loading">جارٍ تحميل التتبع…</div>';modal.classList.add('show');
  const [{data:o,error:oe},{data:history,error:he}]=await Promise.all([
    db.from('orders').select('id,order_number,status,source_site,product_name,product_info,product_image_url,quantity,product_price,shipping_fee,service_fee,total_price,currency,created_at,updated_at,carrier_name,tracking_number,tracking_url').eq('id',id).eq('user_id',user.id).single(),
    db.from('order_status_history').select('status,note,created_at').eq('order_id',id).order('created_at',{ascending:false})
  ]);
  if(oe||!o){$('trackingEvents').innerHTML='<div class="empty">تعذر تحميل تتبع الطلب.</div>';return;}
  selectedOrderId=o.id;$('trackingOrderNumber').textContent=`#${o.order_number}`;
  const priced=o.total_price!=null&&Number(o.total_price)>0;
  const image=o.product_image_url?`<img data-product-image="${esc(o.product_image_url)}" src="assets/logo-clean.png" alt="صورة المنتج" loading="lazy">`:'<div class="tracking-placeholder">FENK</div>';
  $('trackingSummary').innerHTML=`<div class="tracking-status"><strong>${esc(trackingStatusLabelV19(o.status))}</strong><span>${esc(formatDate(o.updated_at||o.created_at))}</span></div><div class="tracking-product">${image}<div class="tracking-product-info"><b>${esc(o.product_name||o.product_info||'طلب منتج')}</b><small>${esc(o.source_site||'FENK')} • الكمية ${Number(o.quantity)||1}</small><strong>${priced?esc(formatMoney(o.total_price,o.currency)):'السعر قيد التحديد'}</strong></div></div><div class="tracking-carrier"><div><small>شركة الشحن</small><b>${esc(o.carrier_name||'سيتم تحديدها عند الشحن')}</b></div><div><small>رقم التتبع</small><b>${o.tracking_number?esc(o.tracking_number):'سيظهر بعد الشحن'}</b></div>${o.tracking_number?`<button type="button" id="copyTrackingNumber">نسخ</button>`:''}</div>`;
  $('trackingEvents').innerHTML=trackingEventMarkupV19(he?[]:history,o.status); await hydrateProductImages($('trackingSummary'));
  $('trackingWhatsapp').href=`https://wa.me/${FENK_WHATSAPP}?text=${encodeURIComponent(`السلام عليكم، أريد الاستفسار عن طلبي:\nرقم الطلب: ${o.order_number}${o.tracking_number?`\nرقم التتبع: ${o.tracking_number}`:''}`)}`;
  $('trackingOrderDetails').onclick=()=>{modal.classList.remove('show');openCustomerOrderDetail(o.id)};
  $('trackingBack').onclick=()=>{modal.classList.remove('show');openCustomerOrders()};
  $('copyTrackingNumber')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(o.tracking_number);fenkToast('تم نسخ رقم التتبع.','success')}catch{}});
  if(o.tracking_url){const link=document.createElement('a');link.href=o.tracking_url;link.target='_blank';link.rel='noopener';link.className='tracking-external';link.textContent='فتح التتبع الخارجي ↗';$('trackingSummary').appendChild(link)}
}

openCustomerOrders=async function(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض طلباتك.');
  const list=$('customerOrdersList');list.innerHTML='<div class="empty">جارٍ تحميل الطلبات…</div>';$('customerOrdersModal')?.classList.add('show');
  const {data,error}=await db.from('orders').select('id,order_number,status,source_site,product_name,product_info,product_image_url,quantity,total_price,currency,created_at,carrier_name,tracking_number').eq('user_id',user.id).order('created_at',{ascending:false});
  if(error){list.innerHTML='<div class="empty error-empty">تعذر تحميل الطلبات الآن. حاول مرة أخرى.</div>';return;}
  list.innerHTML=data?.length?data.map(o=>{const priced=o.total_price!=null&&Number(o.total_price)>0;return `<article class="fenk-order-card" data-order-id="${esc(o.id)}"><div class="fenk-order-top"><span>${esc(formatDate(o.created_at))}</span><b>${esc(trackingStatusLabelV19(o.status))}</b></div><div class="fenk-order-product"><div class="fenk-order-thumb">${o.product_image_url?`<img data-product-image="${esc(o.product_image_url)}" src="assets/logo-clean.png" alt="صورة المنتج" loading="lazy">`:'<img src="assets/logo-clean.png" alt="FENK" loading="lazy">'}</div><div class="fenk-order-info"><strong>${esc(o.product_name||o.product_info||'طلب منتج')}</strong><small>${esc(o.source_site||'FENK')} • الكمية ×${Number(o.quantity)||1}</small><b>${priced?esc(formatMoney(o.total_price,o.currency)):'قيد التحديد'}</b></div></div><div class="fenk-order-actions"><button type="button" class="track-btn" data-track-order="${esc(o.id)}">تتبع الطلب</button><button type="button" class="detail-btn" data-detail-order="${esc(o.id)}">تفاصيل الطلب</button></div>${o.tracking_number?`<div class="tracking-mini">رقم التتبع: <b>${esc(o.tracking_number)}</b></div>`:''}</article>`}).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';
  list.querySelectorAll('[data-track-order]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();openCustomerTrackingV19(b.dataset.trackOrder)}));
  list.querySelectorAll('[data-detail-order]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();openCustomerOrderDetail(b.dataset.detailOrder)}));
  list.querySelectorAll('.fenk-order-card').forEach(card=>card.addEventListener('click',e=>{if(e.target.closest('button,a'))return;openCustomerOrderDetail(card.dataset.orderId)}));
  initIcons(); await hydrateProductImages(list);
};
$('closeCustomerTracking')?.addEventListener('click',()=>$('customerTrackingModal')?.classList.remove('show'));
$('customerTrackingModal')?.addEventListener('click',e=>{if(e.target===$('customerTrackingModal'))$('customerTrackingModal').classList.remove('show')});

/* V21 reliability patches: exact notification routing, safe messages, no automatic postcode/address injection. */
(function patchNotificationRouting(){
  const originalOpenNotifications=window.openNotifications;
  window.openNotifications=async function(){
    await originalOpenNotifications();
    const box=$('notificationsList'); if(!box)return;
    box.querySelectorAll('.notification-clickable').forEach(item=>{
      const clone=item.cloneNode(true); item.replaceWith(clone);
      clone.addEventListener('click',async e=>{
        if(e.target.closest('[data-delete-notification]'))return;
        const nid=clone.dataset.notificationId, oid=clone.dataset.orderId;
        if(nid){
          const {error}=await db.from('notifications').update({is_read:true}).eq('id',nid).eq('user_id',(await db.auth.getUser()).data.user?.id||'');
          if(error)console.warn('Notification read:',error);
        }
        const {data:{user}}=await db.auth.getUser(); if(user)await updateNotificationBadge(user.id);
        if(oid){
          $('notificationsModal')?.classList.remove('show');
          await openCustomerOrderDetail(oid);
        }
      });
    });
  };
})();

/* Customer messages: one retry, friendly UI, technical error only in console. */
const _loadCustomerMessagesV21=loadCustomerMessages;
loadCustomerMessages=async function(userId){
  let result=await db.rpc('get_my_support_messages');
  if(result.error){
    console.warn('Messages load:',result.error);
    await new Promise(r=>setTimeout(r,250));
    result=await db.rpc('get_my_support_messages');
  }
  const box=$('messagesList');
  if(result.error){if(box)box.innerHTML='<div class="empty error-empty">تعذر تحميل الرسائل الآن. حاول مرة أخرى.</div>';return;}
  const data=result.data||[];
  if(box){box.innerHTML=data.length?data.map(m=>`<div class="chat-bubble ${m.sender_role==='customer'?'mine':'admin-msg'}"><p>${esc(m.message)}</p><small>${m.sender_role==='customer'?'أنت':'FENK'} • ${formatDate(m.created_at)}</small></div>`).join(''):'<div class="empty">لا توجد رسائل بعد. اكتب رسالتك وسيرد عليك فريق FENK.</div>';box.scrollTop=box.scrollHeight;}
};

/* Do not auto-fill postal code/address on page load. Saved addresses remain available through the address picker. */
(function disableAutomaticAddressInjection(){
  const oldFill=window.fillOrderFromAddress;
  window.fillOrderFromAddress=function(a){return oldFill(a);};
  // The old startup IIFE cannot be cancelled, but normalize an untouched form back to blank values.
  setTimeout(()=>{
    const postal=$('orderPostalCode');
    if(postal && !postal.dataset.userTouched && !postal.matches(':focus'))postal.value='';
  },600);
  $('orderPostalCode')?.addEventListener('input',e=>e.target.dataset.userTouched='1');
})();

/* Make order status display always use the canonical Supabase status. */
const _canonicalStatusV21=canonicalStatus;
window.canonicalStatus=function(s){return _canonicalStatusV21(s)};

/* V21: replace the legacy horizontal timeline renderer with a mobile-safe vertical renderer. */
renderTimeline=function(status){
  const steps=[['received','تم استلام الطلب'],['pricing','تم تحديد السعر'],['awaiting_payment','بانتظار الدفع'],['payment_submitted','تم إرسال وصل الدفع'],['payment_confirmed','تم تأكيد الدفع'],['purchasing','جارٍ شراء المنتج'],['shipped','تم الشحن'],['arrived_algeria','وصل إلى الجزائر'],['out_for_delivery','خرج للتوصيل'],['delivered','تم التسليم']];
  const currentStatus=canonicalStatus(status);
  if(currentStatus==='cancelled')return '<div class="order-timeline tracking-cancelled">تم إلغاء الطلب</div>';
  const current=Math.max(0,steps.findIndex(x=>x[0]===currentStatus));
  return `<div class="order-timeline">${steps.map((x,i)=>`<div class="timeline-step ${i<current?'done':''} ${i===current?'current':''} ${i>current?'pending':''}"><span>${i<current?'✓':i===current?'●':'○'}</span><small>${esc(x[1])}</small></div>`).join('')}</div>`;
};

/* V21: single authoritative notification renderer; keeps delete and exact-order routing working together. */
openNotifications=async function(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض الإشعارات.');
  const box=$('notificationsList');box.innerHTML='<div class="empty">جارٍ تحميل الإشعارات…</div>';$('notificationsModal')?.classList.add('show');
  const {data,error}=await db.from('notifications').select('id,title,message,is_read,order_id,created_at').eq('user_id',user.id).order('created_at',{ascending:false}).limit(50);
  if(error){console.warn('Notifications load:',error);box.innerHTML='<div class="empty error-empty">تعذر تحميل الإشعارات الآن. حاول مرة أخرى.</div>';return;}
  box.innerHTML=data?.length?`<div class="notifications-toolbar"><span>اضغط على الإشعار لفتح الطلب المرتبط</span><button type="button" id="deleteReadNotifications" class="delete-read-btn">حذف المقروءة</button></div>`+data.map(n=>`<article class="notification-item notification-clickable ${n.is_read?'':'unread'}" data-notification-id="${esc(n.id)}" data-order-id="${esc(n.order_id||'')}"><div class="notification-row"><div class="notification-main"><div class="notification-title"><i data-lucide="bell"></i><b>${esc(n.title||'تحديث الطلب')}</b></div><p>${esc(notificationMessage(n))}</p><small>${formatDate(n.created_at)}${n.order_id?' • فتح الطلب':''}</small></div><button type="button" class="notification-delete" data-delete-notification="${esc(n.id)}" aria-label="حذف الإشعار"><i data-lucide="trash-2"></i></button></div></article>`).join(''):'<div class="empty">لا توجد إشعارات حاليًا.</div>';
  box.querySelectorAll('[data-delete-notification]').forEach(btn=>btn.addEventListener('click',async e=>{
    e.stopPropagation();const nid=btn.dataset.deleteNotification;if(!(await fenkConfirm('هل تريد حذف هذا الإشعار؟')))return;btn.disabled=true;btn.textContent='…';
    const {data:deleted,error}=await db.rpc('delete_my_notification',{p_notification_id:Number(nid)});
    if(error||deleted!==true){console.warn('Notification delete:',error);btn.disabled=false;btn.innerHTML='<i data-lucide="trash-2"></i>';fenkToast('تعذر حذف الإشعار، حاول مرة أخرى.','error');initIcons();return;}
    box.querySelector(`[data-notification-id="${CSS.escape(nid)}"]`)?.remove();await updateNotificationBadge(user.id);fenkToast('تم حذف الإشعار بنجاح ✓','success');if(!box.querySelector('.notification-clickable'))box.innerHTML='<div class="empty">لا توجد إشعارات حاليًا.</div>';
  }));
  box.querySelectorAll('.notification-clickable').forEach(item=>item.addEventListener('click',async e=>{
    if(e.target.closest('[data-delete-notification]'))return;
    const nid=item.dataset.notificationId,oid=item.dataset.orderId;
    if(nid){const {error:readError}=await db.from('notifications').update({is_read:true}).eq('id',nid).eq('user_id',user.id);if(readError)console.warn('Notification read:',readError);}
    item.classList.remove('unread');await updateNotificationBadge(user.id);
    if(oid){$('notificationsModal')?.classList.remove('show');await openCustomerOrderDetail(oid);}else{fenkToast('هذا الإشعار غير مرتبط بطلب.','info');}
  }));
  $('deleteReadNotifications')?.addEventListener('click',async()=>{const btn=$('deleteReadNotifications');if(!(await fenkConfirm('حذف جميع الإشعارات المقروءة؟')))return;btn.disabled=true;btn.textContent='جارٍ الحذف…';const {data:deleted,error}=await db.rpc('delete_my_read_notifications');if(error){console.warn('Delete read notifications:',error);btn.disabled=false;btn.textContent='حذف المقروءة';fenkToast('تعذر حذف الإشعارات، حاول مرة أخرى.','error');return;}fenkToast(`تم حذف ${Number(deleted||0)} إشعار ✓`,'success');await openNotifications();});
  updateNotificationBadge(user.id);initIcons();
};

/* V21: customer detail images support both Supabase paths and normal external URLs. */
appendCustomerProductImage=async function(order,host){
  if(!order?.product_image_url||!host)return;
  try{
    const src=await resolveProductImageUrl(order.product_image_url);
    host.innerHTML=`<button type="button" class="order-product-image-btn" aria-label="عرض صورة المنتج بالحجم الكامل"><img src="${esc(src)}" alt="صورة المنتج" loading="lazy"></button>`;
    const img=host.querySelector('img');img.onerror=()=>{img.onerror=null;host.innerHTML='<div class="order-product-image-fallback">FENK</div>';};
    host.querySelector('button')?.addEventListener('click',()=>{const w=window.open('', '_blank');if(w){w.document.write('<title>صورة المنتج - FENK</title><style>body{margin:0;background:#000;display:grid;place-items:center;min-height:100vh}img{max-width:100%;max-height:100vh;object-fit:contain}</style><img src="'+src.replace(/"/g,'&quot;')+'" alt="صورة المنتج">');w.document.close();}});
  }catch(e){console.warn('Product image:',e);host.innerHTML='<div class="order-product-image-fallback">FENK</div>';}
};


/* FENK V33 — final mobile UX layer. Desktop layout is intentionally untouched. */
(function fenkV33MobileUX(){
  const isMobile=()=>window.matchMedia?.('(max-width:800px)').matches;
  const qs=s=>document.querySelector(s);
  const qsa=s=>[...document.querySelectorAll(s)];

  function setupFooterAccordions(){
    const footer=qs('#siteFooter'); if(!footer)return;
    qsa('#siteFooter > div').forEach(section=>{
      if(section.classList.contains('footer-brand')||section.classList.contains('newsletter')||section.classList.contains('copyright'))return;
      const h=section.querySelector(':scope > h3'); if(!h)return;
      section.classList.add('footer-accordion');
      h.setAttribute('role','button');
      h.setAttribute('tabindex','0');
      h.setAttribute('aria-expanded','false');
      const toggle=()=>{
        if(!isMobile())return;
        const open=section.classList.toggle('open');
        h.setAttribute('aria-expanded',String(open));
      };
      h.addEventListener('click',toggle);
      h.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}});
    });
  }

  function setupMobileInputs(){
    qsa('#orderPhone,#phone,#addressPhone').forEach(el=>{
      el.setAttribute('maxlength','9');
      el.setAttribute('inputmode','numeric');
      el.addEventListener('input',()=>{
        const digits=el.value.replace(/\D/g,'').replace(/^213/,'').slice(0,9);
        if(el.value!==digits)el.value=digits;
      });
    });
    const postal=qs('#orderPostalCode');
    if(postal){
      postal.addEventListener('input',()=>{postal.value=postal.value.replace(/\D/g,'').slice(0,5);});
    }
  }

  function setupMobileModalBehavior(){
    document.addEventListener('click',e=>{
      const target=e.target.closest?.('.mobile-hero-cta');
      if(target){
        requestAnimationFrame(()=>qs('#productUrl')?.focus({preventScroll:true}));
      }
    },{passive:true});
  }

  function applyMobileState(){
    const mobile=isMobile();
    document.body.classList.toggle('fenk-mobile',mobile);
    const nav=qs('.mobile-nav');
    if(nav){
      nav.setAttribute('aria-label','تنقل FENK على الهاتف');
      nav.querySelectorAll('button').forEach(b=>b.setAttribute('type','button'));
    }
  }

  setupFooterAccordions();
  setupMobileInputs();
  setupMobileModalBehavior();
  applyMobileState();
  window.addEventListener('resize',applyMobileState,{passive:true});
})();
