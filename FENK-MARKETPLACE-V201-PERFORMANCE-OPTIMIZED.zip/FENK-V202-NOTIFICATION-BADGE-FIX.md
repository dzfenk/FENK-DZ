# FENK — Notification unread badge fix

- Fixed the mobile bottom notification badge so it reads the real `order_notifications` unread count.
- Direct RLS count is checked first; the existing RPC is only a fallback.
- Badge shows `1`, `2`, ... or `99+`.
- Badge hides when there are no unread notifications.
- Refreshes when the page becomes visible or regains focus.
- No pages, data, payment code, Supabase settings, or existing notification UI were removed.
