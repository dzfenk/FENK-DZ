# FENK V66 — DzairPay Games Sync + HD + Game Music

- Preserved FENK header/identity.
- Removed the large promo carousel from the games catalog so the page follows the DzairPay top-ups flow: search/filter -> game cards.
- Direct game URL (`?game=Free%20Fire`) opens the selected game detail directly, hiding the catalog/promo until the user returns.
- Added a return-to-games button.
- Kept Supabase games/packages/orders and BaridiMob checkout unchanged.
- Verified active FENK game catalog contains 27 games matching the current DzairPay 27-game direct top-up catalog checked on 2026-09-19.
- Added 27 local HD game card/banner assets under `assets/game-hd/` for consistent rendering.
- Kept one dedicated music file per active game under `assets/game-music/`.
- Music source is selected from the game's slug, never randomly.
- Browser autoplay restrictions are handled: if autoplay is blocked, the music dock says to press play; after user interaction the selected game's track starts.
- No official copyrighted game soundtrack was added; existing local tracks remain dedicated per game.
