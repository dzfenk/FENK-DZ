
insert into storage.buckets (id,name,public)
values ('product-images','product-images',false)
on conflict (id) do nothing;

create policy "Users upload own product images"
on storage.objects for insert to authenticated
with check (
  bucket_id='product-images'
  and (storage.foldername(name))[1]=(select auth.uid()::text)
);

create policy "Users read own product images"
on storage.objects for select to authenticated
using (
  bucket_id='product-images'
  and owner_id=(select auth.uid()::text)
);

create policy "Admins manage product images"
on storage.objects for all to authenticated
using (bucket_id='product-images' and public.is_admin())
with check (bucket_id='product-images' and public.is_admin());

create or replace function public.notify_order_status()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if tg_op='INSERT' then
    insert into public.notifications(user_id,order_id,title,message)
    values(new.user_id,new.id,'تم استلام طلبك','تم استلام طلبك '||new.order_number||' بنجاح.');
  elsif new.status is distinct from old.status then
    insert into public.notifications(user_id,order_id,title,message)
    values(new.user_id,new.id,'تحديث الطلب','تم تغيير حالة الطلب '||new.order_number||' إلى: '||new.status);
  end if;
  return new;
end;
$$;

drop trigger if exists order_notification_trigger on public.orders;
create trigger order_notification_trigger
after insert or update of status on public.orders
for each row execute function public.notify_order_status();

alter publication supabase_realtime add table public.orders;
alter publication supabase_realtime add table public.notifications;
