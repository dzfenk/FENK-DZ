create or replace function public.notify_order_status()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare status_label text;
begin
 status_label:=case new.status when 'received' then 'قيد المعالجة' when 'checking' then 'قيد المعالجة' when 'price_confirmation' then 'تم تحديد السعر' when 'awaiting_payment' then 'بانتظار الدفع' when 'payment_proof_received' then 'تم استلام وصل الدفع' when 'paid' then 'تم تأكيد الدفع' when 'shipping' then 'قيد التوصيل' when 'arrived_algeria' then 'قيد التوصيل' when 'delivered' then 'تم التسليم' when 'cancelled' then 'ملغى' else new.status end;
 if tg_op='INSERT' then
  insert into public.notifications(user_id,order_id,title,message) values(new.user_id,new.id,'تم استلام طلبك','✅ تم استلام طلبك '||new.order_number||' بنجاح. 📦 طلبك قيد المعالجة. 💬 سنتواصل معك عبر WhatsApp لتأكيد السعر والدفع.');
 elsif new.status is distinct from old.status then
  insert into public.notifications(user_id,order_id,title,message) values(new.user_id,new.id,'تحديث الطلب','📦 طلبك '||new.order_number||' الآن: '||status_label||'.');
 end if;
 return new;
end;
$$;
drop trigger if exists order_notification_trigger on public.orders;
create trigger order_notification_trigger after insert or update of status on public.orders for each row execute function public.notify_order_status();
