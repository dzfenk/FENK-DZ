import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js/cors";

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, "Content-Type": "application/json" }
});

async function sha256(input: string) {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input)));
}
async function hmacSha256(key: Uint8Array, message: string) {
  const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", cryptoKey, new TextEncoder().encode(message)));
}
function toHex(bytes: Uint8Array) { return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join(""); }
function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const body = await req.json();
    const botToken = Deno.env.get("TELEGRAM_BOT_TOKEN");
    const secretKeys = JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") || "{}");
    const serviceKey = secretKeys.default;
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    if (!botToken || !serviceKey || !supabaseUrl) return json({ error: "Server is not configured" }, 500);

    const { hash, auth_date, id, first_name, last_name, username, photo_url } = body || {};
    if (!hash || !auth_date || !id || !first_name) return json({ error: "Invalid Telegram data" }, 400);
    const age = Math.floor(Date.now() / 1000) - Number(auth_date);
    if (!Number.isFinite(age) || age < -60 || age > 86400) return json({ error: "Telegram login expired" }, 401);

    const dataCheck = Object.entries(body)
      .filter(([key, value]) => key !== "hash" && value !== undefined && value !== null)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, value]) => `${key}=${String(value)}`).join("\n");
    const expected = toHex(await hmacSha256(await sha256(botToken), dataCheck));
    if (!safeEqual(expected, String(hash))) return json({ error: "Telegram verification failed" }, 401);

    const admin = createClient(supabaseUrl, serviceKey);
    const telegramId = String(id);
    const email = `telegram_${telegramId}@telegram.fenk-dz.local`;
    const password = `${crypto.randomUUID()}-${crypto.randomUUID()}!FENK`;
    const fullName = [first_name, last_name].filter(Boolean).join(" ").trim();

    const { data: account } = await admin.from("telegram_accounts").select("user_id").eq("chat_id", Number(id)).maybeSingle();
    let userId = account?.user_id || null;
    const metadata = { telegram_id: telegramId, telegram_username: username || null, telegram_first_name: first_name, telegram_last_name: last_name || null, full_name: fullName, avatar_url: photo_url || null };

    if (userId) {
      const { error } = await admin.auth.admin.updateUserById(userId, { password, user_metadata: metadata });
      if (error) throw error;
    } else {
      const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: metadata });
      if (error) throw error;
      userId = data.user?.id || null;
    }
    if (!userId) throw new Error("Could not create user");

    const { error: tgError } = await admin.from("telegram_accounts").upsert({ user_id: userId, chat_id: Number(id), username: username || null, first_name: first_name || null, linked_at: new Date().toISOString(), updated_at: new Date().toISOString() }, { onConflict: "user_id" });
    if (tgError) throw tgError;

    // Use the server-only key only inside this function to create the authenticated session.
    const { data: sessionData, error: signInError } = await admin.auth.signInWithPassword({ email, password });
    if (signInError || !sessionData.session) throw signInError || new Error("Could not create session");
    return json({ access_token: sessionData.session.access_token, refresh_token: sessionData.session.refresh_token });
  } catch (error) {
    console.error("telegram-login", error);
    return json({ error: error instanceof Error ? error.message : "Telegram login failed" }, 500);
  }
});
