import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js/cors";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", {headers:corsHeaders});
  const auth = req.headers.get("Authorization");
  if (!auth) return new Response(JSON.stringify({error:"Unauthorized"}),{status:401,headers:{...corsHeaders,"Content-Type":"application/json"}});
  const keys = JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") || "{}");
  const secret = keys.default;
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, secret);
  const token = auth.replace(/^Bearer\s+/i,"");
  const {data:{user}} = await admin.auth.getUser(token);
  if (!user) return new Response(JSON.stringify({error:"Unauthorized"}),{status:401,headers:{...corsHeaders,"Content-Type":"application/json"}});
  const {data:isAdmin} = await admin.from("admins").select("user_id").eq("user_id",user.id).maybeSingle();
  if (!isAdmin) return new Response(JSON.stringify({error:"Admin only"}),{status:403,headers:{...corsHeaders,"Content-Type":"application/json"}});
  const {order_id} = await req.json();
  const {data:order,error} = await admin.from("orders").select("*").eq("id",order_id).single();
  if(error || !order) return new Response(JSON.stringify({error:"Order not found"}),{status:404,headers:{...corsHeaders,"Content-Type":"application/json"}});
  const bot=Deno.env.get("TELEGRAM_BOT_TOKEN"), chat=Deno.env.get("TELEGRAM_ADMIN_CHAT_ID");
  if(!bot || !chat) return new Response(JSON.stringify({configured:false,message:"Telegram secrets are not configured"}),{headers:{...corsHeaders,"Content-Type":"application/json"}});
  const text=`🛒 FENK DZ\\n\\nطلب جديد/تحديث\\nرقم الطلب: #${order.order_number}\\nالموقع: ${order.source_site}\\nالكمية: ${order.quantity}\\nالحالة: ${order.status}\\nالسعر: ${order.total_price} ${order.currency}\\n\\n${order.product_url || ""}`;
  const r=await fetch(`https://api.telegram.org/bot${bot}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:chat,text})});
  const result=await r.json();
  return new Response(JSON.stringify(result),{status:r.ok?200:502,headers:{...corsHeaders,"Content-Type":"application/json"}});
});
