const SUPABASE_URL = 'https://zfnlgzwvvytophdxtoks.supabase.co';
const SUPABASE_KEY = 'sb_publishable_d8kkB1Nyfjlx8LD9LQ5Ogw_WZPbxL5k';
const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const $ = (id) => document.getElementById(id);

function initIcons(){try{window.lucide?.createIcons({attrs:{'stroke-width':2.1}})}catch(e){console.warn('Icons:',e)}}
function setMessage(el,text,type=''){if(!el)return;el.textContent=text||'';el.className=type}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function formatDate(v){try{return new Date(v).toLocaleString('ar-DZ')}catch{return '—'}}
function formatMoney(v,c='DZD'){const n=Number(v);return Number.isFinite(n)?`${n.toLocaleString('ar-DZ')} ${c==='DZD'?'دج':c}`:'بانتظار التسعير'}
function openAuth(message=''){ $('authModal')?.classList.add('show'); if(message)setMessage($('authMsg'),message,'error') }
function closeAuth(){ $('authModal')?.classList.remove('show') }

let qty=1, selectedSite='AliExpress', cachedOrders=[], selectedOrderId=null;
const statusNames={received:'قيد المعالجة',price_confirmation:'تم تحديد السعر',awaiting_payment:'بانتظار الدفع',payment_proof_received:'تم استلام وصل الدفع',paid:'تم تأكيد الدفع',shipping:'قيد التوصيل',delivered:'تم التسليم',cancelled:'ملغى'};

async function getProfile(user){
  if(!user)return null;
  const {data,error}=await db.from('profiles').select('id,first_name,last_name,full_name,phone,avatar_url').eq('id',user.id).maybeSingle();
  if(error){console.warn('Profile:',error.message);return null} return data||null;
}
function profileValues(user,profile=null){
  const m=user?.user_metadata||{}, full=profile?.full_name||m.full_name||'';
  const p=String(full).trim().split(/\s+/).filter(Boolean);
  return {first_name:profile?.first_name||m.first_name||p.shift()||'',last_name:profile?.last_name||m.last_name||p.join(' ')||'',phone:profile?.phone||m.phone||''};
}
async function fillOrderContact(user){
  const p=await getProfile(user),v=profileValues(user,p);
  ['orderFirstName','orderLastName','orderPhone'].forEach((id,i)=>{if($(id)&&!$(id).value)$(id).value=[v.first_name,v.last_name,v.phone][i]||''});
}
async function ensureProfileComplete(user,show=true){
  const p=await getProfile(user),v=profileValues(user,p),ok=!!(v.first_name.trim()&&v.last_name.trim()&&v.phone.trim());
  if(!ok&&show)await openProfileModal(user); return ok;
}
async function openProfileModal(user=null,message=''){
  const current=user||(await db.auth.getUser()).data.user;if(!current)return openAuth('سجّل الدخول أولًا باستخدام Google.');
  const p=await getProfile(current),v=profileValues(current,p);
  $('firstName').value=v.first_name;$('lastName').value=v.last_name;$('phone').value=v.phone;$('profileModal')?.classList.add('show');
  if(message)setMessage($('profileMsg'),message,'error');
}

$('googleLogin')?.addEventListener('click',async()=>{
  const b=$('googleLogin');if(b)b.disabled=true;setMessage($('authMsg'),'جارٍ فتح تسجيل الدخول بحساب Google…','success');
  try{
    // Preserve the GitHub Pages sub-path; using origin alone would return to the wrong page.
    const redirectTo=`${location.origin}${location.pathname}`;
    const {error}=await db.auth.signInWithOAuth({provider:'google',options:{redirectTo,queryParams:{prompt:'select_account'}}});
    if(error)setMessage($('authMsg'),error.message,'error');
  }catch(e){setMessage($('authMsg'),e?.message||'تعذر بدء تسجيل الدخول عبر Google.','error')}finally{if(b)b.disabled=false}
});

$('profileForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('انتهت الجلسة. سجّل الدخول باستخدام Google.');
  const firstName=$('firstName').value.trim(),lastName=$('lastName').value.trim(),phone=$('phone').value.trim();
  if(!firstName||!lastName||!phone)return setMessage($('profileMsg'),'أكمل الاسم واللقب ورقم الهاتف.','error');
  if(!/^[0-9+()\s-]{8,20}$/.test(phone))return setMessage($('profileMsg'),'أدخل رقم هاتف صحيح.','error');
  const b=$('saveProfile');b.disabled=true;b.textContent='جارٍ الحفظ…';
  try{
    const fullName=`${firstName} ${lastName}`.trim();
    const {error}=await db.from('profiles').upsert({id:user.id,first_name:firstName,last_name:lastName,full_name:fullName,phone,avatar_url:user.user_metadata?.avatar_url||null,updated_at:new Date().toISOString()},{onConflict:'id'});if(error)throw error;
    await db.auth.updateUser({data:{first_name:firstName,last_name:lastName,full_name:fullName,phone}});
    setMessage($('profileMsg'),'تم حفظ بياناتك بنجاح ✓','success');
    $('orderFirstName').value=firstName;$('orderLastName').value=lastName;$('orderPhone').value=phone;
    setTimeout(()=>$('profileModal')?.classList.remove('show'),450);
  }catch(e){console.error(e);setMessage($('profileMsg'),e?.message||'تعذر حفظ البيانات. حاول مرة أخرى.','error')}finally{b.disabled=false;b.textContent='حفظ البيانات'}
});

// Product image
const imageInput=$('productImage');
imageInput?.addEventListener('change',()=>{
  const file=imageInput.files?.[0];if(!file){$('imagePreview')?.classList.remove('show');if($('imageName'))$('imageName').textContent='';return}
  if(!['image/jpeg','image/png','image/webp'].includes(file.type)){imageInput.value='';return setMessage($('orderMsg'),'اختر صورة JPG أو PNG أو WEBP فقط.','error')}
  if(file.size>5*1024*1024){imageInput.value='';return setMessage($('orderMsg'),'حجم الصورة يجب ألا يتجاوز 5MB.','error')}
  $('imageName').textContent=file.name;$('imagePreview').src=URL.createObjectURL(file);$('imagePreview').classList.add('show');setMessage($('orderMsg'),'تم اختيار الصورة بنجاح ✓','success');
});

document.querySelectorAll('[data-scroll]').forEach(el=>el.addEventListener('click',()=>document.querySelector(el.dataset.scroll)?.scrollIntoView({behavior:'smooth'})));
$('searchBtn')?.addEventListener('click',()=>{const q=$('siteSearch')?.value.trim()||'';if(/^https?:\/\//i.test(q)){$('productUrl').value=q;document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}else if(q){setMessage($('orderMsg'),'ألصق رابط المنتج أو اكتب رابطًا يبدأ بـ https://.','error');document.querySelector('#order')?.scrollIntoView({behavior:'smooth'})}});
$('siteSearch')?.addEventListener('keydown',e=>{if(e.key==='Enter')$('searchBtn')?.click()});
$('countryBtn')?.addEventListener('click',()=>document.querySelector('#order')?.scrollIntoView({behavior:'smooth'}));
$('closeMarket')?.addEventListener('click',()=>$('marketModal')?.classList.remove('show'));
$('marketModal')?.addEventListener('click',e=>{if(e.target===$('marketModal'))$('marketModal').classList.remove('show')});

for(const b of document.querySelectorAll('#sites button'))b.addEventListener('click',()=>{document.querySelectorAll('#sites button').forEach(x=>x.classList.remove('active'));b.classList.add('active');selectedSite=b.dataset.site||'موقع آخر'});
$('plus')?.addEventListener('click',()=>{$('qty').textContent=String(++qty)});
$('minus')?.addEventListener('click',()=>{$('qty').textContent=String(qty=Math.max(1,qty-1))});

async function handleAccountClick(){const {data:{user}}=await db.auth.getUser();if(user)return openProfileModal(user);openAuth()}
$('accountBtn')?.addEventListener('click',handleAccountClick);$('mobileAccount')?.addEventListener('click',handleAccountClick);

async function openCustomerOrders(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض طلباتك.');
  $('customerOrdersList').innerHTML='<div class="empty">جارٍ تحميل الطلبات…</div>';$('customerOrdersModal')?.classList.add('show');
  const {data,error}=await db.from('orders').select('id,order_number,status,source_site,product_name,product_info,quantity,total_price,currency,created_at').eq('user_id',user.id).order('created_at',{ascending:false});
  if(error)return $('customerOrdersList').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';
  $('customerOrdersList').innerHTML=data?.length?data.map(o=>`<article class="notification-item"><b>#${esc(o.order_number)}</b><p>${esc(o.product_name||o.product_info||o.source_site||'طلب منتج')} • الكمية: ${Number(o.quantity)||1}</p><strong>${esc(statusNames[o.status]||'قيد المعالجة')}</strong><small>${formatMoney(o.total_price,o.currency)} • ${formatDate(o.created_at)}</small></article>`).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';
}
$('ordersBtn')?.addEventListener('click',openCustomerOrders);$('mobileOrders')?.addEventListener('click',openCustomerOrders);
$('closeCustomerOrders')?.addEventListener('click',()=>$('customerOrdersModal')?.classList.remove('show'));
$('customerOrdersModal')?.addEventListener('click',e=>{if(e.target===$('customerOrdersModal'))$('customerOrdersModal').classList.remove('show')});

async function openMessages(){
  const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول أولًا لعرض رسائلك.');
  $('notificationsList').innerHTML='<div class="empty">جارٍ تحميل الرسائل…</div>';$('notificationsModal')?.classList.add('show');
  const {data,error}=await db.from('notifications').select('id,title,message,is_read,order_id,created_at').eq('user_id',user.id).order('created_at',{ascending:false}).limit(50);
  if(error)return $('notificationsList').innerHTML='<div class="empty">تعذر تحميل الرسائل.</div>';
  $('notificationsList').innerHTML=data?.length?data.map(n=>`<article class="notification-item ${n.is_read?'':'unread'}"><b>${esc(n.title)}</b><p>${esc(n.message)}</p><small>${formatDate(n.created_at)}</small></article>`).join(''):'<div class="empty">لا توجد رسائل بعد.</div>';
  const ids=(data||[]).filter(n=>!n.is_read).map(n=>n.id);if(ids.length)await db.from('notifications').update({is_read:true}).in('id',ids);
}
$('messagesBtn')?.addEventListener('click',openMessages);$('mobileMessages')?.addEventListener('click',openMessages);
$('closeNotifications')?.addEventListener('click',()=>$('notificationsModal')?.classList.remove('show'));
$('notificationsModal')?.addEventListener('click',e=>{if(e.target===$('notificationsModal'))$('notificationsModal').classList.remove('show')});
$('closeProfile')?.addEventListener('click',()=>$('profileModal')?.classList.remove('show'));
$('profileModal')?.addEventListener('click',e=>{if(e.target===$('profileModal'))$('profileModal').classList.remove('show')});
$('closeAuth')?.addEventListener('click',closeAuth);$('authModal')?.addEventListener('click',e=>{if(e.target===$('authModal'))closeAuth()});

async function uploadProductImage(userId){
  const file=imageInput?.files?.[0];if(!file)return null;
  const ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[file.type];
  if(!ext)throw new Error('الصورة يجب أن تكون JPG أو PNG أو WEBP.');if(file.size>5*1024*1024)throw new Error('حجم الصورة يجب ألا يتجاوز 5MB.');
  const path=`${userId}/${crypto.randomUUID()}.${ext}`;const {error}=await db.storage.from('product-images').upload(path,file,{contentType:file.type,upsert:false});if(error)throw error;return path;
}

async function sendTelegramOrder(orderId){
  try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:orderId,event:'created'}});if(error)console.warn('Telegram:',error.message)}catch(e){console.warn('Telegram:',e)}
}

$('sendOrder')?.addEventListener('click',async()=>{
  setMessage($('orderMsg'),'');const {data:{user}}=await db.auth.getUser();if(!user)return openAuth('سجّل الدخول باستخدام Google أولًا لإرسال الطلب.');
  const first=$('orderFirstName').value.trim(),last=$('orderLastName').value.trim(),phone=$('orderPhone').value.trim(),wilaya=$('orderWilaya').value.trim(),commune=$('orderCommune').value.trim(),postal=$('orderPostalCode').value.trim(),address=$('orderAddress').value.trim(),url=$('productUrl').value.trim(),productName=$('productName').value.trim(),info=$('productInfo').value.trim();
  if(!first||!last||!phone||!wilaya||!commune||!address)return setMessage($('orderMsg'),'أكمل الاسم واللقب والهاتف والولاية والبلدية والعنوان.','error');
  if(!/^[0-9+()\s-]{8,20}$/.test(phone))return setMessage($('orderMsg'),'أدخل رقم هاتف صحيح.','error');
  if(!url&&!imageInput?.files?.length)return setMessage($('orderMsg'),'أدخل رابط المنتج أو أرسل صورة المنتج.','error');
  if(url&&!/^https?:\/\//i.test(url))return setMessage($('orderMsg'),'رابط المنتج يجب أن يبدأ بـ https:// أو http://','error');
  const b=$('sendOrder');b.disabled=true;b.textContent='جارٍ إرسال الطلب…';
  try{
    const fullName=`${first} ${last}`.trim();
    const profileError=(await db.from('profiles').upsert({id:user.id,first_name:first,last_name:last,full_name:fullName,phone,avatar_url:user.user_metadata?.avatar_url||null,updated_at:new Date().toISOString()},{onConflict:'id'})).error;if(profileError)throw profileError;
    const imagePath=await uploadProductImage(user.id);
    const payload={user_id:user.id,product_url:url||null,product_name:productName||null,product_info:info||null,product_image_url:imagePath,source_site:selectedSite,quantity:qty,customer_first_name:first,customer_last_name:last,customer_phone:phone,wilaya,commune,address,postal_code:postal||null,status:'received'};
    const {data,error}=await db.from('orders').insert(payload).select('id,order_number').single();if(error)throw error;
    await sendTelegramOrder(data.id);
    setMessage($('orderMsg'),`✅ تم إرسال طلبك بنجاح\n📦 طلبك قيد المعالجة\n💬 سنتواصل معك عبر WhatsApp لتأكيد السعر والدفع.\nرقم الطلب: #${data.order_number}`,'success');
    $('productUrl').value='';$('productName').value='';$('productInfo').value='';imageInput.value='';$('imagePreview')?.classList.remove('show');$('imageName').textContent='';qty=1;$('qty').textContent='1';
  }catch(e){console.error('Order:',e);setMessage($('orderMsg'),e?.message||'تعذر إرسال الطلب. حاول مرة أخرى.','error')}finally{b.disabled=false;b.textContent='إرسال الطلب ➤'}
});

async function isAdmin(){const {data:{user}}=await db.auth.getUser();if(!user)return false;const {data,error}=await db.from('admins').select('user_id').eq('user_id',user.id).maybeSingle();if(error){console.warn('Admin:',error.message);return false}return !!data}
async function openAdmin(){if(!(await isAdmin()))return openAuth('هذا الحساب ليس Admin.');closeAuth();$('adminPanel').classList.add('show');const {data:{user}}=await db.auth.getUser();$('adminEmail').textContent=user?.email||'';await refreshAdmin()}
$('adminBtn')?.addEventListener('click',openAdmin);$('closeAdmin')?.addEventListener('click',()=>$('adminPanel').classList.remove('show'));
document.querySelectorAll('.admin-tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.admin-tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.admin-view').forEach(x=>x.classList.add('hidden'));b.classList.add('active');$('tab-'+b.dataset.tab)?.classList.remove('hidden')}));

function orderRow(o){return `<div class="mini-order"><b>#${esc(o.order_number)}</b><span>${esc(o.customer_first_name||'')} ${esc(o.customer_last_name||'')}</span><span>${esc(o.customer_phone||'—')}</span><strong>${esc(statusNames[o.status]||o.status||'—')}</strong><button type="button" class="detail-btn" data-order-id="${esc(o.id)}">فتح الطلب</button></div>`}
function renderOrders(orders){
  const q=($('orderSearch')?.value||'').trim().toLowerCase(),f=$('statusFilter')?.value||'';
  const rows=orders.filter(o=>(!q||String(o.order_number||'').toLowerCase().includes(q)||String(o.customer_phone||'').toLowerCase().includes(q))&&(!f||o.status===f));
  if(!rows.length){$('ordersTable').innerHTML='<div class="empty">لا توجد طلبات مطابقة.</div>';return}
  $('ordersTable').innerHTML=`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الطلب</th><th>العميل</th><th>الهاتف</th><th>الموقع</th><th>الكمية</th><th>السعر</th><th>الحالة</th><th>التاريخ</th><th></th></tr></thead><tbody>${rows.map(o=>`<tr><td>#${esc(o.order_number)}</td><td>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim()||'—')}</td><td>${esc(o.customer_phone||'—')}</td><td>${esc(o.source_site||'—')}</td><td>${Number(o.quantity)||1}</td><td>${formatMoney(o.total_price,o.currency)}</td><td>${esc(statusNames[o.status]||o.status||'—')}</td><td>${formatDate(o.created_at)}</td><td><button class="detail-btn" data-order-id="${esc(o.id)}">فتح</button></td></tr>`).join('')}</tbody></table></div>`;
  document.querySelectorAll('.detail-btn').forEach(b=>b.addEventListener('click',()=>openOrderDetail(b.dataset.orderId)));
}

async function refreshAdmin(){
  const [or,ur,br]=await Promise.all([db.from('orders').select('*').order('created_at',{ascending:false}),db.from('profiles').select('*').order('created_at',{ascending:false}),db.from('banners').select('*').order('sort_order',{ascending:true})]);
  if(or.error){$('recentOrders').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';return}
  cachedOrders=or.data||[];$('sTotal').textContent=cachedOrders.length;$('sNew').textContent=cachedOrders.filter(o=>['received','checking'].includes(o.status)).length;$('sPaid').textContent=cachedOrders.filter(o=>o.status==='paid').length;$('sDone').textContent=cachedOrders.filter(o=>o.status==='delivered').length;$('recentOrders').innerHTML=cachedOrders.length?cachedOrders.slice(0,8).map(orderRow).join(''):'<div class="empty">لا توجد طلبات بعد.</div>';renderOrders(cachedOrders);initIcons();
  const users=ur.data||[];$('usersTable').innerHTML=users.length?`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الاسم</th><th>اللقب</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>${users.map(u=>`<tr><td>${esc(u.first_name||'—')}</td><td>${esc(u.last_name||'—')}</td><td>${esc(u.phone||'—')}</td><td>${formatDate(u.created_at)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا يوجد مستخدمون بعد.</div>';
  const banners=br.data||[];$('bannersList').innerHTML=banners.length?banners.map(b=>`<div class="banner-row"><b>${esc(b.title||'بنر')}</b><span>${b.active?'فعال':'متوقف'}</span></div>`).join(''):'<div class="empty">لا توجد بنرات بعد.</div>';
}

async function openOrderDetail(id){
  const order=cachedOrders.find(o=>o.id===id);if(!order)return;selectedOrderId=id;
  $('detailOrderNumber').textContent=`#${order.order_number}`;$('detailTotalPrice').value=order.total_price??'';$('detailShipping').value=order.shipping_fee??0;$('detailService').value=order.service_fee??0;$('detailStatus').value=statusNames[order.status]?order.status:'received';$('detailPaymentInfo').value=order.payment_info||'';$('detailAdminNote').value=order.admin_note||'';
  const wa=normalizeWhatsApp(order.customer_phone||'');$('whatsappOrder').href=wa?`https://wa.me/${wa}?text=${encodeURIComponent(`مرحبًا ${order.customer_first_name||''}، معك FENK DZ بخصوص طلبك #${order.order_number}.`)}`:'#';
  $('orderDetailContent').innerHTML=`<div class="detail-grid"><div><b>الاسم واللقب</b><span>${esc(`${order.customer_first_name||''} ${order.customer_last_name||''}`.trim()||'—')}</span></div><div><b>الهاتف</b><span>${esc(order.customer_phone||'—')}</span></div><div><b>الولاية</b><span>${esc(order.wilaya||'—')}</span></div><div><b>البلدية</b><span>${esc(order.commune||'—')}</span></div><div><b>الرمز البريدي</b><span>${esc(order.postal_code||'—')}</span></div><div class="full-field"><b>العنوان</b><span>${esc(order.address||'—')}</span></div><div><b>السلعة</b><span>${esc(order.product_name||'—')}</span></div><div><b>معلومات السلعة</b><span>${esc(order.product_info||'—')}</span></div><div><b>رابط السلعة</b><span>${order.product_url?`<a href="${esc(order.product_url)}" target="_blank" rel="noopener">فتح الرابط</a>`:'—'}</span></div><div><b>الكمية</b><span>${Number(order.quantity)||1}</span></div><div><b>تاريخ الطلب</b><span>${formatDate(order.created_at)}</span></div></div>`;
  $('orderDetailModal')?.classList.add('show');initIcons();
}
function normalizeWhatsApp(phone){let p=String(phone||'').replace(/\D/g,'');if(p.startsWith('00'))p=p.slice(2);if(p.startsWith('0'))p='213'+p.slice(1);return p}
$('closeOrderDetail')?.addEventListener('click',()=>$('orderDetailModal')?.classList.remove('show'));
$('orderDetailModal')?.addEventListener('click',e=>{if(e.target===$('orderDetailModal'))$('orderDetailModal').classList.remove('show')});
$('saveOrderDetail')?.addEventListener('click',async()=>{
  if(!selectedOrderId)return;const b=$('saveOrderDetail');b.disabled=true;b.textContent='جارٍ الحفظ…';
  try{
    const total=$('detailTotalPrice').value===''?null:Number($('detailTotalPrice').value),shipping=Number($('detailShipping').value||0),service=Number($('detailService').value||0),status=$('detailStatus').value;
    const {data,error}=await db.from('orders').update({total_price:total,shipping_fee:shipping,service_fee:service,status,payment_info:$('detailPaymentInfo').value.trim()||null,admin_note:$('detailAdminNote').value.trim()||null,updated_at:new Date().toISOString()}).eq('id',selectedOrderId).select().single();if(error)throw error;
    await db.from('order_status_history').insert({order_id:selectedOrderId,status,note:'تم التحديث من لوحة الإدارة'});await notifyTelegram(data);setMessage($('orderDetailMsg'),'تم حفظ التعديلات وإرسال التحديث ✓','success');await refreshAdmin();
  }catch(e){setMessage($('orderDetailMsg'),e?.message||'تعذر حفظ التعديلات.','error')}finally{b.disabled=false;b.textContent='حفظ التعديلات'}
});
async function notifyTelegram(order){try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:order.id,event:'updated'}});if(error)console.warn('Telegram:',error.message)}catch(e){console.warn('Telegram:',e)}}
$('orderSearch')?.addEventListener('input',()=>renderOrders(cachedOrders));$('statusFilter')?.addEventListener('change',()=>renderOrders(cachedOrders));
$('telegramTest')?.addEventListener('click',async()=>{const m=$('telegramMsg');setMessage(m,'جارٍ اختبار Telegram…','success');if(!(await isAdmin()))return setMessage(m,'يجب تسجيل الدخول بحساب Admin.','error');const sample=cachedOrders[0];if(!sample)return setMessage(m,'أنشئ طلبًا أولًا لاختبار Telegram.','error');try{const {error}=await db.functions.invoke('telegram-order-notify',{body:{order_id:sample.id,event:'test'}});if(error)throw error;setMessage(m,'تم إرسال اختبار Telegram بنجاح ✓','success')}catch(e){setMessage(m,e?.message||'تعذر إرسال اختبار Telegram.','error')}});
$('newsletterSubscribe')?.addEventListener('click',()=>{const i=$('newsletterEmail'),v=i?.value.trim()||'';if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))return alert('أدخل بريدًا إلكترونيًا صحيحًا.');alert('تم تسجيل بريدك بنجاح. شكرًا لثقتك في FENK DZ.');i.value=''})

function updateAuthUI(user){const label=user?`مسجل: ${user.user_metadata?.full_name||user.email||'Google'}`:'تسجيل الدخول';if($('accountBtn'))$('accountBtn').title=label;if($('mobileAccount'))$('mobileAccount').title=label}

db.auth.onAuthStateChange((_event,session)=>{
  updateAuthUI(session?.user||null);
  if(session){setTimeout(async()=>{await fillOrderContact(session.user);const admin=await isAdmin();if($('adminBtn'))$('adminBtn').style.display=admin?'block':'none'},0)}else{if($('adminBtn'))$('adminBtn').style.display='none'}
});
(async()=>{const {data:{session}}=await db.auth.getSession();updateAuthUI(session?.user||null);if(session){await fillOrderContact(session.user);if(await isAdmin())$('adminBtn').style.display='block'}})();

document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;['authModal','profileModal','notificationsModal','customerOrdersModal','orderDetailModal','marketModal','adminPanel'].forEach(id=>$(id)?.classList.remove('show'))});
document.querySelectorAll('video').forEach(v=>v.addEventListener('error',()=>v.closest('.video-card')?.classList.add('video-fallback')));
initIcons();window.FENK={version:'V13-GOOGLE-WHATSAPP-ORDERS',supabaseUrl:SUPABASE_URL};
