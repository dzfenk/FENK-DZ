# V59 games reference note

The old DzairPay-inspired visual direction is obsolete. The current FENK games page uses its own FENK layout and does not copy the reference screenshots.
