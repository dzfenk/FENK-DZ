# V58 reference notes

Music was intentionally removed from the current FENK games build. The current games page is visual-only and does not load audio files.
