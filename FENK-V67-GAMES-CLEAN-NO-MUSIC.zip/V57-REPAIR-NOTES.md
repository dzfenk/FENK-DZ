# FENK V57 — Gaming UI + Admin package repair

## Implemented
- Reworked `game-topup.html` into a mobile-first game detail page inspired by the supplied reference layout, while keeping FENK branding.
- Dynamic game tabs and game hero artwork.
- Dynamic package cards loaded from Supabase `game_packages` instead of a fixed dropdown.
- The active package price is displayed in DZD and comes from the Admin-managed package record.
- Selected package is visually highlighted and its total is shown before submitting.
- Checkout keeps Player ID, region, phone and customer name fields.
- The page explicitly avoids asking customers for game account passwords.
- Barid Mob is shown as the payment method.
- Existing Supabase order flow remains in use.

## Database
- Migration `20260919001130_admin_game_packages_barid_policies_v57` is applied to project `fenk-dz`.
- Admin-only policies were added for game/package/payment-setting management.
- `prepare_order()` now uses the selected game's active package and Admin-defined Barid Mob price.
- Barid Mob payment destination and payment information are populated from `payment_settings`.
- Verified with a transaction test and rollback: package price, total, payment destination, RIP and confirmation message were generated correctly.

## Current database check
- There is currently 1 active game package in the database: PUBG Mobile / 660 UC / 3000 DZD.
- Barid Mob account number is configured as: 00799999002385072872.

## Important
This update does not rebuild FENK from scratch and does not remove existing project data.
