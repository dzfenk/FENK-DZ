# FENK V67 — Games Clean UI

- Removed all game/background music files and all audio controls from the games page.
- Reworked `game-topup.html` into a distinct FENK UI; it does not copy the supplied DzairPay reference layout.
- Kept Supabase games/packages/orders and BaridiMob checkout flow.
- Catalog is compact and responsive, with search and price/name sorting.
- Game details, packages, phone validation, order submission, and direct `?game=` links remain functional.
- Fixed the category control so it no longer presents unused DzairPay-style filters.
