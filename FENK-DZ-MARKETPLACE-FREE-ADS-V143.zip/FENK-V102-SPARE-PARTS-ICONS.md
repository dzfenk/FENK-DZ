# FENK V102 — Spare Parts Icons
- Added a dedicated "قطع غيار السيارات" icon strip to Marketplace.
- Six automotive subcategories: brakes, oils/filters, batteries, suspension/control arms, engines, tires.
- Uses inline SVG icons with dark automotive cards, silver/white icon discs, and restrained FENK green accents to match the supplied automotive banners without turning the page red/green.
- Responsive: 6 columns desktop, 3 columns mobile.
- Each icon opens the Marketplace products category.
- Existing four main Marketplace categories and other functionality preserved.
