# FENK V87 — Marketplace Page Fix

- Compact Marketplace strip under the games/top-up section.
- Real `marketplace.html` page (the previous V86 archive contained an empty placeholder file).
- Marketplace categories: products, stores, cars for sale, real estate, land.
- Published ads load from Supabase.
- `#publish` opens the paid-ad submission flow.
- Paid ads remain pending until Admin approves payment and publication.
- Existing V86 Supabase migration and Admin files are preserved.
