# FENK V98 — Marketplace category images

تم استبدال صور Marketplace الافتراضية بصور المستخدم:
- سيارات للبيع → assets/marketplace/cars.jpg
- الإعلانات → assets/marketplace/ads.gif
- عقارات / أراضي → assets/marketplace/realestate.jpg
- منتجات → assets/marketplace/marketplace-products.png (كما هي)

تم تطبيق التعديل في:
- marketplace.html
- marketplace-category.html

لم يتم حذف وظائف Marketplace أو تغيير قاعدة البيانات.
