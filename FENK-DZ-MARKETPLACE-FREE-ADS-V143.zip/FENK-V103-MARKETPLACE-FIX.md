# FENK V103 — Marketplace repair

- Restored Supabase RLS policies for marketplace ads/packages/categories.
- Admins can create/update/delete Marketplace ads; owners can manage their own ads.
- Public visitors can read published, non-expired ads.
- Marketplace promotional banner is now the first content after the header.
- Removed the old green Marketplace hero and price panel from above the promotional banner.
- Kept a compact “انشر إعلانك” CTA immediately below the promotional hero.
- Preserved Marketplace categories, spare-parts icons, promotional images, forms and existing project files.
