# V90 Marketplace
- Replaced emoji-only category cards with custom visual artwork embedded directly in the page.
- No external image host is required for category artwork.
- Category cards remain real links and open their filtered Marketplace page.
- Improved mobile layout, hero, cards and publishing area.
