FENK V86 Marketplace Fix
- Compact Marketplace strip placed directly under game top-up.
- Marketplace page cleaned and category quick bar added.
- Publish buttons now open marketplace.html#publish.
- Marketplace admin tab added for payment/content approval and revenue tracking.
- Supabase migration adds/ensures categories, packages, ads, storage, and RLS.
- No existing core FENK tables are deleted.
