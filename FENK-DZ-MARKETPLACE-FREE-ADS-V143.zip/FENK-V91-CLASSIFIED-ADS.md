# FENK V91 — Classified Marketplace Ads

Added structured publishing for:
- Cars for sale: model/year/engine/gearbox/mileage/condition/location + optional notes and phone.
- Homes/real estate: property type/area/rooms/floor/location + optional notes and phone.
- Land: area/type/documents/road/location + optional notes and phone.
- Image upload is optional at the category-detail level; main ad image and payment proof remain required for publication.
- Admin configures the Baridimob account and instructions.
- User pays outside the site, uploads the receipt, and remains pending.
- Admin confirms payment and publishes; otherwise rejects.
