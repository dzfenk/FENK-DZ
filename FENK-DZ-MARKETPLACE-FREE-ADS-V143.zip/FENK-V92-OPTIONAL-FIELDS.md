# FENK V92 — Optional classified ad fields

The advertiser is NOT forced to fill every field.

Optional:
- Car/real-estate/land details
- Phone number
- Contact link
- Description
- Main advertisement photo

Required only to submit a paid ad for review:
- Advertisement title
- Duration
- Payment receipt/proof

Admin approval remains required before publication.
