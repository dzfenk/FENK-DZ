# FENK V88
Marketplace strip moved away from the games/top-up area and placed after supported global shopping sites.
The strip is intentionally compact and opens the dedicated marketplace.html page.
