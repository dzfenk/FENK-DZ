# FENK V134 — Messaging + Notifications

- Fixed notification modal close/touch handling.
- Added message reactions with per-user uniqueness.
- Added long-press bottom sheet on mobile.
- Added reply and forward references.
- Added delete-for-me and delete-for-everyone with RLS/RPC enforcement.
- Added realtime support for messages and reactions.
- Preserved existing FENK design, Supabase auth/RLS, orders, ads and Telegram.
