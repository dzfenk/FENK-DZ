alter publication supabase_realtime add table public.support_messages;
