const token=Deno.env.get("TELEGRAM_BOT_TOKEN")||"";
const API="https://api.telegram.org/bot"+token;
const raw=Deno.env.get("SUPABASE_SECRET_KEYS");
const serviceKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")||(raw?JSON.parse(raw).default:"");
const base=Deno.env.get("SUPABASE_URL")||"";
const admin=String(Deno.env.get("TELEGRAM_ADMIN_CHAT_ID")||"8617207330");

function authorized(req:Request){
  const a=req.headers.get("authorization")||"";
  const key=req.headers.get("apikey")||"";
  return (!!serviceKey && (a==="Bearer "+serviceKey || key===serviceKey));
}
async function tg(method:string, body:Record<string,unknown>){
  const r=await fetch(API+"/"+method,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)});
  return await r.json().catch(()=>({ok:false}));
}
async function rest(path:string, init:RequestInit={}){
  const r=await fetch(base+"/rest/v1/"+path,{...init,headers:{apikey:serviceKey,Authorization:"Bearer "+serviceKey,"Content-Type":"application/json",...(init.headers||{})}});
  const j=await r.json().catch(()=>null);
  if(!r.ok) throw new Error(JSON.stringify(j));
  return j;
}
Deno.serve(async req=>{
  if(req.method!=="POST") return Response.json({ok:false,error:"METHOD_NOT_ALLOWED"},{status:405});
  if(!authorized(req)) return Response.json({ok:false,error:"UNAUTHORIZED"},{status:401});
  try{
    const p=await req.json();
    const r=p?.record;
    if(!r || r.sender_role!=="customer" || !r.user_id || !r.message) return Response.json({ok:true,skipped:true});
    const profiles=await rest("profiles?select=first_name,last_name,phone&id=eq."+encodeURIComponent(r.user_id)+"&limit=1");
    const profile=Array.isArray(profiles)&&profiles[0]?profiles[0]:{};
    const name=String([profile.first_name,profile.last_name].filter(Boolean).join(" ")||"عميل");
    const phone=String(profile.phone||"غير متوفر");
    const text=[
      "💬 رسالة جديدة من عميل FENK",
      "",
      "👤 العميل: "+name,
      "📱 الهاتف: "+phone,
      "🆔 CUSTOMER_ID: "+r.user_id,
      "",
      "💬 "+String(r.message)
    ].join("\n");
    await tg("sendMessage",{chat_id:admin,text,reply_markup:{inline_keyboard:[[{text:"✍️ رد على العميل",callback_data:"reply:"+r.user_id}]]}});
    return Response.json({ok:true});
  }catch(e){
    console.error(e);
    return Response.json({ok:false,error:e instanceof Error?e.message:"SERVER_ERROR"},{status:500});
  }
});
