const token=Deno.env.get("TELEGRAM_BOT_TOKEN")||"";
const adminChat=String(Deno.env.get("TELEGRAM_ADMIN_CHAT_ID")||"");
const supabaseUrl=Deno.env.get("SUPABASE_URL")||"";
const serviceKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")||"";
const anonKey=Deno.env.get("SUPABASE_ANON_KEY")||"";

async function telegram(method:string, body:Record<string,unknown>){
  if(!token||!adminChat) throw new Error("Telegram secrets are not configured.");
  const r=await fetch(`https://api.telegram.org/bot${token}/${method}`,{
    method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)
  });
  const j=await r.json().catch(()=>({}));
  if(!r.ok||j?.ok===false) throw new Error(String(j?.description||"Telegram request failed"));
  return j;
}

async function getUser(accessToken:string){
  const r=await fetch(`${supabaseUrl}/auth/v1/user`,{
    headers:{apikey:anonKey||serviceKey,Authorization:`Bearer ${accessToken}`}
  });
  if(!r.ok) return null;
  return await r.json().catch(()=>null);
}

function safe(v:unknown,max=500){return String(v??"").replace(/[\u0000-\u001f]/g," ").slice(0,max)}
function label(event:string){
  return ({proof_uploaded:"📸 إثبات دفع جديد",deleted:"🗑️ إعلان محذوف",updated:"✏️ إعلان محدث"} as Record<string,string>)[event]||"📢 تحديث إعلان";
}

Deno.serve(async req=>{
  if(req.method!=="POST") return Response.json({ok:false,error:"METHOD_NOT_ALLOWED"},{status:405});
  try{
    const auth=req.headers.get("authorization")||"";
    const tokenMatch=auth.match(/^Bearer\s+(.+)$/i);
    const accessToken=tokenMatch?.[1]||"";
    const user=accessToken?await getUser(accessToken):null;
    if(!user?.id) return Response.json({ok:false,error:"UNAUTHORIZED"},{status:401});

    const p=await req.json().catch(()=>({}));
    const event=safe(p?.event,50);
    const adId=safe(p?.ad_id,100);
    const s=p?.snapshot||{};
    const ar=await fetch(`${supabaseUrl}/rest/v1/rpc/is_admin`,{method:"POST",headers:{apikey:anonKey||serviceKey,Authorization:`Bearer ${accessToken}`,"content-type":"application/json"},body:"{}"});
    const isAdmin=ar.ok && (await ar.json().catch(()=>false))===true;

    // Owners may report their own event; admin may report any event.
    if(!isAdmin && s?.user_id && String(s.user_id)!==String(user.id))
      return Response.json({ok:false,error:"FORBIDDEN"},{status:403});

    const text=[
      label(event),
      "",
      `🆔 الإعلان: ${adId||"غير معروف"}`,
      `📌 العنوان: ${safe(s?.title||"إعلان FENK",180)}`,
      s?.ad_code?`🔖 الكود: ${safe(s.ad_code,80)}`:"",
      s?.user_id?`👤 USER_ID: ${safe(s.user_id,100)}`:"",
      s?.wilaya?`📍 الولاية: ${safe(s.wilaya,100)}`:"",
      s?.municipality?`🏘️ البلدية: ${safe(s.municipality,100)}`:"",
      s?.price_dzd!=null?`💰 السعر: ${safe(s.price_dzd,50)} دج`:"",
    ].filter(Boolean).join("\n");

    await telegram("sendMessage",{chat_id:adminChat,text});
    return Response.json({ok:true});
  }catch(e){
    console.error(e);
    return Response.json({ok:false,error:e instanceof Error?e.message:"SERVER_ERROR"},{status:500});
  }
});
