FENK V96 — Marketplace category layout
Exactly four cards:
1. منتجات
2. سيارات للبيع
3. الإعلانات
4. عقارات / أراضي

Removed the separate «الكل» and «متاجر» cards from the Marketplace category grid.
Each card remains a real link to the appropriate category.
