# FENK V109 — Marketplace Publish Button Fix
- Fixed the main "انشر إعلانك" CTA to navigate directly to marketplace-publish.html.
- Fixed empty-state publish CTA to use the same direct page.
- Fixed homepage Marketplace navigation links to dedicated category pages.
- Fixed the FENK AI floating-menu "نشر إعلان" link to open the dedicated publish page.
- Kept Marketplace public ads only on the Marketplace page and category filtering unchanged.
