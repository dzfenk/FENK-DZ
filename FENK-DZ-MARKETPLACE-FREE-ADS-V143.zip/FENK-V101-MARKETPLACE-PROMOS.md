# FENK V101 — Marketplace promotional banners
- Added the 5 user-provided FENK promotional images to Marketplace.
- Added a responsive neutral/white promotional carousel under the Marketplace hero.
- Images are presented without changing the Marketplace into a red or green themed page; the existing FENK green identity remains the UI accent.
- Each banner links to its relevant Marketplace category.
- Added autoplay, arrows, dots, and mobile touch-friendly behavior.
- No database schema or existing Marketplace functionality was removed.
