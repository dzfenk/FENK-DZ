# FENK V94 — Marketplace UI/function fixes

- Fixed invisible publication-price text inside the green hero.
- Made publication price chips high-contrast and readable on mobile.
- Category cards keep real links: products, stores, cars, realestate, land.
- Category images are responsive and no longer distort on mobile.
- Empty category states remain usable and provide a publish action.
- Fixed the land category label to “أراضي للبيع”.
