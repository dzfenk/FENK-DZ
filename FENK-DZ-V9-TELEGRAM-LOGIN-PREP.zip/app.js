const SUPABASE_URL = 'https://zfnlgzwvvytophdxtoks.supabase.co';
const SUPABASE_KEY = 'sb_publishable_d8kkB1Nyfjlx8LD9LQ5Ogw_WZPbxL5k';
const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const $ = (id) => document.getElementById(id);

function initIcons() {
  try { if (window.lucide) window.lucide.createIcons({ attrs: { 'stroke-width': 2.1 } }); } catch (e) { console.warn('Icons:', e); }
}
initIcons();

const imageInput = $('productImage');
const imagePreview = $('imagePreview');
const imageName = $('imageName');
imageInput?.addEventListener('change', () => {
  const file = imageInput.files?.[0];
  if (!file) {
    if (imagePreview) { imagePreview.removeAttribute('src'); imagePreview.classList.remove('show'); }
    if (imageName) imageName.textContent = '';
    return;
  }
  const allowed = ['image/jpeg','image/png','image/webp'];
  if (!allowed.includes(file.type)) {
    imageInput.value = '';
    if (imagePreview) { imagePreview.removeAttribute('src'); imagePreview.classList.remove('show'); }
    if (imageName) imageName.textContent = '';
    return setMessage($('orderMsg'), 'اختر صورة JPG أو PNG أو WEBP فقط.', 'error');
  }
  if (file.size > 5 * 1024 * 1024) {
    imageInput.value = '';
    if (imagePreview) { imagePreview.removeAttribute('src'); imagePreview.classList.remove('show'); }
    if (imageName) imageName.textContent = '';
    return setMessage($('orderMsg'), 'حجم الصورة يجب ألا يتجاوز 5MB.', 'error');
  }
  if (imageName) imageName.textContent = file.name;
  if (imagePreview) {
    imagePreview.src = URL.createObjectURL(file);
    imagePreview.classList.add('show');
  }
  setMessage($('orderMsg'), 'تم اختيار الصورة بنجاح ✓', 'success');
});

let qty = 1;
let selectedSite = 'AliExpress';
let cachedOrders = [];

const statusNames = {
  received: 'جديد', checking: 'جاري التحقق', price_confirmation: 'تأكيد السعر',
  awaiting_payment: 'انتظار الدفع', paid: 'مدفوع', shipping: 'قيد الشحن',
  arrived_algeria: 'وصل الجزائر', delivered: 'تم التسليم', cancelled: 'ملغي'
};

function setMessage(el, text, type = '') {
  if (!el) return;
  el.textContent = text || '';
  el.className = type;
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
function formatDate(value) {
  try { return new Date(value).toLocaleDateString('ar-DZ'); } catch { return '—'; }
}
function formatMoney(value, currency = 'DZD') {
  const n = Number(value);
  return Number.isFinite(n) ? `${n.toLocaleString('ar-DZ')} ${currency === 'DZD' ? 'دج' : currency}` : 'بانتظار التسعير';
}
function openAuth(message = '') {
  $('authModal')?.classList.add('show');
  loadTelegramWidget();
  if (message) setMessage($('authMsg'), message, 'error');
}
function closeAuth() { $('authModal')?.classList.remove('show'); }

let telegramWidgetLoaded = false;
function loadTelegramWidget() {
  const box = $('telegramLoginBox');
  if (!box || telegramWidgetLoaded) return;
  telegramWidgetLoaded = true;
  box.innerHTML = '';
  const script = document.createElement('script');
  script.async = true;
  script.src = 'https://telegram.org/js/telegram-widget.js?22';
  script.dataset.telegramLogin = 'FENK_DZ_Bot';
  script.dataset.size = 'large';
  script.dataset.userpic = 'false';
  script.dataset.requestAccess = 'write';
  script.dataset.onauth = 'onTelegramAuth(user)';
  box.appendChild(script);
}

async function onTelegramAuth(user) {
  if (!user?.id || !user?.hash || !user?.auth_date) return setMessage($('authMsg'), 'تعذر التحقق من حساب Telegram.', 'error');
  setMessage($('authMsg'), 'جارٍ تسجيل الدخول عبر Telegram…', 'success');
  try {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/telegram-login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(user) });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.access_token || !result.refresh_token) throw new Error(result.error || 'تعذر تسجيل الدخول عبر Telegram.');
    const { error } = await db.auth.setSession({ access_token: result.access_token, refresh_token: result.refresh_token });
    if (error) throw error;
    setMessage($('authMsg'), 'تم تسجيل الدخول بنجاح ✓', 'success');
    setTimeout(closeAuth, 500);
  } catch (error) {
    console.error('Telegram login:', error);
    setMessage($('authMsg'), error?.message || 'تعذر تسجيل الدخول عبر Telegram.', 'error');
  }
}
window.onTelegramAuth = onTelegramAuth;

async function onTelegramAuth(user) {
  if (!user || !user.id || !user.hash || !user.auth_date) {
    return setMessage($('authMsg'), 'تعذر التحقق من حساب Telegram.', 'error');
  }
  setMessage($('authMsg'), 'جارٍ تسجيل الدخول عبر Telegram…', 'success');
  const widget = $('telegramLoginBox');
  if (widget) widget.style.pointerEvents = 'none';
  try {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/telegram-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user)
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.access_token || !result.refresh_token) {
      throw new Error(result.error || 'تعذر تسجيل الدخول عبر Telegram.');
    }
    const { error } = await db.auth.setSession({
      access_token: result.access_token,
      refresh_token: result.refresh_token
    });
    if (error) throw error;
    setMessage($('authMsg'), 'تم تسجيل الدخول بنجاح ✓', 'success');
    await refreshTelegramLinkUI((await db.auth.getUser()).data.user);
    setTimeout(closeAuth, 500);
  } catch (error) {
    console.error('Telegram login:', error);
    setMessage($('authMsg'), error?.message || 'تعذر تسجيل الدخول عبر Telegram.', 'error');
  } finally {
    if (widget) widget.style.pointerEvents = '';
  }
}
window.onTelegramAuth = onTelegramAuth;

// Product source selector
for (const button of document.querySelectorAll('#sites button')) {
  button.addEventListener('click', () => {
    document.querySelectorAll('#sites button').forEach((b) => b.classList.remove('active'));
    button.classList.add('active');
    selectedSite = button.dataset.site || 'موقع آخر';
  });
}

$('plus')?.addEventListener('click', () => { qty += 1; $('qty').textContent = qty; });
$('minus')?.addEventListener('click', () => { qty = Math.max(1, qty - 1); $('qty').textContent = qty; });
$('accountBtn')?.addEventListener('click', () => openAuth());
$('mobileAccount')?.addEventListener('click', () => openAuth());
$('mobileStore')?.addEventListener('click', () => $('marketModal')?.classList.add('show'));
$('favoritesBtn')?.addEventListener('click', () => openAuth('سجّل الدخول عبر Telegram للوصول إلى المفضلة.'));
$('searchBtn')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') e.currentTarget.click(); });

$('closeAuth')?.addEventListener('click', closeAuth);
$('authModal')?.addEventListener('click', (e) => { if (e.target === $('authModal')) closeAuth(); });

async function refreshTelegramLinkUI(user) {
  const box = $('telegramLinkBox');
  if (!box) return;
  if (!user) { box.innerHTML = ''; return; }
  const { data } = await db.from('telegram_accounts').select('chat_id,username,first_name,linked_at').eq('user_id', user.id).maybeSingle();
  if (data) {
    box.innerHTML = `<div class=\"tg-linked\"><i data-lucide=\"circle-check\"></i><span>Telegram مرتبط${data.username ? ` (@${esc(data.username)})` : ''}</span></div>`;
  } else {
    box.innerHTML = `<button id=\"connectTelegram\" class=\"telegram-connect\" type=\"button\"><i data-lucide=\"send\"></i><span>ربط حسابي مع Telegram</span></button><small class=\"telegram-hint\">اضغط ثم افتح البوت وأرسل Start لربط الحساب.</small>`;
    $('connectTelegram')?.addEventListener('click', createTelegramLink);
  }
  initIcons();
}

async function createTelegramLink() {
  const { data: { user } } = await db.auth.getUser();
  if (!user) return openAuth('سجّل الدخول أولًا لربط Telegram.');
  const token = crypto.randomUUID();
  const expires = new Date(Date.now() + 15 * 60 * 1000).toISOString();
  const { error } = await db.from('telegram_link_tokens').insert({ token, user_id: user.id, expires_at: expires });
  if (error) {
    return setMessage($('authMsg'), 'تعذر إنشاء رابط Telegram. حاول مرة أخرى.', 'error');
  }
  const url = `https://t.me/FENK_DZ_Bot?start=${encodeURIComponent(token)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
  setMessage($('authMsg'), 'تم فتح بوت FENK DZ. اضغط Start لإتمام الربط.', 'success');
  setTimeout(() => refreshTelegramLinkUI(user), 1500);
}

$('googleLogin')?.addEventListener('click', async () => {
  const button = $('googleLogin');
  if (button) button.disabled = true;
  setMessage($('authMsg'), 'جارٍ فتح تسجيل الدخول بحساب Google…', 'success');
  try {
    const { error } = await db.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: 'https://transcendent-fairy-2dc2c4.netlify.app/',
        queryParams: { access_type: 'offline', prompt: 'select_account' }
      }
    });
    if (error) setMessage($('authMsg'), error.message, 'error');
  } catch (error) {
    setMessage($('authMsg'), error?.message || 'تعذر بدء تسجيل الدخول عبر Google.', 'error');
  } finally {
    if (button) button.disabled = false;
  }
});

document.querySelectorAll('[data-scroll]').forEach(el => el.addEventListener('click', () => { const target=document.querySelector(el.dataset.scroll); target?.scrollIntoView({behavior:'smooth',block:'start'}); }));
$('searchBtn')?.addEventListener('click', () => { const q=$('siteSearch').value.trim(); if(q){ $('productUrl').value=/^https?:\/\//i.test(q)?q:''; if(!$('productUrl').value) $('description').value=q; $('order').scrollIntoView({behavior:'smooth'}); } });
$('siteSearch')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') $('searchBtn')?.click(); });
$('countryBtn')?.addEventListener('click', () => document.getElementById('order')?.scrollIntoView({behavior:'smooth'}));
$('closeMarket')?.addEventListener('click', () => $('marketModal')?.classList.remove('show'));
$('marketModal')?.addEventListener('click', e => { if(e.target === $('marketModal')) $('marketModal').classList.remove('show'); });
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  $('authModal')?.classList.remove('show');
  $('marketModal')?.classList.remove('show');
  $('adminPanel')?.classList.remove('show');
});

function updateAuthUI(user) {
  const label = user ? `مسجل: ${user.user_metadata?.full_name || user.user_metadata?.telegram_username || 'Telegram'}` : 'تسجيل الدخول';
  if ($('accountBtn')) $('accountBtn').title = label;
  if ($('mobileAccount')) $('mobileAccount').title = label;
}

async function uploadProductImage(userId) {
  const input = $('productImage');
  const file = input?.files?.[0];
  if (!file) return null;
  const allowed = ['image/jpeg','image/png','image/webp'];
  if (!allowed.includes(file.type)) throw new Error('الصورة يجب أن تكون JPG أو PNG أو WEBP.');
  if (file.size > 5 * 1024 * 1024) throw new Error('حجم الصورة يجب ألا يتجاوز 5MB.');
  const mimeExt = { 'image/jpeg':'jpg', 'image/png':'png', 'image/webp':'webp' };
  const ext = mimeExt[file.type] || 'jpg';
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await db.storage.from('product-images').upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw error;
  return path;
}

$('sendOrder')?.addEventListener('click', async () => {
  setMessage($('orderMsg'), '');
  const { data: { user } } = await db.auth.getUser();
  if (!user) return openAuth('سجّل الدخول عبر Telegram أولًا لإرسال الطلب.');

  const productUrl = $('productUrl').value.trim();
  const description = $('description').value.trim();
  if (!productUrl && !description && !$('productImage')?.files?.length) {
    return setMessage($('orderMsg'), 'أدخل رابط المنتج أو وصفه أو صورة.', 'error');
  }
  if (productUrl && !/^https?:\/\//i.test(productUrl)) {
    return setMessage($('orderMsg'), 'رابط المنتج يجب أن يبدأ بـ https:// أو http://', 'error');
  }

  const button = $('sendOrder');
  button.disabled = true;
  button.textContent = 'جارٍ إرسال الطلب…';
  try {
    const imagePath = await uploadProductImage(user.id);
    const payload = {
      user_id: user.id,
      product_url: productUrl || null,
      product_description: description || null,
      product_image_url: imagePath,
      source_site: selectedSite,
      quantity: qty
    };
    const { data, error } = await db.from('orders').insert(payload).select('id,order_number').single();
    if (error) throw error;
    setMessage($('orderMsg'), `تم إرسال الطلب #${data.order_number}. سنراجع المنتج ونرسل لك السعر.`, 'success');
    $('productUrl').value = '';
    $('description').value = '';
    $('productImage').value = '';
    if ($('imagePreview')) { $('imagePreview').removeAttribute('src'); $('imagePreview').classList.remove('show'); }
    if ($('imageName')) $('imageName').textContent = '';
    qty = 1; $('qty').textContent = '1';
  } catch (error) {
    console.error(error);
    setMessage($('orderMsg'), error?.message || 'تعذر إرسال الطلب. حاول مرة أخرى.', 'error');
  } finally {
    button.disabled = false;
    button.textContent = 'إرسال الطلب ➤';
  }
});

async function isAdmin() {
  const { data: { user } } = await db.auth.getUser();
  if (!user) return false;
  const { data, error } = await db.from('admins').select('user_id').eq('user_id', user.id).maybeSingle();
  if (error) { console.warn('Admin check:', error.message); return false; }
  return !!data;
}

async function openAdmin() {
  if (!(await isAdmin())) return openAuth('هذا الحساب ليس Admin.');
  closeAuth();
  $('adminPanel').classList.add('show');
  const { data: { user } } = await db.auth.getUser();
  $('adminEmail').textContent = user?.email || '';
  await refreshAdmin();
}
$('adminBtn')?.addEventListener('click', openAdmin);
$('closeAdmin')?.addEventListener('click', () => $('adminPanel').classList.remove('show'));

document.querySelectorAll('.admin-tab').forEach((button) => button.addEventListener('click', () => {
  document.querySelectorAll('.admin-tab').forEach((b) => b.classList.remove('active'));
  document.querySelectorAll('.admin-view').forEach((v) => v.classList.add('hidden'));
  button.classList.add('active');
  $('tab-' + button.dataset.tab)?.classList.remove('hidden');
}));

function orderRow(order) {
  const label = order.product_description || order.product_url || 'منتج بدون وصف';
  return `<div class="mini-order"><b>#${esc(order.order_number)}</b><span>${esc(order.source_site || '—')}</span><span>${esc(label).slice(0, 80)}</span><strong>${esc(statusNames[order.status] || order.status || '—')}</strong></div>`;
}
function renderOrders(orders) {
  const query = ($('orderSearch')?.value || '').trim().toLowerCase();
  const filter = $('statusFilter')?.value || '';
  const rows = orders.filter((o) => {
    const number = String(o.order_number || '').toLowerCase();
    return (!query || number.includes(query)) && (!filter || o.status === filter);
  });
  if (!rows.length) { $('ordersTable').innerHTML = '<div class="empty">لا توجد طلبات مطابقة.</div>'; return; }
  $('ordersTable').innerHTML = `<div class="table-wrap"><table class="admin-table"><thead><tr><th>الطلب</th><th>الموقع</th><th>الكمية</th><th>السعر</th><th>الحالة</th><th>التاريخ</th></tr></thead><tbody>${rows.map((o) => `<tr><td>#${esc(o.order_number)}</td><td>${esc(o.source_site)}</td><td>${Number(o.quantity) || 1}</td><td>${formatMoney(o.total_price, o.currency)}</td><td><select class="status-select" data-order-id="${esc(o.id)}">${Object.entries(statusNames).map(([key,label]) => `<option value="${key}" ${key === o.status ? 'selected' : ''}>${label}</option>`).join('')}</select></td><td>${formatDate(o.created_at)}</td></tr>`).join('')}</tbody></table></div>`;
  document.querySelectorAll('.status-select').forEach((select) => select.addEventListener('change', () => changeStatus(select.dataset.orderId, select.value)));
}

async function refreshAdmin() {
  const [ordersResult, usersResult, bannersResult] = await Promise.all([
    db.from('orders').select('*').order('created_at', { ascending: false }),
    db.from('profiles').select('*').order('created_at', { ascending: false }),
    db.from('banners').select('*').order('sort_order', { ascending: true })
  ]);
  if (ordersResult.error) { console.error(ordersResult.error); $('recentOrders').innerHTML = '<div class="empty">تعذر تحميل الطلبات.</div>'; return; }
  cachedOrders = ordersResult.data || [];
  $('sTotal').textContent = cachedOrders.length;
  $('sNew').textContent = cachedOrders.filter((o) => o.status === 'received').length;
  $('sPaid').textContent = cachedOrders.filter((o) => o.status === 'paid').length;
  $('sDone').textContent = cachedOrders.filter((o) => o.status === 'delivered').length;
  $('recentOrders').innerHTML = cachedOrders.length ? cachedOrders.slice(0, 8).map(orderRow).join('') : '<div class="empty">لا توجد طلبات بعد.</div>';
  initIcons();
  renderOrders(cachedOrders);

  const users = usersResult.data || [];
  $('usersTable').innerHTML = users.length ? `<div class="table-wrap"><table class="admin-table"><thead><tr><th>الاسم</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>${users.map((u) => `<tr><td>${esc(u.full_name || '—')}</td><td>${esc(u.phone || '—')}</td><td>${formatDate(u.created_at)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا يوجد مستخدمون بعد.</div>';

  const banners = bannersResult.data || [];
  $('bannersList').innerHTML = banners.length ? banners.map((b) => `<div class="banner-row"><b>${esc(b.title || 'بنر')}</b><span>${b.active ? 'فعال' : 'متوقف'}</span></div>`).join('') : '<div class="empty">لا توجد بنرات بعد.</div>';
}

async function changeStatus(id, status) {
  if (!id || !status) return;
  const { data, error } = await db.from('orders').update({ status }).eq('id', id).select().single();
  if (error) return alert(error.message);
  await db.from('order_status_history').insert({ order_id: id, status, note: 'تم التحديث من لوحة الإدارة' });
  // notifications are created by the database trigger; do not duplicate them here.
  await notifyTelegram(data);
  await refreshAdmin();
}

async function notifyTelegram(order) {
  try {
    const { error } = await db.functions.invoke('telegram-notify', { body: { order_id: order.id } });
    if (error) console.warn('Telegram:', error.message);
  } catch (e) { console.warn('Telegram:', e); }
}

$('orderSearch')?.addEventListener('input', () => renderOrders(cachedOrders));
$('statusFilter')?.addEventListener('change', () => renderOrders(cachedOrders));

$('telegramTest')?.addEventListener('click', async () => {
  const msg = $('telegramMsg');
  setMessage(msg, 'جارٍ اختبار Telegram…', 'success');
  const { data: { user } } = await db.auth.getUser();
  if (!user || !(await isAdmin())) return setMessage(msg, 'يجب تسجيل الدخول بحساب Admin.', 'error');
  const sample = cachedOrders[0];
  if (!sample) return setMessage(msg, 'أنشئ طلبًا أولًا لاختبار Telegram.', 'error');
  try {
    const { error } = await db.functions.invoke('telegram-notify', { body: { order_id: sample.id } });
    if (error) throw error;
    setMessage(msg, 'تم إرسال اختبار Telegram بنجاح ✓', 'success');
  } catch (e) { setMessage(msg, e?.message || 'تعذر إرسال اختبار Telegram.', 'error'); }
});

$('newsletterSubscribe')?.addEventListener('click', () => {
  const input = $('newsletterEmail');
  const value = input?.value.trim() || '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return alert('أدخل بريدًا إلكترونيًا صحيحًا.');
  alert('تم تسجيل بريدك بنجاح. شكرًا لثقتك في FENK DZ.');
  input.value = '';
});

// Keep admin state correct after login/logout and provide realtime refresh for admins.
db.auth.onAuthStateChange(async (_event, session) => {
  updateAuthUI(session?.user || null);
  if (session) {
    await refreshTelegramLinkUI(session.user);
    const admin = await isAdmin();
    if ($('adminBtn')) $('adminBtn').style.display = admin ? 'block' : 'none';
  } else if ($('adminBtn')) $('adminBtn').style.display = 'none';
});

(async () => {
  const { data: { session } } = await db.auth.getSession();
  updateAuthUI(session?.user || null);
  if (session) await refreshTelegramLinkUI(session.user);
  if (session && await isAdmin()) $('adminBtn').style.display = 'block';
})();

// Basic runtime diagnostics for the deployment.
document.querySelectorAll('video').forEach(v => v.addEventListener('error', () => v.closest('.video-card')?.classList.add('video-fallback')));
window.FENK = { version: 'V8-PRE-PUBLISH-CHECKED', supabaseUrl: SUPABASE_URL };
