# FENK DZ V6 — Real Icons + Image Upload Fixed

نسخة محسنة مبنية على FENK DZ V5 مع الحفاظ على هوية وتصميم الصفحة.

## أهم الإصلاحات
- تسجيل الدخول في الواجهة: Google فقط.
- أيقونات حقيقية بأسلوب Lucide بدل الـemoji في عناصر الواجهة الرئيسية.
- رفع صور المنتجات: JPG / PNG / WEBP حتى 5MB.
- معاينة الصورة قبل الإرسال + اسم الملف + رسائل خطأ واضحة.
- رفع الصورة إلى Supabase Storage داخل `product-images/{user_id}/...`.
- تحسين Mobile حتى لا يغطي الشريط السفلي محتوى نموذج الطلب.
- اختبار Telegram من لوحة الإدارة.
- اشتراك النشرة البريدية مع تحقق من البريد.
- تحسين أزرار متجر/حساب الهاتف.

## فحوصات النسخة
- `app.js` تم فحصه بـ Node.js syntax check.
- HTML تم تحليله بنجاح.
- تم فحص المراجع المحلية للصور/الفيديوهات.
- ZIP تم اختباره integrity.
- إعدادات Supabase الحالية لـ `product-images` مضبوطة على 5MB وJPEG/PNG/WEBP.

## Supabase
Project: `zfnlgzwvvytophdxtoks`
URL: `https://zfnlgzwvvytophdxtoks.supabase.co`

لا تضع أي Secret/Service Role key داخل الواجهة. مفتاح Supabase الموجود في `app.js` هو publishable key فقط.
