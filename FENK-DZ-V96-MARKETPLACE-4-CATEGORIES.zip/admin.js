const SUPABASE_URL='https://wqfnzahjwlukncxlxdkp.supabase.co';
const SUPABASE_KEY='sb_publishable__QR4tJ9p5RYOQkIuHkoYKQ_mbDa9tuA';
const FENK_WHATSAPP='213778939292';
const OAUTH_REDIRECT=new URL('admin.html',window.location.href).href;
const db=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{auth:{flowType:'pkce',persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});const $=id=>document.getElementById(id);
let cachedOrders=[],selectedOrderId=null;
const processingStatuses=new Set(['received','pricing','purchasing','shipped','arrived_algeria','out_for_delivery']);
const statusNames={received:'تم استلام الطلب',pricing:'تم تحديد السعر',awaiting_payment:'بانتظار الدفع',payment_submitted:'في انتظار التحقق من الدفع',payment_confirmed:'تم استلام الدفع',purchasing:'جاري تنفيذ الشحن',shipped:'تم الشحن',arrived_algeria:'وصل إلى الجزائر',out_for_delivery:'خرج للتوصيل',delivered:'مكتمل',completed:'تم شحن اللعبة',cancelled:'تم إلغاء الطلب'};
const canonicalStatus=s=>({checking:'received',price_confirmation:'pricing',payment_proof_received:'payment_submitted',paid:'payment_confirmed',shipping:'shipped'}[s]||s||'received');
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const formatDate=v=>{const d=new Date(v);return !v||Number.isNaN(d.getTime())?'—':d.toLocaleDateString('ar-DZ',{day:'2-digit',month:'2-digit',year:'numeric'})+' • '+d.toLocaleTimeString('ar-DZ',{hour:'2-digit',minute:'2-digit'})};
const formatMoney=(v,c='DZD')=>{const n=Number(v);return Number.isFinite(n)&&n>0?`${n.toLocaleString('ar-DZ')} ${c==='DZD'?'دج':c}`:'قيد التحديد'};
const msg=(t,type='')=>{const e=$('adminLoginMsg');if(e){e.textContent=t;e.className='admin-msg '+type}};
const initIcons=()=>{try{window.lucide?.createIcons({attrs:{'stroke-width':2.1}})}catch{}};
async function isAdmin(){const {data:{session}}=await db.auth.getSession();const user=session?.user;if(!user)return false;const {data,error}=await db.from('admin_users').select('user_id').eq('user_id',user.id).maybeSingle();return !error&&!!data}
function showPanel(user){$('adminLogin').style.display='none';$('adminPanel').classList.add('show');$('adminPanel').setAttribute('aria-hidden','false');$('adminEmail').textContent=user?.email||'';initIcons();}
function showLogin(t=''){ $('adminLogin').style.display='grid';$('adminPanel').classList.remove('show');$('adminPanel').setAttribute('aria-hidden','true');if(t)msg(t,'error'); }
function setAdminMenu(open){const p=$('adminPanel');if(!p)return;p.classList.toggle('menu-open',!!open);$('adminMenuBtn')?.setAttribute('aria-expanded',String(!!open));$('adminSideBackdrop')?.classList.toggle('show',!!open)}
$('adminMenuBtn')?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();setAdminMenu(!$('adminPanel').classList.contains('menu-open'))});
$('adminSideBackdrop')?.addEventListener('click',e=>{e.preventDefault();setAdminMenu(false)});

$('adminTelegramTest')?.addEventListener('click',async e=>{
  const b=e.currentTarget; const old=b.textContent; b.disabled=true; b.textContent='جارٍ الاختبار…';
  try{
    const {data:{session}}=await db.auth.getSession();
    if(!session?.access_token) throw new Error('انتهت جلسة الإدارة. سجّل الدخول مرة أخرى.');
    const r=await fetch(`${SUPABASE_URL}/functions/v1/telegram-test`,{method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,apikey:SUPABASE_KEY,'Content-Type':'application/json'}});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||j?.ok===false) throw new Error(j?.error||'تعذر الاتصال بـ Telegram.');
    b.textContent='✓ Telegram متصل';
    setTimeout(()=>{b.textContent=old},2500);
  }catch(err){
    console.error('Telegram test:',err); b.textContent='✕ فشل الاختبار';
    setTimeout(()=>{b.textContent=old},2500);
  }finally{b.disabled=false}
});
$('adminMobileRefresh')?.addEventListener('click',async()=>{const b=$('adminMobileRefresh');b.disabled=true;try{await refreshAdmin();await refreshAdminMessages()}finally{b.disabled=false}});

async function handleOAuthCallback(){
  const url=new URL(window.location.href);
  const code=url.searchParams.get('code');
  const errorParam=url.searchParams.get('error');
  const errorDescription=url.searchParams.get('error_description');
  if(errorParam){
    url.searchParams.delete('error');url.searchParams.delete('error_code');url.searchParams.delete('error_description');url.searchParams.delete('state');url.searchParams.delete('code');
    history.replaceState({},document.title,url.pathname+url.search+url.hash);
    throw new Error(errorDescription||'تعذر تسجيل الدخول باستخدام Google.');
  }
  if(code){
    const {error}=await db.auth.exchangeCodeForSession(code);
    url.searchParams.delete('code');url.searchParams.delete('state');
    history.replaceState({},document.title,url.pathname+url.search+url.hash);
    if(error)throw error;
  }
}
async function boot(){
  try{await handleOAuthCallback();}catch(err){console.error(err);showLogin(err?.message||'تعذر إكمال تسجيل الدخول باستخدام Google.');return;}
  const {data:{session}}=await db.auth.getSession();
  if(!session)return showLogin();
  if(await isAdmin()){showPanel(session.user);await refreshAdmin();await refreshAdminMessages();}
  else{await db.auth.signOut();showLogin('هذا الحساب لا يملك صلاحية Admin.');}
}
$('adminGoogleLogin')?.addEventListener('click',async e=>{
  e.preventDefault();
  const b=e.currentTarget;b.disabled=true;msg('جارٍ فتح Google…','success');
  try{
    const {error}=await db.auth.signInWithOAuth({provider:'google',options:{redirectTo:OAUTH_REDIRECT,queryParams:{prompt:'select_account'}}});
    if(error)throw error;
  }catch(err){console.error(err);msg(err?.message||'تعذر فتح تسجيل الدخول باستخدام Google.','error');b.disabled=false;}
});
db.auth.onAuthStateChange((_event,session)=>{
  if(!session){showLogin();return;}
  setTimeout(async()=>{try{if(await isAdmin()){showPanel(session.user);await refreshAdmin();await refreshAdminMessages()}else{await db.auth.signOut();showLogin('هذا الحساب لا يملك صلاحية Admin.')}}catch(err){console.error(err);showLogin('حدث خطأ أثناء التحقق من صلاحية الإدارة.')}} ,0)
});
$('adminLogoutBtn').onclick=async e=>{e.preventDefault();const b=e.currentTarget;b.disabled=true;try{await db.auth.signOut()}finally{location.reload()}};$('adminSiteBtn').onclick=e=>{e.preventDefault();location.href=location.pathname.replace(/admin\.html.*$/,'')||'/'};
async function handleAdminDetailButton(e){
  const detail=e.target?.closest?.('.detail-btn');
  if(!detail || detail.disabled) return;
  e.preventDefault();
  e.stopPropagation();
  const id=detail.getAttribute('data-order-id');
  if(!id){ console.error('FENK: missing order id'); return; }
  detail.disabled=true;
  try{ await openOrderDetail(id); }catch(err){
    console.error('FENK: failed to open order',err);
    const m=$('orderDetailMsg'); if(m) m.textContent='تعذر فتح تفاصيل الطلب. أعد المحاولة.';
  }finally{ detail.disabled=false; }
}

document.addEventListener('click',async e=>{
  const tab=e.target.closest?.('.admin-tab');
  if(tab){
    e.preventDefault(); e.stopPropagation();
    document.querySelectorAll('.admin-tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.admin-view').forEach(x=>x.classList.add('hidden'));
    tab.classList.add('active');
    const view=$('tab-'+tab.dataset.tab);
    if(view) view.classList.remove('hidden');
    setAdminMenu(false);
    if(tab.dataset.tab==='messages') await refreshAdminMessages();
    if(tab.dataset.tab==='orders') renderOrders(cachedOrders);
    if(tab.dataset.tab==='games') await refreshGameSettingsAdmin();
    if(tab.dataset.tab==='packages') await refreshGamePackagesAdmin();
    if(tab.dataset.tab==='payment') await refreshPaymentSettingsAdmin();
    if(tab.dataset.tab==='marketplaceAds') await refreshMarketplaceAdsAdmin();
    return;
  }
  if(e.target.closest?.('.detail-btn')) await handleAdminDetailButton(e);
});

// Android/mobile reliability: pointerup is fired even when a browser delays/suppresses click.
document.addEventListener('pointerup',async e=>{
  if(e.pointerType==='mouse') return;
  if(e.target.closest?.('.detail-btn')) await handleAdminDetailButton(e);
},{passive:false});
function orderRow(o){return `<div class="mini-order"><b>#${esc(o.order_number)}</b><span>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim())}</span><span>${esc(o.customer_phone||'—')}</span><strong>${esc(statusNames[canonicalStatus(o.status)]||o.status||'—')}</strong><button type="button" class="detail-btn" data-order-id="${esc(o.id)}">فتح الطلب</button></div>`}
function renderOrders(orders){
  const q=($('orderSearch').value||'').trim().toLowerCase();
  const f=$('statusFilter').value||'';
  const rows=orders.filter(o=>{
    const st=canonicalStatus(o.status);
    const search=!q||String(o.order_number||'').toLowerCase().includes(q)||String(o.customer_phone||'').toLowerCase().includes(q);
    const statusOk=f==='cancelled'?st==='cancelled':(st!=='cancelled'&&(!f||(f==='processing'?processingStatuses.has(st):st===f)));
    return search&&statusOk;
  });
  $('ordersTable').innerHTML=rows.length?`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الطلب</th><th>العميل</th><th>الهاتف</th><th>الموقع</th><th>الكمية</th><th>السعر</th><th>الحالة</th><th>التاريخ</th><th></th></tr></thead><tbody>${rows.map(o=>`<tr><td>#${esc(o.order_number)}</td><td>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim()||'—')}</td><td>${esc(o.customer_phone||'—')}</td><td>${esc(o.source_site||'—')}</td><td>${Number(o.quantity)||1}</td><td>${formatMoney(o.total_price,o.currency)}</td><td>${esc(statusNames[canonicalStatus(o.status)]||o.status||'—')}</td><td>${formatDate(o.created_at)}</td><td><button type="button" class="detail-btn" data-order-id="${esc(o.id)}">فتح</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد طلبات مطابقة.</div>';
}
async function refreshAdmin(){const [or,ur,br]=await Promise.all([db.from('orders').select('*').order('created_at',{ascending:false}),db.from('profiles').select('*').order('created_at',{ascending:false})]);if(or.error){$('recentOrders').innerHTML='<div class="empty">تعذر تحميل الطلبات.</div>';return}cachedOrders=or.data||[];const activeOrders=cachedOrders.filter(o=>canonicalStatus(o.status)!=='cancelled');$('sTotal').textContent=cachedOrders.length;$('sNew').textContent=activeOrders.filter(o=>processingStatuses.has(canonicalStatus(o.status))).length;$('sAwaiting').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='awaiting_payment').length;$('sProof').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='payment_submitted').length;$('sPaid').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='payment_confirmed').length;$('sDone').textContent=activeOrders.filter(o=>canonicalStatus(o.status)==='delivered').length;$('sCancelled').textContent=cachedOrders.filter(o=>canonicalStatus(o.status)==='cancelled').length;$('recentOrders').innerHTML=activeOrders.length?activeOrders.slice(0,8).map(orderRow).join(''):'<div class="empty">لا توجد طلبات نشطة.</div>';renderOrders(cachedOrders);const users=ur.data||[];$('usersTable').innerHTML=users.length?`<div class="table-wrap"><table class="admin-table"><thead><tr><th>الاسم</th><th>اللقب</th><th>الهاتف</th><th>التاريخ</th></tr></thead><tbody>${users.map(u=>`<tr><td>${esc(u.first_name||'—')}</td><td>${esc(u.last_name||'—')}</td><td>${esc(u.phone||'—')}</td><td>${formatDate(u.created_at)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا يوجد مستخدمون بعد.</div>';initIcons()}
async function refreshAdminMessages(){const box=$('adminMessagesList');box.innerHTML='<div class="empty">جارٍ تحميل رسائل العملاء…</div>';const {data,error}=await db.from('support_messages').select('id,user_id,message,sender_role,created_at,order_id').order('created_at',{ascending:false}).limit(200);if(error){box.innerHTML='<div class="empty">تعذر تحميل رسائل العملاء.</div>';return}const groups=new Map();for(const m of data||[]){if(!groups.has(m.user_id))groups.set(m.user_id,[]);groups.get(m.user_id).push(m)}const ids=[...groups.keys()];let profiles=[];if(ids.length){const r=await db.from('profiles').select('id,first_name,last_name,phone').in('id',ids);profiles=r.data||[]}const pm=new Map(profiles.map(x=>[x.id,x]));box.innerHTML=ids.length?[...groups.entries()].map(([uid,arr])=>{const p=pm.get(uid)||{};return `<article class="admin-chat-card"><div class="admin-chat-head"><div><b>${esc(`${p.first_name||''} ${p.last_name||''}`.trim()||'عميل')}</b><small>${esc(p.phone||'')}</small></div><span>${formatDate(arr[0].created_at)}</span></div><div class="admin-chat-thread">${arr.slice().reverse().map(m=>`<div class="chat-bubble ${m.sender_role==='admin'?'admin-msg':'mine'}"><p>${esc(m.message)}</p><small>${m.sender_role==='admin'?'FENK':'العميل'} • ${formatDate(m.created_at)}</small></div>`).join('')}</div><form class="admin-reply-form" data-user-id="${esc(uid)}"><textarea rows="2" maxlength="4000" placeholder="اكتب ردًا للعميل..."></textarea><button class="send" type="submit">إرسال الرد</button></form></article>`}).join(''):'<div class="empty">لا توجد رسائل من العملاء بعد.</div>';box.querySelectorAll('.admin-reply-form').forEach(f=>f.onsubmit=async e=>{e.preventDefault();const ta=f.querySelector('textarea'),text=ta.value.trim();if(!text)return;const b=f.querySelector('button');b.disabled=true;const {error}=await db.from('support_messages').insert({user_id:f.dataset.userId,sender_role:'admin',message:text});if(!error){ta.value='';await refreshAdminMessages()}else alert('تعذر إرسال الرد.');b.disabled=false});initIcons()}
async function createCustomerStatusNotification(order, oldStatus, newStatus, oldPaymentInfo=''){
  if(!order?.user_id)return {ok:false,reason:'NO_USER'};
  const paymentInfo=String(order.payment_info||'').trim();
  const adminNote=String(order.admin_note||'').trim();
  const total=Number(order.total_price);
  const paymentChanged=paymentInfo!==String(oldPaymentInfo||'').trim();
  // Important: if the order is already confirmed and the admin only adds/changes
  // the payment information, still send the payment details to the customer.
  // Notify when payment information becomes available, even while the order is still waiting for payment.
  // Also notify on confirmation, and when payment information is changed after confirmation.
  if(oldStatus===newStatus && !(paymentChanged && paymentInfo))return {ok:true,skipped:true};
  const isGame=!!(order.game_id||order.package_id);
  const labels=isGame
    ? {payment_submitted:'تم استلام وصل الدفع الخاص باللعبة',payment_confirmed:'تم تأكيد الدفع للعبة',completed:'تم شحن اللعبة',cancelled:'تم إلغاء طلب اللعبة'}
    : {received:'تم استلام طلبك',pricing:'تم تحديد سعر طلبك',awaiting_payment:'طلبك بانتظار الدفع',payment_submitted:'تم استلام وصل الدفع الخاص بطلبك',payment_confirmed:'تم قبول طلبك وتأكيد الدفع ✓',purchasing:'جارٍ تجهيز طلبك للشراء',shipped:'تم شحن طلبك',arrived_algeria:'وصل طلبك إلى الجزائر',out_for_delivery:'طلبك خرج للتوصيل',delivered:'تم تسليم طلبك',cancelled:'تم إلغاء طلبك'};
  const paymentAvailable=!!paymentInfo && paymentChanged;
  const title=newStatus==='payment_confirmed'?'تم قبول طلبك وتأكيد الدفع ✓':(paymentAvailable?'معلومات الدفع متاحة 💳':(labels[newStatus]||'تم تحديث طلبك'));
  let message=paymentAvailable && newStatus==='awaiting_payment'
    ? `تم تحديد سعر طلبك #${order.order_number||''} وأصبحت معلومات الدفع متاحة.`
    : `تم تحديث حالة طلبك #${order.order_number||''}: ${labels[newStatus]||'تم تحديث طلبك'}.`;
  if(paymentInfo) message += `\n\n💳 معلومات الدفع: ${paymentInfo}`;
  if(adminNote) message += `\n📝 ملاحظة الإدارة: ${adminNote}`;
  if(Number.isFinite(total)&&total>0) message += `\n💰 المبلغ الإجمالي: ${total.toLocaleString('ar-DZ')} دج`;
  if(paymentInfo || newStatus==='payment_confirmed') message += '\n\nيمكنك فتح الطلب من الإشعار لمشاهدة التفاصيل كاملة.';
  const {error}=await db.from('order_notifications').insert({recipient_user_id:order.user_id,order_id:order.id,title,message,is_read:false});
  if(error){console.warn('Customer notification insert failed:',error);return {ok:false,error};}
  return {ok:true};
}

async function openOrderDetail(id){
  const o=cachedOrders.find(x=>String(x.id)===String(id));
  if(!o){console.warn('FENK: order not found',id,cachedOrders.length);const m=$('orderDetailMsg');if(m)m.textContent='لم يتم العثور على هذا الطلب.';return;}
  selectedOrderId=id;
  $('detailOrderNumber').textContent='#'+o.order_number;
  $('detailProductPrice').value=o.product_price??'';$('detailShipping').value=o.shipping_fee??'';$('detailService').value=o.service_fee??'';$('detailTotalPrice').value=o.total_price??'';
  const isGame=!!(o.game_id||o.package_id);
  const statusSelect=$('detailStatus');
  if(statusSelect){
    statusSelect.innerHTML=isGame
      ? '<option value="payment_submitted">تم استلام وصل الدفع</option><option value="payment_confirmed">تم تأكيد الدفع</option><option value="completed">تم شحن اللعبة</option><option value="cancelled">تم إلغاء الطلب</option>'
      : '<option value="received">تم استلام الطلب</option><option value="pricing">تم تحديد السعر</option><option value="awaiting_payment">بانتظار الدفع</option><option value="payment_submitted">تم إرسال وصل الدفع</option><option value="payment_confirmed">تم تأكيد الدفع</option><option value="purchasing">جارٍ شراء المنتج</option><option value="shipped">تم شحن المنتج</option><option value="arrived_algeria">وصل إلى الجزائر</option><option value="out_for_delivery">خرج للتوصيل</option><option value="delivered">تم التسليم</option><option value="cancelled">الطلبات الملغاة</option>';
    statusSelect.value=canonicalStatus(o.status);
  }
  $('detailCarrierName').value=o.carrier_name||'';$('detailTrackingNumber').value=o.tracking_number||'';$('detailTrackingUrl').value=o.tracking_url||'';$('detailPaymentInfo').value=o.payment_info||'';$('detailAdminNote').value=o.admin_note||'';
  const adminPaymentInfo=String(o.payment_info||'').trim()||((o.payment_method||'')==='barid_mob'?'طريقة الدفع: بريد موب\nRIP: 00799999002385072872':'');
  let proofHtml=''; if(o.payment_proof_path){ try{const sr=await db.storage.from('fenk-game-payment-proofs').createSignedUrl(o.payment_proof_path,600); if(sr?.data?.signedUrl) proofHtml=`<div class="full-field admin-payment-preview"><b>إثبات الدفع</b><span><a href="${esc(sr.data.signedUrl)}" target="_blank" rel="noopener">فتح إثبات الدفع</a></span></div>`;}catch(e){console.warn('proof signed url',e)} }
  const p=String(o.customer_phone||'').replace(/\D/g,'').replace(/^0/,'213');
  $('whatsappOrder').href=p?`https://wa.me/${p}?text=${encodeURIComponent(`مرحبًا ${o.customer_first_name||''}، معك FENK بخصوص طلبك #${o.order_number}.`)}`:'#';
  const fields=o.player_data?.fields&&typeof o.player_data.fields==='object'?o.player_data.fields:{};
  const fieldEntries=Object.entries(fields);
  let gameFieldsHtml=''; if(fieldEntries.length){ let inner=''; for(const [k,v] of fieldEntries){ const sensitive=/password|pass|secret/i.test(k); inner += '<div><b>'+esc(k)+'</b><span class="order-secret" data-secret="'+(sensitive?'1':'0')+'" data-value="'+esc(String(v??''))+'">'+(sensitive?'••••••••':' '+esc(String(v??'—')) )+'</span>'+(sensitive?'<button type="button" class="reveal-secret" data-secret-toggle>إظهار</button>':'')+'</div>'; } gameFieldsHtml='<div class="full-field game-order-fields"><b>بيانات اللعبة</b><div class="order-game-fields">'+inner+'</div></div>'; }
  $('orderDetailContent').innerHTML=`<div class="detail-grid"><div><b>الاسم واللقب</b><span>${esc(`${o.customer_first_name||''} ${o.customer_last_name||''}`.trim()||o.customer_name||'—')}</span></div><div><b>الهاتف</b><span>${esc(o.customer_phone||'—')}</span></div><div><b>الولاية</b><span>${esc(o.wilaya||'—')}</span></div><div><b>البلدية</b><span>${esc(o.commune||'—')}</span></div><div><b>الرمز البريدي</b><span>${esc(o.postal_code||'—')}</span></div><div class="full-field"><b>العنوان</b><span>${esc(o.address||'—')}</span></div><div><b>السلعة</b><span>${esc(o.product_name||'—')}</span></div><div><b>معلومات السلعة</b><span>${esc(o.product_info||'—')}</span></div><div><b>رابط السلعة</b><span>${o.product_url?`<a href="${esc(o.product_url)}" target="_blank" rel="noopener">فتح الرابط</a>`:'—'}</span></div><div><b>الكمية</b><span>${Number(o.quantity)||1}</span></div><div><b>تاريخ الطلب</b><span>${formatDate(o.created_at)}</span></div>${o.game_id||o.package_id?`<div><b>اللعبة</b><span>${esc(o.player_data?.game||o.product_name||'—')}</span></div><div><b>الباقة</b><span>${esc(o.player_data?.package||'—')}</span></div><div><b>Player ID</b><span>${esc(o.player_id||'—')}</span></div>${gameFieldsHtml}`:''}${adminPaymentInfo?`<div class="full-field admin-payment-preview"><b>حساب الدفع للطلب</b><span>${esc(adminPaymentInfo)}</span></div>`:''}${proofHtml}</div>`;
  $('orderDetailContent').querySelectorAll('[data-secret-toggle]').forEach(btn=>btn.onclick=()=>{const span=btn.previousElementSibling;if(!span)return;const shown=span.dataset.shown==='1';span.textContent=shown?'••••••••':span.dataset.value;span.dataset.shown=shown?'0':'1';btn.textContent=shown?'إظهار':'إخفاء';});
  $('orderDetailModal').classList.add('show');
}
$('closeOrderDetail').onclick=()=>$('orderDetailModal').classList.remove('show');$('orderDetailModal').onclick=e=>{if(e.target===$('orderDetailModal'))$('orderDetailModal').classList.remove('show')};
$('saveOrderDetail').onclick=async()=>{if(!selectedOrderId)return;const b=$('saveOrderDetail');b.disabled=true;try{const pr=$('detailProductPrice').value===''?null:Number($('detailProductPrice').value),sh=$('detailShipping').value===''?null:Number($('detailShipping').value),sv=$('detailService').value===''?null:Number($('detailService').value);if([pr,sh,sv].some(x=>x!==null&&(!Number.isFinite(x)||x<0)))throw Error();const total=pr!==null&&sh!==null&&sv!==null?pr+sh+sv:null;let status=$('detailStatus').value;if(status==='pricing'&&(!Number.isFinite(total)||total<=0))throw Error();if(total!==null&&total>0&&status==='received')status='pricing';const previousOrder=cachedOrders.find(x=>String(x.id)===String(selectedOrderId))||{};const oldStatus=canonicalStatus(previousOrder.status);const oldPaymentInfo=String(previousOrder.payment_info||'').trim();const {error}=await db.from('orders').update({product_price:pr,shipping_fee:sh,service_fee:sv,status,carrier_name:$('detailCarrierName').value.trim()||null,tracking_number:$('detailTrackingNumber').value.trim()||null,tracking_url:$('detailTrackingUrl').value.trim()||null,payment_info:$('detailPaymentInfo').value.trim()||null,admin_note:$('detailAdminNote').value.trim()||null,updated_at:new Date().toISOString()}).eq('id',selectedOrderId);if(error)throw error;const updatedOrder={...previousOrder,status,payment_info:$('detailPaymentInfo').value.trim()||null,admin_note:$('detailAdminNote').value.trim()||null,total_price:total};const notif=await createCustomerStatusNotification(updatedOrder,oldStatus,status,oldPaymentInfo);$('orderDetailMsg').textContent=notif?.ok===false?'تم حفظ التعديلات، لكن تعذر إنشاء إشعار للزبون.':'تم حفظ التعديلات ✓';if(status==='cancelled'){$('orderDetailModal').classList.remove('show');selectedOrderId=null;}await refreshAdmin()}catch{$('orderDetailMsg').textContent='تعذر حفظ التعديلات.'}finally{b.disabled=false}};
$('orderSearch').oninput=()=>renderOrders(cachedOrders);$('statusFilter').onchange=()=>renderOrders(cachedOrders);
document.querySelectorAll('.stat-filter').forEach(card=>{const apply=()=>{const filter=card.dataset.filter||'';$('statusFilter').value=filter;const ordersTab=document.querySelector('.admin-tab[data-tab="orders"]');if(ordersTab){ordersTab.click();}else renderOrders(cachedOrders);};card.addEventListener('click',apply);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();apply();}});});

// FENK V57 — Admin game packages + Barid Mob settings
let adminGames=[];
let adminPackages=[];

function setAdminMsg(id,text,type=''){
  const el=$(id); if(!el)return;
  el.textContent=text||'';
  el.className='admin-msg'+(type?' '+type:'');
}

function resetPackageForm(){
  $('packageId').value='';
  $('packageName').value='';
  $('packageAmount').value='';
  $('packagePriceDzd').value='';
  $('packageOriginalPriceDzd').value='';
  $('packageSort').value='0';
  $('packageActive').checked=true;
  $('savePackageBtn').textContent='إضافة الباقة';
}

async function loadAdminGamesAndPackages(){
  const [gr,pr]=await Promise.all([
    db.from('games').select('id,name,slug,is_active,sort_order').order('sort_order',{ascending:true}),
    db.from('game_packages').select('id,game_id,name,amount,price_dzd,payment_price_dzd,original_price_dzd,is_active,sort_order').order('sort_order',{ascending:true})
  ]);
  if(gr.error) throw gr.error;
  if(pr.error) throw pr.error;
  adminGames=gr.data||[];
  adminPackages=pr.data||[];
  const select=$('packageGame');
  if(select){
    select.innerHTML=adminGames.length
      ? adminGames.map(g=>`<option value="${esc(g.id)}">${esc(g.name)}${g.is_active?'':' — غير مفعلة'}</option>`).join('')
      : '<option value="">لا توجد ألعاب</option>';
  }
  renderAdminPackages();
}

function renderAdminPackages(){
  const box=$('packagesTable'); if(!box)return;
  const gamesMap=new Map(adminGames.map(g=>[String(g.id),g.name]));
  if(!adminPackages.length){
    box.innerHTML='<div class="empty">لا توجد باقات حاليًا. أضف أول باقة من النموذج أعلاه.</div>';
    return;
  }
  box.innerHTML=`<div class="table-wrap"><table class="packages-admin-table">
    <thead><tr><th>اللعبة</th><th>الباقة</th><th>القيمة</th><th>السعر</th><th>الحالة</th><th>إجراءات</th></tr></thead>
    <tbody>${adminPackages.map(p=>{
      const price=p.payment_price_dzd??p.price_dzd; const original=p.original_price_dzd;
      return `<tr>
        <td data-label="اللعبة">${esc(gamesMap.get(String(p.game_id))||'—')}</td>
        <td data-label="الباقة"><b>${esc(p.name||'—')}</b></td>
        <td data-label="القيمة">${esc(p.amount||'—')}</td>
        <td data-label="السعر">${Number.isFinite(Number(price))?Number(price).toLocaleString('ar-DZ')+' دج':'—'}${original&&Number(original)>Number(price)?`<br><del>${Number(original).toLocaleString('ar-DZ')} دج</del>`:''}</td>
        <td data-label="الحالة"><span class="package-status ${p.is_active?'':'off'}">${p.is_active?'مفعلة':'متوقفة'}</span></td>
        <td data-label="إجراءات"><div class="package-actions">
          <button type="button" data-package-action="edit" data-package-id="${esc(p.id)}">تعديل</button>
          <button type="button" data-package-action="toggle" data-package-id="${esc(p.id)}">${p.is_active?'إيقاف':'تفعيل'}</button>
          <button type="button" class="danger" data-package-action="delete" data-package-id="${esc(p.id)}">حذف</button>
        </div></td>
      </tr>`;
    }).join('')}</tbody></table></div>`;
}

async function refreshGamePackagesAdmin(){
  try{
    setAdminMsg('packageMsg','جارٍ تحميل الباقات…');
    await loadAdminGamesAndPackages();
    resetPackageForm();
    setAdminMsg('packageMsg','تم تحميل الباقات ✓','success');
  }catch(e){
    console.error('FENK packages:',e);
    setAdminMsg('packageMsg','تعذر تحميل الباقات. تأكد من صلاحيات Admin وRLS.','error');
  }
}

$('packageForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const btn=$('savePackageBtn'); btn.disabled=true;
  try{
    const gameId=$('packageGame').value;
    const name=$('packageName').value.trim();
    const amount=$('packageAmount').value.trim()||name;
    const price=Number($('packagePriceDzd').value);
    const sort=Math.max(0,Number($('packageSort').value)||0);
    const active=$('packageActive').checked;
    if(!gameId||!name||!Number.isFinite(price)||price<0) throw new Error('أكمل اللعبة واسم الباقة والسعر بشكل صحيح.');
    const id=$('packageId').value.trim();
    const originalRaw=Number($('packageOriginalPriceDzd').value); const original=Number.isFinite(originalRaw)&&originalRaw>price?originalRaw:null;
    const payload={game_id:gameId,name,amount,price_dzd:price,payment_price_dzd:price,original_price_dzd:original,is_active:active,sort_order:sort};
    const r=id
      ? await db.from('game_packages').update(payload).eq('id',id)
      : await db.from('game_packages').insert(payload);
    if(r.error) throw r.error;
    setAdminMsg('packageMsg',id?'تم تعديل الباقة ✓':'تمت إضافة الباقة ✓','success');
    resetPackageForm();
    await loadAdminGamesAndPackages();
  }catch(err){
    console.error('FENK save package:',err);
    setAdminMsg('packageMsg',err?.message||'تعذر حفظ الباقة.','error');
  }finally{btn.disabled=false;}
});

$('cancelPackageEdit')?.addEventListener('click',()=>{resetPackageForm();setAdminMsg('packageMsg','');});

$('reloadPackagesBtn')?.addEventListener('click',()=>refreshGamePackagesAdmin());

$('packagesTable')?.addEventListener('click',async e=>{
  const btn=e.target.closest?.('[data-package-action]'); if(!btn)return;
  const id=btn.dataset.packageId;
  const pkg=adminPackages.find(x=>String(x.id)===String(id)); if(!pkg)return;
  const action=btn.dataset.packageAction;
  if(action==='edit'){
    $('packageId').value=pkg.id;
    $('packageGame').value=pkg.game_id;
    $('packageName').value=pkg.name||'';
    $('packageAmount').value=pkg.amount||'';
    $('packagePriceDzd').value=pkg.payment_price_dzd??pkg.price_dzd??'';
    $('packageOriginalPriceDzd').value=pkg.original_price_dzd??'';
    $('packageSort').value=pkg.sort_order??0;
    $('packageActive').checked=!!pkg.is_active;
    $('savePackageBtn').textContent='حفظ تعديل الباقة';
    $('packageForm').scrollIntoView({behavior:'smooth',block:'start'});
    return;
  }
  btn.disabled=true;
  try{
    if(action==='toggle'){
      const r=await db.from('game_packages').update({is_active:!pkg.is_active}).eq('id',id);
      if(r.error)throw r.error;
      setAdminMsg('packageMsg',pkg.is_active?'تم إيقاف الباقة ✓':'تم تفعيل الباقة ✓','success');
    }else if(action==='delete'){
      if(!confirm(`حذف باقة «${pkg.name||''}»؟ لن يتم حذف الطلبات القديمة المرتبطة بها.`))return;
      const r=await db.from('game_packages').delete().eq('id',id);
      if(r.error)throw r.error;
      setAdminMsg('packageMsg','تم حذف الباقة ✓','success');
    }
    await loadAdminGamesAndPackages();
  }catch(err){
    console.error('FENK package action:',err);
    setAdminMsg('packageMsg',err?.message||'تعذر تنفيذ العملية.','error');
  }finally{btn.disabled=false;}
});

async function refreshPaymentSettingsAdmin(){
  try{
    setAdminMsg('paymentSettingsMsg','جارٍ تحميل إعدادات الدفع…');
    const {data,error}=await db.from('payment_settings').select('id,method,display_name,account_number,phone_number,instructions,is_active').eq('method','barid_mob').maybeSingle();
    if(error)throw error;
    if(!data){setAdminMsg('paymentSettingsMsg','لم يتم العثور على إعداد بريد موب. شغّل ترقية قاعدة البيانات المرفقة مع المشروع.','error');return;}
    $('baridAccountNumber').value=data.account_number||'';
    $('baridPhoneNumber').value=data.phone_number||'';
    $('baridInstructions').value=data.instructions||'';
    $('baridActive').checked=data.is_active!==false;
    setAdminMsg('paymentSettingsMsg','تم تحميل إعدادات بريد موب ✓','success');
  }catch(err){
    console.error('FENK payment settings:',err);
    setAdminMsg('paymentSettingsMsg','تعذر تحميل إعدادات الدفع.','error');
  }
}

$('paymentSettingsForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const btn=$('savePaymentSettingsBtn');btn.disabled=true;
  try{
    const account=$('baridAccountNumber').value.replace(/\s+/g,'').trim();
    const phone=$('baridPhoneNumber').value.trim()||null;
    const instructions=$('baridInstructions').value.trim();
    const active=$('baridActive').checked;
    if(!account)throw new Error('أدخل رقم RIP / الحساب أولًا.');
    const {data,error}=await db.from('payment_settings').update({
      account_number:account,phone_number:phone,instructions,is_active:active,updated_at:new Date().toISOString()
    }).eq('method','barid_mob').select('id').single();
    if(error||!data)throw error||new Error('لم يتم تحديث إعداد الدفع.');
    setAdminMsg('paymentSettingsMsg','تم حفظ حساب بريد موب وإعداداته ✓','success');
  }catch(err){
    console.error('FENK payment save:',err);
    setAdminMsg('paymentSettingsMsg',err?.message||'تعذر حفظ إعدادات الدفع.','error');
  }finally{btn.disabled=false;}
});

function recalcDetailTotal(){const a=Number($('detailProductPrice')?.value),b=Number($('detailShipping')?.value),c=Number($('detailService')?.value);const vals=[$('detailProductPrice')?.value,$('detailShipping')?.value,$('detailService')?.value];$('detailTotalPrice').value=vals.every(v=>v!=='')&&[a,b,c].every(Number.isFinite)?a+b+c:'';}
['detailProductPrice','detailShipping','detailService'].forEach(id=>$(id)?.addEventListener('input',recalcDetailTotal));
window.fenkOpenOrderDetail=openOrderDetail;
boot();


// FENK V66 — Admin game metadata + per-game checkout fields
let gameSettingsCache=[];
let checkoutFieldsCache=[];

async function refreshGameSettingsAdmin(){
  try{
    setAdminMsg('gameSettingsMsg','جارٍ تحميل الألعاب…');
    const {data,error}=await db.from('games').select('id,name,slug,logo_url,banner_url,description,category,is_active,sort_order').order('sort_order',{ascending:true});
    if(error) throw error;
    gameSettingsCache=data||[];
    const sel=$('gameSettingsGame');
    if(!sel) return;
    const current=sel.value;
    sel.innerHTML=gameSettingsCache.map(g=>`<option value="${esc(g.id)}">${esc(g.name)}</option>`).join('');
    if(current && gameSettingsCache.some(g=>String(g.id)===String(current))) sel.value=current;
    else if(gameSettingsCache[0]) sel.value=gameSettingsCache[0].id;
    loadSelectedGameSettings();
    await loadCheckoutFieldsForSelectedGame();
    setAdminMsg('gameSettingsMsg','تم تحميل إعدادات الألعاب ✓','success');
  }catch(e){console.error(e);setAdminMsg('gameSettingsMsg',e?.message||'تعذر تحميل إعدادات الألعاب.','error');}
}
function loadSelectedGameSettings(){
  const g=gameSettingsCache.find(x=>String(x.id)===String($('gameSettingsGame')?.value));
  if(!g)return;
  $('gameSettingsName').value=g.name||'';
  $('gameSettingsSlug').value=g.slug||'';
  $('gameSettingsBanner').value=g.banner_url||'';
  $('gameSettingsLogo').value=g.logo_url||'';
  $('gameSettingsDescription').value=g.description||'';
  $('gameSettingsCategory').value=g.category||'games';
  $('gameSettingsSort').value=g.sort_order??0;
  $('gameSettingsActive').checked=!!g.is_active;
}
$('gameSettingsGame')?.addEventListener('change',async()=>{loadSelectedGameSettings();await loadCheckoutFieldsForSelectedGame();});
$('reloadGameSettingsBtn')?.addEventListener('click',()=>refreshGameSettingsAdmin());
$('gameSettingsForm')?.addEventListener('submit',async e=>{
  e.preventDefault(); const btn=$('saveGameSettingsBtn');btn.disabled=true;
  try{
    const id=$('gameSettingsGame').value;
    const payload={name:$('gameSettingsName').value.trim(),slug:$('gameSettingsSlug').value.trim(),banner_url:$('gameSettingsBanner').value.trim()||null,logo_url:$('gameSettingsLogo').value.trim()||null,description:$('gameSettingsDescription').value.trim()||null,category:$('gameSettingsCategory').value||'games',sort_order:Math.max(0,Number($('gameSettingsSort').value)||0),is_active:$('gameSettingsActive').checked};
    if(!id||!payload.name||!payload.slug)throw new Error('أكمل اسم اللعبة وSlug.');
    const {error}=await db.from('games').update(payload).eq('id',id);if(error)throw error;
    setAdminMsg('gameSettingsMsg','تم حفظ إعدادات اللعبة ✓','success');await refreshGameSettingsAdmin();
  }catch(e){console.error(e);setAdminMsg('gameSettingsMsg',e?.message||'تعذر حفظ اللعبة.','error');}finally{btn.disabled=false;}
});
function resetCheckoutFieldForm(){
  $('checkoutFieldId').value='';$('checkoutFieldKey').value='';$('checkoutFieldLabel').value='';$('checkoutFieldType').value='text';$('checkoutFieldPlaceholder').value='';$('checkoutFieldOptions').value='';$('checkoutFieldSort').value='0';$('checkoutFieldRequired').checked=true;$('checkoutFieldActive').checked=true;$('saveCheckoutFieldBtn').textContent='إضافة الحقل';
}
function renderCheckoutFieldsAdmin(){
  const box=$('checkoutFieldsTable');if(!box)return;
  const rows=[...checkoutFieldsCache].sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));
  box.innerHTML=rows.length?`<div class="table-wrap"><table class="packages-admin-table"><thead><tr><th>الحقل</th><th>النوع</th><th>إجباري</th><th>الحالة</th><th>الترتيب</th><th></th></tr></thead><tbody>${rows.map(f=>`<tr><td data-label="الحقل"><b>${esc(f.field_label||f.field_key)}</b><small>${esc(f.field_key)}</small></td><td data-label="النوع">${esc(f.field_type||'text')}</td><td data-label="إجباري">${f.is_required?'نعم':'لا'}</td><td data-label="الحالة">${f.is_active?'مفعّل':'متوقف'}</td><td data-label="الترتيب">${esc(f.sort_order??0)}</td><td><div class="package-actions"><button type="button" data-field-action="edit" data-field-id="${esc(f.id)}">تعديل</button><button type="button" data-field-action="toggle" data-field-id="${esc(f.id)}">${f.is_active?'إيقاف':'تفعيل'}</button><button type="button" class="danger" data-field-action="delete" data-field-id="${esc(f.id)}">حذف</button></div></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد حقول مخصصة لهذه اللعبة.</div>';
}
async function loadCheckoutFieldsForSelectedGame(){
  const id=$('gameSettingsGame')?.value;if(!id)return;
  const {data,error}=await db.from('game_checkout_fields').select('id,game_id,field_key,field_label,field_type,placeholder,is_required,options,sort_order,is_active').eq('game_id',id).order('sort_order',{ascending:true});
  if(error){setAdminMsg('checkoutFieldMsg','تعذر تحميل حقول الشحن.','error');return;}
  checkoutFieldsCache=data||[];renderCheckoutFieldsAdmin();resetCheckoutFieldForm();
}
$('checkoutFieldForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const btn=$('saveCheckoutFieldBtn');btn.disabled=true;
  try{
    const gameId=$('gameSettingsGame').value,key=$('checkoutFieldKey').value.trim(),label=$('checkoutFieldLabel').value.trim(),type=$('checkoutFieldType').value;
    if(!gameId||!key||!label)throw new Error('أكمل اسم الحقل الداخلي واسم الحقل للعميل.');
    let options=null;
    if(type==='select') options=$('checkoutFieldOptions').value.split(',').map(x=>x.trim()).filter(Boolean).map(x=>({value:x,label:x}));
    const payload={game_id:gameId,field_key:key,field_label:label,field_type:type,placeholder:$('checkoutFieldPlaceholder').value.trim()||null,is_required:$('checkoutFieldRequired').checked,options,sort_order:Math.max(0,Number($('checkoutFieldSort').value)||0),is_active:$('checkoutFieldActive').checked};
    const id=$('checkoutFieldId').value.trim();
    const r=id?await db.from('game_checkout_fields').update(payload).eq('id',id):await db.from('game_checkout_fields').insert(payload);
    if(r.error)throw r.error;
    setAdminMsg('checkoutFieldMsg',id?'تم تعديل الحقل ✓':'تمت إضافة الحقل ✓','success');await loadCheckoutFieldsForSelectedGame();
  }catch(e){console.error(e);setAdminMsg('checkoutFieldMsg',e?.message||'تعذر حفظ الحقل.','error');}finally{btn.disabled=false;}
});
$('cancelCheckoutFieldEdit')?.addEventListener('click',resetCheckoutFieldForm);
$('checkoutFieldsTable')?.addEventListener('click',async e=>{
  const btn=e.target.closest?.('[data-field-action]');if(!btn)return;const id=btn.dataset.fieldId;const f=checkoutFieldsCache.find(x=>String(x.id)===String(id));if(!f)return;const action=btn.dataset.fieldAction;
  if(action==='edit'){
    $('checkoutFieldId').value=f.id;$('checkoutFieldKey').value=f.field_key||'';$('checkoutFieldLabel').value=f.field_label||'';$('checkoutFieldType').value=f.field_type||'text';$('checkoutFieldPlaceholder').value=f.placeholder||'';$('checkoutFieldOptions').value=Array.isArray(f.options)?f.options.map(x=>x.label??x.value??'').join(', '):'';$('checkoutFieldSort').value=f.sort_order??0;$('checkoutFieldRequired').checked=!!f.is_required;$('checkoutFieldActive').checked=!!f.is_active;$('saveCheckoutFieldBtn').textContent='حفظ تعديل الحقل';return;
  }
  btn.disabled=true;try{let r;if(action==='toggle')r=await db.from('game_checkout_fields').update({is_active:!f.is_active}).eq('id',id);else if(action==='delete')r=await db.from('game_checkout_fields').delete().eq('id',id);if(r?.error)throw r.error;await loadCheckoutFieldsForSelectedGame();}catch(e){console.error(e);setAdminMsg('checkoutFieldMsg',e?.message||'تعذر تعديل الحقل.','error');}finally{btn.disabled=false;}
});


// FENK V86 — Marketplace paid ads review (Admin only)
async function refreshMarketplaceAdsAdmin(){
  const box=$('marketplaceAdsTable'); if(!box)return;
  box.innerHTML='<div class="empty">جارٍ تحميل إعلانات Marketplace…</div>';
  const [{data:ads,error:ae},{data:cats,error:ce}]=await Promise.all([
    db.from('marketplace_ads').select('id,user_id,title,description,price_dzd,contact,image_url,payment_proof_path,ad_fee_dzd,payment_status,approval_status,created_at,package_id,category_id,phone,wilaya,municipality,details').order('created_at',{ascending:false}).limit(200),
    db.from('marketplace_categories').select('id,name,slug')
  ]);
  if(ae){box.innerHTML='<div class="empty">تعذر تحميل الإعلانات: '+esc(ae.message)+'</div>';return}
  const cm=new Map((cats||[]).map(c=>[c.id,c.name]));
  const accepted=(ads||[]).filter(a=>a.payment_status==='confirmed').reduce((s,a)=>s+Number(a.ad_fee_dzd||0),0);
  $('mpAdsRevenue').textContent=accepted.toLocaleString('ar-DZ')+' دج';
  $('mpAdsPending').textContent=(ads||[]).filter(a=>a.payment_status==='pending'||a.approval_status==='pending').length;
  $('mpAdsPublished').textContent=(ads||[]).filter(a=>a.approval_status==='published').length;
  if(!ads?.length){box.innerHTML='<div class="empty">لا توجد طلبات إعلانات حتى الآن.</div>';return}
  const pay={pending:'قيد المراجعة',confirmed:'مقبول',rejected:'مرفوض'};
  const appr={pending:'بانتظار النشر',published:'منشور',rejected:'مرفوض'};
  box.innerHTML=ads.map(a=>`<article class="mp-ad-row">
    <div class="mp-ad-head">
      <div><h4>${esc(a.title)}</h4><small>${esc(cm.get(a.category_id)||'—')} • ${Number(a.ad_fee_dzd||0).toLocaleString('ar-DZ')} دج • ${formatDate(a.created_at)}</small></div>
      <div class="mp-ad-badges"><span class="mp-badge ${a.payment_status==='confirmed'?'ok':a.payment_status==='rejected'?'bad':''}">الدفع: ${pay[a.payment_status]||a.payment_status}</span><span class="mp-badge ${a.approval_status==='published'?'ok':a.approval_status==='rejected'?'bad':''}">الإعلان: ${appr[a.approval_status]||a.approval_status}</span></div>
    </div>
    ${a.image_url?`<img class="mp-ad-proof" src="${esc(a.image_url)}" alt="">`:''}<div style="font-size:11px;line-height:1.7">${a.phone?`الهاتف: ${esc(a.phone)}<br>`:''}${a.wilaya?`الولاية: ${esc(a.wilaya)}<br>`:''}${a.municipality?`البلدية: ${esc(a.municipality)}<br>`:''}${a.details?Object.entries(a.details).filter(([k,v])=>v&&k!=='type').map(([k,v])=>`${esc(k)}: ${esc(v)}`).join(' • '):''}</div>
    <p style="margin:8px 0;font-size:12px;line-height:1.7">${esc(a.description||'')}</p>
    <small>التواصل: ${esc(a.contact||'—')}</small>
    <div class="mp-ad-actions">
      ${a.payment_proof_path?`<button type="button" onclick="viewMarketplaceProof('${esc(a.payment_proof_path)}')">🧾 إثبات الدفع</button>`:''}
      ${a.payment_status!=='confirmed'?`<button type="button" onclick="updateMarketplaceAd('${esc(a.id)}','payment_ok')">✓ قبول الدفع</button>`:''}
      ${a.payment_status!=='rejected'?`<button type="button" class="danger" onclick="updateMarketplaceAd('${esc(a.id)}','payment_no')">رفض الدفع</button>`:''}
      ${a.payment_status==='confirmed'&&a.approval_status!=='published'?`<button type="button" onclick="updateMarketplaceAd('${esc(a.id)}','publish')">📢 نشر الإعلان</button>`:''}
      ${a.approval_status==='published'?`<button type="button" class="danger" onclick="updateMarketplaceAd('${esc(a.id)}','unpublish')">إيقاف الإعلان</button>`:''}
    </div>
  </article>`).join('');
}
async function updateMarketplaceAd(id,action){
  let patch={};
  if(action==='payment_ok') patch={payment_status:'confirmed',payment_confirmed_at:new Date().toISOString(),payment_confirmed_by:null};
  if(action==='payment_no') patch={payment_status:'rejected',approval_status:'rejected'};
  if(action==='publish'){
    const {data:a,error}=await db.from('marketplace_ads').select('package_id').eq('id',id).single();
    if(error) return alert('تعذر قراءة مدة الإعلان.');
    const {data:p}=await db.from('marketplace_packages').select('duration_days').eq('id',a.package_id).single();
    const start=new Date(), end=new Date(start.getTime()+Number(p?.duration_days||1)*86400000);
    patch={approval_status:'published',payment_status:'confirmed',start_at:start.toISOString(),end_at:end.toISOString()};
  }
  if(action==='unpublish') patch={approval_status:'rejected'};
  const {error}=await db.from('marketplace_ads').update(patch).eq('id',id);
  if(error) alert('تعذر تحديث الإعلان: '+error.message); else await refreshMarketplaceAdsAdmin();
}
async function viewMarketplaceProof(path){
  const {data,error}=await db.storage.from('marketplace-payment-proofs').createSignedUrl(path,600);
  if(error||!data?.signedUrl){alert('تعذر فتح إثبات الدفع.');return}
  window.open(data.signedUrl,'_blank','noopener');
}
$('refreshMarketplaceAds')?.addEventListener('click',refreshMarketplaceAdsAdmin);
