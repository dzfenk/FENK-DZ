-- FENK V161: Admin full content control for Marketplace categories.
alter table public.marketplace_categories add column if not exists image_url text;
alter table public.marketplace_categories add column if not exists url text;
comment on column public.marketplace_categories.image_url is 'Admin-managed public image for the Marketplace category card.';
comment on column public.marketplace_categories.url is 'Admin-managed destination URL for the Marketplace category card.';

-- Admin-only write access; public users keep active-category read access.
drop policy if exists marketplace_categories_admin_write on public.marketplace_categories;
create policy marketplace_categories_admin_write on public.marketplace_categories
for all to authenticated
using (public.is_fenk_admin())
with check (public.is_fenk_admin());

-- Keep the image bucket available for Admin uploads.
insert into storage.buckets(id,name,public) values('marketplace-images','marketplace-images',true)
on conflict(id) do update set public=true;
